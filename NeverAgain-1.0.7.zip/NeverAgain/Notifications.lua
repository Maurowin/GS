-- NeverAgain Notifications
-- Handles popup notifications and alerts

local NA = NeverAgain

function NA:InitializeNotifications()
    -- Notification frame will be created on demand
end

-- Show notification when blacklisted player is in group
function NA:ShowBlacklistedInGroupNotification(players)
    if not self.db.profile.settings.popup then return end
    if not players or #players == 0 then return end
    
    -- Create notification frame if it doesn't exist
    if not self.notificationFrame then
        self:CreateNotificationFrame()
    end
    
    local frame = self.notificationFrame
    
    -- Clear previous content
    if frame.entries then
        for _, entry in ipairs(frame.entries) do
            entry:Hide()
        end
    end
    frame.entries = {}
    
    -- Set title
    local count = #players
    frame.title:SetText("⚠ Warning: Blacklisted Player" .. (count > 1 and "s" or "") .. " in Group!")
    
    -- Create entries for each player
    local yOffset = -40
    for i, playerData in ipairs(players) do
        local entry = self:CreateNotificationEntry(frame.content, playerData)
        entry:SetPoint("TOPLEFT", frame.content, "TOPLEFT", 10, yOffset)
        table.insert(frame.entries, entry)
        yOffset = yOffset - 70
    end
    
    -- Adjust frame height
    local totalHeight = 100 + (#players * 70)
    frame:SetHeight(math.min(totalHeight, 500))
    
    -- Show frame
    frame:Show()
    
    -- Play sound
    PlaySound(8959) -- RAID_WARNING sound
end

-- Create notification frame
function NA:CreateNotificationFrame()
    local frame = CreateFrame("Frame", "NeverAgainNotificationFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(450, 200)
    frame:SetPoint("TOP", UIParent, "TOP", 0, -100)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetFrameStrata("HIGH")
    frame:Hide()
    
    -- Red border for warning
    frame:SetBackdropBorderColor(1, 0, 0, 1)
    
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    frame.title:SetPoint("TOP", 0, -8)
    frame.title:SetTextColor(1, 0, 0)
    
    -- Scroll frame for players
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 15, -35)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 45)
    
    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(400, 1)
    scrollFrame:SetScrollChild(content)
    
    frame.scrollFrame = scrollFrame
    frame.content = content
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    closeBtn:SetSize(100, 25)
    closeBtn:SetPoint("BOTTOM", frame, "BOTTOM", 0, 12)
    closeBtn:SetText("OK")
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    
    self.notificationFrame = frame
end

-- Create a notification entry for a player
function NA:CreateNotificationEntry(parent, playerData)
    local entry = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    entry:SetSize(390, 65)
    entry:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    entry:SetBackdropColor(0.3, 0, 0, 0.8)
    entry:SetBackdropBorderColor(1, 0, 0, 1)
    
    -- Player name
    local nameText = entry:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    nameText:SetPoint("TOPLEFT", entry, "TOPLEFT", 10, -8)
    nameText:SetText(playerData.name)
    nameText:SetTextColor(1, 0.3, 0.3)
    
    -- Class color
    if playerData.class and playerData.class ~= "UNKNOWN" then
        local classColor = RAID_CLASS_COLORS[playerData.class]
        if classColor then
            nameText:SetTextColor(classColor.r, classColor.g, classColor.b)
        end
    end
    
    -- Reason
    local reasonText = entry:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    reasonText:SetPoint("TOPLEFT", nameText, "BOTTOMLEFT", 0, -5)
    reasonText:SetWidth(370)
    reasonText:SetJustifyH("LEFT")
    reasonText:SetText("|cffffcc00Reason:|r " .. playerData.reason)
    
    -- Notes if available
    if playerData.notes and playerData.notes ~= "" then
        local notesText = entry:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        notesText:SetPoint("TOPLEFT", reasonText, "BOTTOMLEFT", 0, -3)
        notesText:SetWidth(370)
        notesText:SetJustifyH("LEFT")
        notesText:SetText("|cffaaaaaa" .. playerData.notes .. "|r")
    end
    
    entry:Show()
    return entry
end

-- Show simple notification message
function NA:ShowNotification(message, color)
    if not self.db.profile.settings.notifications then return end
    
    local r, g, b = 1, 1, 0
    if color then
        r, g, b = color.r or r, color.g or g, color.b or b
    end
    
    UIErrorsFrame:AddMessage(message, r, g, b, 1, 5)
end

-- Notification for adding player
function NA:NotifyPlayerAdded(playerName)
    self:ShowNotification("NeverAgain: " .. playerName .. " added to blacklist", {r=1, g=0, b=0})
end

-- Notification for removing player
function NA:NotifyPlayerRemoved(playerName)
    self:ShowNotification("NeverAgain: " .. playerName .. " removed from blacklist", {r=0, g=1, b=0})
end
