-- NeverAgain Core
-- Main addon initialization and core functionality

-- Create addon namespace immediately
if not NeverAgain then
    NeverAgain = {}
end
local NA = NeverAgain

-- Default database structure
local defaults = {
    profile = {
        blacklist = {},
        settings = {
            notifications = true,
            tooltips = true,
            chatIgnore = true,
            popup = true,
            queueIndicator = true,
            lockWindows = false,
            minimap = {
                hide = false,
                angle = 220,
            }
        },
        windowPositions = {
            listFrame = {},
            notificationFrame = {}
        }
    }
}

-- Helper function to print messages
function NA:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ff00[NeverAgain]|r " .. tostring(msg))
end

-- Initialize on ADDON_LOADED
local function OnAddonLoaded(self, event, addonName)
    if addonName ~= "NeverAgain" then return end
    
    -- Initialize database
    if not NeverAgainDB then
        NeverAgainDB = {}
    end
    if not NeverAgainDB.profile then
        NeverAgainDB.profile = CopyTable(defaults.profile)
    end
    
    NA.db = NeverAgainDB
    
    -- Make sure all fields exist
    if not NA.db.profile.blacklist then NA.db.profile.blacklist = {} end
    if not NA.db.profile.settings then NA.db.profile.settings = CopyTable(defaults.profile.settings) end
    if not NA.db.profile.windowPositions then NA.db.profile.windowPositions = {} end
    
    NA:OnInitialize()
    NA:OnEnable()
    
    -- Unregister this event
    NA.initFrame:UnregisterEvent("ADDON_LOADED")
end

-- Create event frame for initialization
NA.initFrame = CreateFrame("Frame")
NA.initFrame:RegisterEvent("ADDON_LOADED")
NA.initFrame:SetScript("OnEvent", OnAddonLoaded)

function NA:OnInitialize()
    -- Register slash commands
    SLASH_NEVERAGAIN1 = "/neveragain"
    SLASH_NEVERAGAIN2 = "/na"
    SlashCmdList["NEVERAGAIN"] = function(msg)
        NA:SlashCommand(msg)
    end
    
    self:Print("NeverAgain loaded! Type /na or /neveragain to open the blacklist.")
end

function NA:OnEnable()
    -- Create event frame
    if not self.eventFrame then
        self.eventFrame = CreateFrame("Frame")
    end
    
    -- Register events
    self.eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    self.eventFrame:RegisterEvent("LFG_LIST_SEARCH_RESULTS_RECEIVED")
    self.eventFrame:RegisterEvent("LFG_LIST_SEARCH_RESULT_UPDATED")
    self.eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    self.eventFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    
    -- Set event handler
    self.eventFrame:SetScript("OnEvent", function(frame, event, ...)
        if NA[event] then
            NA[event](NA, event, ...)
        end
    end)
    
    -- Initialize modules
    self:InitializeDatabase()
    self:InitializeUI()
    self:InitializeMinimap()
    self:InitializeTooltips()
    self:InitializeChatFilter()
    self:InitializeGroupScanner()
    self:InitializeNotifications()
    
    self:Print("NeverAgain enabled. Stay safe!")
end

function NA:OnDisable()
    -- Clean up
end

function NA:SlashCommand(input)
    input = strtrim(input):lower()
    
    if input == "" or input == "show" then
        self:ToggleMainWindow()
    elseif input == "config" or input == "options" then
        self:OpenConfig()
    elseif input == "minimap" then
        self:ToggleMinimapButton()
    elseif input == "minimap show" then
        self:ShowMinimapButton()
        self:Print("Minimap button shown.")
    elseif input == "minimap hide" then
        self:HideMinimapButton()
        self:Print("Minimap button hidden.")
    elseif input:match("^add%s+(.+)") then
        local playerName = input:match("^add%s+(.+)")
        self:AddToBlacklist(playerName, "Added via command")
    elseif input:match("^remove%s+(.+)") then
        local playerName = input:match("^remove%s+(.+)")
        self:RemoveFromBlacklist(playerName)
    else
        self:Print("NeverAgain Commands:")
        self:Print("/na show - Toggle blacklist window")
        self:Print("/na add [player] - Add player to blacklist")
        self:Print("/na remove [player] - Remove player from blacklist")
        self:Print("/na minimap - Toggle minimap button")
        self:Print("/na config - Open settings")
    end
end

-- Helper function to normalize player names (remove realm)
function NA:NormalizeName(name)
    if not name then return nil end
    -- Use pcall to safely handle potential secret string values
    local success, result = pcall(function()
        return name:gsub("%-.*", "") -- Remove realm
    end)
    if not success then
        -- If gsub fails (e.g., name is a secret value), return nil
        return nil
    end
    return result
end

-- Get full player name with realm
function NA:GetFullName(name)
    if not name then return nil end
    
    -- If already has realm, return as is (use pcall for string operations)
    local hasRealm = pcall(function() return name:find("-") end)
    if hasRealm then
        local success, result = pcall(function() return name:find("-") end)
        if success and result then
            return name
        end
    end
    
    -- Try to get realm from target/mouseover/party/raid
    local realm = nil
    
    -- Helper function to safely check unit name
    local function SafeCheckUnit(unit, targetName)
        if not UnitExists(unit) then return false end
        local success, unitName, unitRealm = pcall(UnitName, unit)
        if not success then return false end
        -- Use pcall for the comparison in case unitName is a secret value
        local compareSuccess, isMatch = pcall(function() return unitName == targetName end)
        if not compareSuccess then return false end
        return isMatch, unitRealm
    end
    
    -- Check target
    local isMatch, unitRealm = SafeCheckUnit("target", name)
    if isMatch then
        realm = unitRealm
    end
    
    -- Check mouseover
    if not realm then
        isMatch, unitRealm = SafeCheckUnit("mouseover", name)
        if isMatch then
            realm = unitRealm
        end
    end
    
    -- Check party members
    if not realm and IsInGroup() then
        for i = 1, 4 do
            local unit = "party" .. i
            isMatch, unitRealm = SafeCheckUnit(unit, name)
            if isMatch then
                realm = unitRealm
                break
            end
        end
    end
    
    -- Check raid members
    if not realm and IsInRaid() then
        for i = 1, 40 do
            local unit = "raid" .. i
            isMatch, unitRealm = SafeCheckUnit(unit, name)
            if isMatch then
                realm = unitRealm
                break
            end
        end
    end
    
    -- Default to current realm if not found
    if not realm or realm == "" then
        realm = GetRealmName()
    end
    
    return name .. "-" .. realm
end

function NA:OpenConfig()
    -- TODO: Implement config window
    self:Print("Configuration window coming soon!")
end