-- NeverAgain Minimap Button
-- Adds a minimap button for easy access using LibDBIcon

local NA = NeverAgain
local LDB = LibStub("LibDataBroker-1.1", true)
local icon = LibStub("LibDBIcon-1.0", true)

function NA:InitializeMinimap()
    if not LDB or not icon then
        self:Print("LibDBIcon not found, minimap button disabled")
        return
    end
    
    -- Ensure settings exist
    if not self.db.profile.settings.minimap then
        self.db.profile.settings.minimap = {}
    end
    
    -- Set default values
    if self.db.profile.settings.minimap.hide == nil then
        self.db.profile.settings.minimap.hide = false
    end
    if not self.db.profile.settings.minimap.minimapPos then
        self.db.profile.settings.minimap.minimapPos = 220
    end
    if not self.db.profile.settings.minimap.radius then
        self.db.profile.settings.minimap.radius = 105
    end
    
    -- Create LibDataBroker object
    local ldbObject = LDB:NewDataObject("NeverAgain", {
        type = "data source",
        text = "NeverAgain",
        icon = "Interface\\RaidFrame\\ReadyCheck-NotReady",
        OnClick = function(clickedframe, button)
            if button == "LeftButton" then
                NA:ToggleMainWindow()
            elseif button == "RightButton" then
                NA:ShowMinimapMenu(clickedframe)
            end
        end,
        OnTooltipShow = function(tooltip)
            if not tooltip or not tooltip.AddLine then return end
            tooltip:SetText("|cff00ff00NeverAgain|r")
            tooltip:AddLine("Personal Blacklist Manager", 1, 1, 1)
            tooltip:AddLine(" ")
            tooltip:AddLine("|Left-Click:|r Open blacklist", 0.7, 0.7, 0.7)
            tooltip:AddLine("| Right-Click:|r Options menu", 0.7, 0.7, 0.7)
            tooltip:AddLine("|Drag:|r Move button", 0.7, 0.7, 0.7)
            
            local count = NA:GetBlacklistCount()
            if count > 0 then
                tooltip:AddLine(" ")
                tooltip:AddLine(count .. " player" .. (count > 1 and "s" or "") .. " blacklisted", 1, 0, 0)
            end
        end,
    })
    
    -- Register with LibDBIcon
    icon:Register("NeverAgain", ldbObject, self.db.profile.settings.minimap)
    
    self.ldbObject = ldbObject
    
    -- Make sure it's shown if not hidden
    if not self.db.profile.settings.minimap.hide then
        icon:Show("NeverAgain")
    end
end

function NA:ShowMinimapMenu(frame)
    -- Use MenuUtil for WoW 12.0+
    if not MenuUtil or not MenuUtil.CreateContextMenu then
        self:Print("Menu system not available")
        return
    end
    
    MenuUtil.CreateContextMenu(frame, function(owner, rootDescription)
        -- Title
        rootDescription:CreateTitle("|cff00ff00NeverAgain|r")
        
        -- Open Blacklist
        rootDescription:CreateButton("Open Blacklist", function()
            NA:ToggleMainWindow()
        end)
        
        -- Add Player (with submenu for target/focus)
        local addSubmenu = rootDescription:CreateButton("Add Player")
        addSubmenu:CreateButton("Add Target", function()
            if UnitExists("target") and UnitIsPlayer("target") then
                local success, name = pcall(UnitName, "target")
                if success and name then
                    NA:ShowAddDialog()
                    if NA.addDialog then
                        NA.addDialog.nameInput:SetText(name)
                    end
                else
                    NA:Print("Unable to get target name")
                end
            else
                NA:Print("No valid player target")
            end
        end)
        addSubmenu:CreateButton("Add Focus", function()
            if UnitExists("focus") and UnitIsPlayer("focus") then
                local success, name = pcall(UnitName, "focus")
                if success and name then
                    NA:ShowAddDialog()
                    if NA.addDialog then
                        NA.addDialog.nameInput:SetText(name)
                    end
                else
                    NA:Print("Unable to get focus name")
                end
            else
                NA:Print("No valid player focus")
            end
        end)
        addSubmenu:CreateButton("Add Manually...", function()
            NA:ShowAddDialog()
        end)
        
        -- Separator
        rootDescription:CreateDivider()
        
        -- Statistics
        local count = NA:GetBlacklistCount()
        local statsText = count .. " player" .. (count ~= 1 and "s" or "") .. " blacklisted"
        rootDescription:CreateButton("|cffaaaaaa" .. statsText .. "|r", function() end):SetEnabled(false)
        
        -- Separator
        rootDescription:CreateDivider()
        
        -- Options submenu
        local optionsSubmenu = rootDescription:CreateButton("Options")
        
        -- Toggle features
        optionsSubmenu:CreateCheckbox("Notifications", function()
            return NA.db.profile.settings.notifications
        end, function()
            NA.db.profile.settings.notifications = not NA.db.profile.settings.notifications
            NA:Print("Notifications " .. (NA.db.profile.settings.notifications and "enabled" or "disabled"))
        end)
        
        optionsSubmenu:CreateCheckbox("Tooltips", function()
            return NA.db.profile.settings.tooltips
        end, function()
            NA.db.profile.settings.tooltips = not NA.db.profile.settings.tooltips
            NA:Print("Tooltips " .. (NA.db.profile.settings.tooltips and "enabled" or "disabled"))
        end)
        
        optionsSubmenu:CreateCheckbox("Chat Ignore", function()
            return NA.db.profile.settings.chatIgnore
        end, function()
            NA.db.profile.settings.chatIgnore = not NA.db.profile.settings.chatIgnore
            NA:Print("Chat ignore " .. (NA.db.profile.settings.chatIgnore and "enabled" or "disabled"))
        end)
        
        optionsSubmenu:CreateCheckbox("Queue Indicator", function()
            return NA.db.profile.settings.queueIndicator
        end, function()
            NA.db.profile.settings.queueIndicator = not NA.db.profile.settings.queueIndicator
            NA:Print("Queue indicator " .. (NA.db.profile.settings.queueIndicator and "enabled" or "disabled"))
        end)
        
        optionsSubmenu:CreateDivider()
        
        optionsSubmenu:CreateButton("Hide Minimap Button", function()
            NA:HideMinimapButton()
            NA:Print("Minimap button hidden. Use /na minimap show to show it again.")
        end)
        
        -- Separator
        rootDescription:CreateDivider()
        
        -- Close
        rootDescription:CreateButton("|cffff0000Close|r", function() end)
    end)
end

function NA:ShowMinimapButton()
    if icon then
        icon:Show("NeverAgain")
        self.db.profile.settings.minimap.hide = false
    end
end

function NA:HideMinimapButton()
    if icon then
        icon:Hide("NeverAgain")
        self.db.profile.settings.minimap.hide = true
    end
end

function NA:ToggleMinimapButton()
    if self.db.profile.settings.minimap.hide then
        self:ShowMinimapButton()
    else
        self:HideMinimapButton()
    end
end