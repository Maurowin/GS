-- NeverAgain Database Management
-- Handles blacklist entries and data management

local NA = NeverAgain

function NA:InitializeDatabase()
    -- Database is already initialized in Core.lua
    self:Print("Database initialized with " .. self:GetBlacklistCount() .. " entries.")
end

-- Add a player to the blacklist
function NA:AddToBlacklist(playerName, reason, notes)
    if not playerName or playerName == "" then
        self:Print("Invalid player name.")
        return false
    end
    
    -- Normalize and get full name with realm
    local normalizedName = self:NormalizeName(playerName)
    if not normalizedName then
        self:Print("Unable to process player name.")
        return false
    end
    
    local fullName = self:GetFullName(playerName)
    if not fullName then
        self:Print("Unable to get full player name.")
        return false
    end
    
    -- Check if already blacklisted
    if self.db.profile.blacklist[fullName] then
        self:Print(normalizedName .. " is already on your blacklist.")
        return false
    end
    
    -- Try to detect class from various sources
    local className = "UNKNOWN"
    
    -- Helper function to safely compare unit name
    local function SafeUnitNameMatch(unit, targetName)
        if not UnitExists(unit) then return false end
        local success, unitName = pcall(UnitName, unit)
        if not success then return false end
        local compareSuccess, isMatch = pcall(function() return unitName == targetName end)
        if not compareSuccess then return false end
        return isMatch
    end
    
    -- Try from target
    if SafeUnitNameMatch("target", normalizedName) then
        local _, class = UnitClass("target")
        if class then className = class end
    end
    
    -- Try from mouseover
    if className == "UNKNOWN" and SafeUnitNameMatch("mouseover", normalizedName) then
        local _, class = UnitClass("mouseover")
        if class then className = class end
    end
    
    -- Try from party/raid members
    if className == "UNKNOWN" then
        if IsInRaid() then
            for i = 1, 40 do
                local unit = "raid" .. i
                if SafeUnitNameMatch(unit, normalizedName) then
                    local _, class = UnitClass(unit)
                    if class then className = class end
                    break
                end
            end
        elseif IsInGroup() then
            for i = 1, 4 do
                local unit = "party" .. i
                if SafeUnitNameMatch(unit, normalizedName) then
                    local _, class = UnitClass(unit)
                    if class then className = class end
                    break
                end
            end
        end
    end
    
    -- Extract realm from fullName if present (use pcall for string operations)
    local realm = GetRealmName()  -- Default value
    local success, matchResult = pcall(function() return fullName:match("%-(.+)$") end)
    if success and matchResult then
        realm = matchResult
    end
    
    -- Add to blacklist
    self.db.profile.blacklist[fullName] = {
        name = normalizedName,
        fullName = fullName,
        realm = realm,
        reason = reason or "No reason provided",
        notes = notes or "",
        dateAdded = time(),
        class = className,
        muted = false,
    }
    
    -- Get class color for display
    local displayName = normalizedName
    if className ~= "UNKNOWN" then
        local classColor = RAID_CLASS_COLORS[className]
        if classColor then
            displayName = string.format("|cff%02x%02x%02x%s|r", classColor.r * 255, classColor.g * 255, classColor.b * 255, normalizedName)
        end
    end
    
    self:Print(displayName .. " |cffaaaaaa(" .. realm .. ")|r has been added to your blacklist.")
    
    -- Update UI if open
    if self.listFrame and self.listFrame:IsShown() then
        self:UpdateBlacklistDisplay()
    end
    
    return true
end

-- Remove a player from the blacklist
function NA:RemoveFromBlacklist(playerName)
    if not playerName or playerName == "" then
        self:Print("Invalid player name.")
        return false
    end
    
    -- Try different variations to find the entry
    local fullName = nil
    
    -- 1. Try with the name as-is (might already have realm)
    if self.db.profile.blacklist[playerName] then
        fullName = playerName
    else
        -- 2. Try normalized + realm
        local normalizedName = self:NormalizeName(playerName)
        if normalizedName then
            local withRealm = self:GetFullName(normalizedName)
            
            if withRealm and self.db.profile.blacklist[withRealm] then
                fullName = withRealm
            else
                -- 3. Search by matching name field
                for key, entry in pairs(self.db.profile.blacklist) do
                    if entry.name == normalizedName or entry.fullName == playerName then
                        fullName = key
                        break
                    end
                end
            end
        else
            -- If normalization failed, try to search by partial match
            for key, entry in pairs(self.db.profile.blacklist) do
                if entry.fullName == playerName then
                    fullName = key
                    break
                end
            end
        end
    end
    
    if not fullName or not self.db.profile.blacklist[fullName] then
        self:Print(playerName .. " is not on your blacklist.")
        return false
    end
    
    local entry = self.db.profile.blacklist[fullName]
    
    -- Remove from blacklist
    self.db.profile.blacklist[fullName] = nil
    
    self:Print("|cff00ff00" .. entry.name .. "|r has been removed from your blacklist.")
    
    -- Update UI if open
    if self.listFrame and self.listFrame:IsShown() then
        self:UpdateBlacklistDisplay()
    end
    
    return true
end

-- Check if a player is blacklisted
function NA:IsBlacklisted(playerName)
    if not playerName then return false end
    
    local normalizedName = self:NormalizeName(playerName)
    -- If normalization fails (secret value), we can't safely check
    if not normalizedName then return false end
    
    local fullName = self:GetFullName(normalizedName)
    if not fullName then return false end
    
    return self.db.profile.blacklist[fullName] ~= nil
end

-- Get blacklist entry for a player
function NA:GetBlacklistEntry(playerName)
    if not playerName then return nil end
    
    local normalizedName = self:NormalizeName(playerName)
    -- If normalization fails (secret value), we can't safely get entry
    if not normalizedName then return nil end
    
    local fullName = self:GetFullName(normalizedName)
    if not fullName then return nil end
    
    return self.db.profile.blacklist[fullName]
end

-- Update blacklist entry
function NA:UpdateBlacklistEntry(playerName, field, value)
    if not playerName then return false end
    
    local normalizedName = self:NormalizeName(playerName)
    -- If normalization fails (secret value), we can't safely update
    if not normalizedName then return false end
    
    local fullName = self:GetFullName(normalizedName)
    if not fullName then return false end
    
    if not self.db.profile.blacklist[fullName] then
        return false
    end
    
    self.db.profile.blacklist[fullName][field] = value
    
    -- Update UI if open
    if self.listFrame and self.listFrame:IsShown() then
        self:UpdateBlacklistDisplay()
    end
    
    return true
end

-- Get total blacklist count
function NA:GetBlacklistCount()
    local count = 0
    for _ in pairs(self.db.profile.blacklist) do
        count = count + 1
    end
    return count
end

-- Get all blacklisted players as sorted array
function NA:GetBlacklistArray()
    local array = {}
    for fullName, entry in pairs(self.db.profile.blacklist) do
        table.insert(array, entry)
    end
    
    -- Sort by name
    table.sort(array, function(a, b)
        return a.name < b.name
    end)
    
    return array
end

-- Clear all blacklist entries
function NA:ClearBlacklist()
    self.db.profile.blacklist = {}
    
    self:Print("Blacklist cleared.")
    
    -- Update UI if open
    if self.listFrame and self.listFrame:IsShown() then
        self:UpdateBlacklistDisplay()
    end
end

-- Quick add from various sources
function NA:QuickAdd(unit, reason)
    if not unit then return end
    
    local success, name = pcall(UnitName, unit)
    if success and name then
        self:AddToBlacklist(name, reason or "Quick add")
    end
end
