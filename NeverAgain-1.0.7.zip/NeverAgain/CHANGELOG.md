# Changelog


**Core Ignore List System**
- Add players to your personnal blacklist with reasons and notes
- Remove players from your personal blacklist
- View all personnal blacklisted players in card-based UI
- Class-colored player names
- Date tracking for when players were added
- Cross-realm support with server display

**User Interface**
- Modern card-based layout with 3-column grid
- Add/Edit player dialog with dropdown for reasons
- Hover effects and visual feedback

**Tooltip Information**
- Ignored status shown on player tooltips
- Displays reason and notes
- Shows date added
- Works with mouseover, target, party/raid members

**Context Menu Integration**
- Right-click player names in chat to add to your ignore list
- Right-click minimap button for quick options menu
- Add Target/Focus from minimap menu

**Slash Commands**
- `/na` or `/neveragain` - Toggle main window
- `/na add [name]` - Quick add
- `/na remove [name]` - Quick remove
- `/na minimap` - Toggle minimap button

**Database Management**
- Persistent storage via SavedVariables
- Automatic detection of player class and realm
- Full support for cross-realm players
- Clear All function with confirmation dialog

#### 📋 Features Details

**Predefined Reasons:**
- Toxic Behavior
- Rage Quit
- Ninja Looter
- AFK / Leeching
- Trolling
- Scammer
- Griefing
- Bad Performance
- Harassment
- Other

---

**Remember**: Use it responsibly and avoid harassment of other players.

**Stay safe and enjoy your time in Azeroth!**