-- NeverAgain Chat Filter
-- Filters chat messages from blacklisted players

local NA = NeverAgain

function NA:InitializeChatFilter()
    -- Register chat message filters
    self:RegisterChatFilters()
end

-- Register filters for all chat types
function NA:RegisterChatFilters()
    local chatEvents = {
        "CHAT_MSG_SAY",
        "CHAT_MSG_YELL",
        "CHAT_MSG_EMOTE",
        "CHAT_MSG_TEXT_EMOTE",
        "CHAT_MSG_PARTY",
        "CHAT_MSG_PARTY_LEADER",
        "CHAT_MSG_RAID",
        "CHAT_MSG_RAID_LEADER",
        "CHAT_MSG_RAID_WARNING",
        "CHAT_MSG_INSTANCE_CHAT",
        "CHAT_MSG_INSTANCE_CHAT_LEADER",
        "CHAT_MSG_GUILD",
        "CHAT_MSG_OFFICER",
        "CHAT_MSG_WHISPER",
        "CHAT_MSG_WHISPER_INFORM",
        "CHAT_MSG_BN_WHISPER",
        "CHAT_MSG_BN_WHISPER_INFORM",
        "CHAT_MSG_CHANNEL",
    }
    
    for _, event in ipairs(chatEvents) do
        ChatFrame_AddMessageEventFilter(event, function(...)
            return self:FilterChatMessage(...)
        end)
    end
end

-- Filter function for chat messages
function NA:FilterChatMessage(self, event, msg, sender, ...)
    if not NA.db.profile.settings.chatIgnore then
        return false
    end
    
    -- Extract player name (remove server)
    local name = sender:match("^([^%-]+)")
    if not name then
        name = sender
    end
    
    -- Check if blacklisted
    if NA:IsBlacklisted(name) then
        -- Return true to filter (hide) the message
        return true
    end
    
    -- Don't filter
    return false
end

-- Sync with WoW's ignore list
function NA:SyncWithIgnoreList()
    if not self.db.profile.settings.chatIgnore then return end
    
    -- Add all blacklisted players to ignore list
    for fullName, entry in pairs(self.db.profile.blacklist) do
        C_FriendList.AddIgnore(entry.name)
    end
end

-- Remove from ignore list when removing from blacklist
function NA:RemoveFromIgnoreList(playerName)
    C_FriendList.DelIgnore(playerName)
end

-- Batch add to ignore list
function NA:AddAllToIgnoreList()
    for fullName, entry in pairs(self.db.profile.blacklist) do
        C_FriendList.AddIgnore(entry.name)
    end
    self:Print("All blacklisted players added to ignore list.")
end

-- Batch remove from ignore list
function NA:RemoveAllFromIgnoreList()
    for fullName, entry in pairs(self.db.profile.blacklist) do
        C_FriendList.DelIgnore(entry.name)
    end
    self:Print("All blacklisted players removed from ignore list.")
end
