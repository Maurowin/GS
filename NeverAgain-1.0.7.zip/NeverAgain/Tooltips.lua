-- NeverAgain Tooltips
-- Adds blacklist information to unit tooltips

local NA = NeverAgain

function NA:InitializeTooltips()
    -- Use TooltipDataProcessor for modern WoW versions
    if TooltipDataProcessor then
        TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip, data)
            self:UpdateTooltip(tooltip, data)
        end)
    else
        -- Fallback for older method
        GameTooltip:HookScript("OnShow", function(tooltip)
            self:UpdateTooltipLegacy(tooltip)
        end)
        
        -- Also try to hook the update
        if GameTooltip.SetUnit then
            hooksecurefunc(GameTooltip, "SetUnit", function(tooltip)
                self:UpdateTooltipLegacy(tooltip)
            end)
        end
    end
    
    -- Hook into chat dropdown menus - DELAYED to avoid taint
    C_Timer.After(1, function()
        self:HookChatDropdown()
    end)
end

-- Hook into chat dropdown menu system
function NA:HookChatDropdown()
    -- Use the new Menu system for WoW 12.0+
    if not Menu or not Menu.ModifyMenu then
        -- Fallback: menu system not available
        return
    end
    
    -- List of menu types to hook
    local menuTypes = {
        "MENU_UNIT_PLAYER",
        "MENU_UNIT_ENEMY_PLAYER", 
        "MENU_UNIT_PARTY",
        "MENU_UNIT_RAID_PLAYER",
        "MENU_UNIT_FRIEND",
        "MENU_UNIT_COMMUNITIES_GUILD_MEMBER",
        "MENU_UNIT_COMMUNITIES_WOW_MEMBER",
    }
    
    for _, menuType in ipairs(menuTypes) do
        -- Protect the hook with pcall to prevent taint propagation
        local success, err = pcall(function()
            Menu.ModifyMenu(menuType, function(owner, rootDescription, contextData)
                -- Verify we're not in a protected context
                if InCombatLockdown() then return end
                
                -- Make sure we have valid data
                if not contextData then return end
                
                -- Get player name from context
                local name = contextData.name
                if not name then
                    -- Try to get from unit
                    if contextData.unit and UnitIsPlayer(contextData.unit) then
                        name = UnitName(contextData.unit)
                    end
                end
                
                if not name then return end
                
                -- Add separator
                rootDescription:CreateDivider()
                
                -- Add our menu option
                if NA:IsBlacklisted(name) then
                    rootDescription:CreateButton("|cffff0000Remove from NeverAgain|r", function()
                        NA:RemoveFromBlacklist(name)
                    end)
                else
                    rootDescription:CreateButton("|cff00ff00Add to NeverAgain|r", function()
                        NA:ShowAddDialog()
                        if NA.addDialog then
                            NA.addDialog.nameInput:SetText(name)
                            -- Extract realm if present
                            local realm = name:match("%-(.+)$")
                            if realm then
                                NA.addDialog.realmInput:SetText(realm)
                                NA.addDialog.nameInput:SetText(name:match("^(.+)%-"))
                            end
                        end
                    end)
                end
            end)
        end)
        
        if not success then
            -- Silently fail if we can't hook this menu type
            -- This prevents taint errors from propagating
        end
    end
end

-- Modern tooltip update method
function NA:UpdateTooltip(tooltip, data)
    if not self.db.profile.settings.tooltips then return end
    if not tooltip or not data then return end
    
    -- Try to get unit directly from hyperlink or other data
    local name = nil
    local unitToken = nil
    
    -- Try to get name from hyperlink
    if data.hyperlink then
        name = data.hyperlink:match("%[(.-)%]")
    end
    
    -- Try common unit tokens if name not found
    if not name then
        local tokens = {"mouseover", "target", "focus"}
        for _, token in ipairs(tokens) do
            if UnitExists(token) and UnitIsPlayer(token) then
                name = UnitName(token)
                if name then
                    unitToken = token
                    break
                end
            end
        end
    end
    
    if not name then return end
    
    -- Normalize name
    name = self:NormalizeName(name)
    
    -- Check if blacklisted
    if self:IsBlacklisted(name) then
        local entry = self:GetBlacklistEntry(name)
        if entry then
            self:AddBlacklistInfoToTooltip(tooltip, entry)
        end
    end
end

-- Legacy tooltip update method
function NA:UpdateTooltipLegacy(tooltip)
    if not self.db.profile.settings.tooltips then return end
    if not tooltip then return end
    
    local name, unit = tooltip:GetUnit()
    if not name then return end
    if not UnitIsPlayer(unit) then return end
    
    -- Normalize name
    name = self:NormalizeName(name)
    
    -- Check if blacklisted
    if self:IsBlacklisted(name) then
        local entry = self:GetBlacklistEntry(name)
        if entry then
            self:AddBlacklistInfoToTooltip(tooltip, entry)
        end
    end
end

-- Add blacklist information to tooltip
function NA:AddBlacklistInfoToTooltip(tooltip, entry)
    -- Add separator
    tooltip:AddLine(" ")
    
    -- Add blacklist header with icon
    tooltip:AddLine("|TInterface\\RaidFrame\\ReadyCheck-NotReady:16|t |cffff0000BLACKLISTED|r", 1, 0, 0, true)
    
    -- Add reason
    tooltip:AddDoubleLine("Reason:", entry.reason, 1, 1, 0, 1, 1, 1)
    
    -- Add notes if available
    if entry.notes and entry.notes ~= "" then
        tooltip:AddDoubleLine("Notes:", entry.notes, 0.7, 0.7, 0.7, 1, 1, 1)
    end
    
    -- Add date
    local dateStr = date("%Y-%m-%d", entry.dateAdded)
    tooltip:AddDoubleLine("Added:", dateStr, 0.5, 0.5, 0.5, 1, 1, 1)
    
    tooltip:Show()
end