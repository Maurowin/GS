-- NeverAgain UI
-- Unique and modern blacklist manager interface

local NA = NeverAgain

-- Predefined reasons
local REASONS = {
    "Toxic Behavior",
    "Rage Quit",
    "Ninja Looter",
    "AFK / Leeching",
    "Trolling",
    "Scammer",
    "Griefing",
    "Bad Performance",
    "Harassment",
    "Other"
}

function NA:InitializeUI()
    self:CreateMainWindow()
    self:CreateAddDialog()
end

-- Create modern main window with card layout
function NA:CreateMainWindow()
    -- Main frame with dark theme
    local frame = CreateFrame("Frame", "NeverAgainListFrame", UIParent, "BackdropTemplate")
    frame:SetSize(950, 650)
    frame:SetPoint("CENTER")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    frame:SetBackdropColor(0.05, 0.05, 0.05, 0.95)
    frame:SetBackdropBorderColor(0.8, 0.1, 0.1, 1)
    frame:Hide()
    
    -- Header bar with gradient
    local header = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    header:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, -4)
    header:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    header:SetHeight(50)
    header:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        tile = false
    })
    header:SetBackdropColor(0.15, 0.05, 0.05, 1)
    
    -- Title with icon
    local icon = header:CreateTexture(nil, "ARTWORK")
    icon:SetSize(32, 32)
    icon:SetPoint("LEFT", header, "LEFT", 15, 0)
    icon:SetTexture("Interface\\RaidFrame\\ReadyCheck-NotReady")
    
    local title = header:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("LEFT", icon, "RIGHT", 10, 0)
    title:SetText("|cffff3333Never|r|cffffffff Again|r")
    
    -- Stats in header
    local statsText = header:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    statsText:SetPoint("RIGHT", header, "RIGHT", -15, 0)
    statsText:SetText("0 blacklisted")
    statsText:SetTextColor(0.8, 0.8, 0.8)
    frame.statsText = statsText
    
    -- Action bar
    local actionBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    actionBar:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -5)
    actionBar:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, -5)
    actionBar:SetHeight(45)
    actionBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8X8",
        tile = false
    })
    actionBar:SetBackdropColor(0.1, 0.1, 0.1, 0.8)
    
    -- Add button with icon
    local addBtn = CreateFrame("Button", nil, actionBar, "UIPanelButtonTemplate")
    addBtn:SetSize(120, 32)
    addBtn:SetPoint("LEFT", actionBar, "LEFT", 10, 0)
    addBtn:SetText("|TInterface\\Buttons\\UI-PlusButton-Up:16|t Add")
    addBtn:SetScript("OnClick", function()
        self:ShowAddDialog()
    end)
    
    -- Clear all button
    local clearBtn = CreateFrame("Button", nil, actionBar, "UIPanelButtonTemplate")
    clearBtn:SetSize(100, 32)
    clearBtn:SetPoint("RIGHT", actionBar, "RIGHT", -10, 0)
    clearBtn:SetText("Clear All")
    clearBtn:GetFontString():SetTextColor(1, 0.3, 0.3)
    clearBtn:SetScript("OnClick", function()
        StaticPopupDialogs["NEVERAGAIN_CLEAR"] = {
            text = "Delete ALL blacklisted players?",
            button1 = "Yes, delete all",
            button2 = "Cancel",
            OnAccept = function() self:ClearBlacklist() end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
        }
        StaticPopup_Show("NEVERAGAIN_CLEAR")
    end)
    
    -- Search box
    local searchBox = CreateFrame("EditBox", nil, actionBar, "InputBoxTemplate")
    searchBox:SetSize(150, 30)
    searchBox:SetPoint("RIGHT", clearBtn, "LEFT", -15, 0)
    searchBox:SetAutoFocus(false)
    searchBox:SetTextInsets(10, 10, 3, 3)
    searchBox:SetScript("OnTextChanged", function(self)
        NA:FilterBlacklist(self:GetText())
    end)
    
    local searchLabel = actionBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    searchLabel:SetPoint("RIGHT", searchBox, "LEFT", -5, 0)
    searchLabel:SetText("Search:")
    searchLabel:SetTextColor(0.7, 0.7, 0.7)
    
    -- Scroll frame for cards
    local scrollFrame = CreateFrame("ScrollFrame", "NeverAgainScrollFrame", frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", actionBar, "BOTTOMLEFT", 10, -10)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -30, 45)
    
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(890, 1)
    scrollFrame:SetScrollChild(scrollChild)
    
    frame.scrollFrame = scrollFrame
    frame.scrollChild = scrollChild
    frame.searchBox = searchBox
    
    -- Close button
    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    
    self.listFrame = frame
end

-- Create card-style entry (unique design)
function NA:CreateCardEntry(parent, data, index)
    local card = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    card:SetSize(280, 140)
    card:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = false, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    card:SetBackdropColor(0.12, 0.12, 0.12, 0.95)
    card:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    
    -- Class-colored top bar
    local topBar = card:CreateTexture(nil, "BACKGROUND")
    topBar:SetPoint("TOPLEFT", card, "TOPLEFT", 3, -3)
    topBar:SetPoint("TOPRIGHT", card, "TOPRIGHT", -3, -3)
    topBar:SetHeight(4)
    
    if data.class and data.class ~= "UNKNOWN" then
        local classColor = RAID_CLASS_COLORS[data.class]
        if classColor then
            topBar:SetColorTexture(classColor.r, classColor.g, classColor.b, 1)
        else
            topBar:SetColorTexture(0.5, 0.5, 0.5, 1)
        end
    else
        topBar:SetColorTexture(0.5, 0.5, 0.5, 1)
    end
    
    -- Player name
    local nameText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    nameText:SetPoint("TOPLEFT", card, "TOPLEFT", 10, -15)
    nameText:SetWidth(260)
    nameText:SetJustifyH("LEFT")
    
    if data.class and data.class ~= "UNKNOWN" then
        local classColor = RAID_CLASS_COLORS[data.class]
        if classColor then
            nameText:SetTextColor(classColor.r, classColor.g, classColor.b)
        end
    end
    nameText:SetText(data.name)
    
    -- Realm
    local realmText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    realmText:SetPoint("TOPLEFT", nameText, "BOTTOMLEFT", 0, -2)
    realmText:SetText("|cff666666" .. (data.realm or "Unknown") .. "|r")
    
    -- Class name
    local classText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    classText:SetPoint("TOPLEFT", realmText, "BOTTOMLEFT", 0, -2)
    local className = self:GetLocalizedClass(data.class or "UNKNOWN")
    if data.class and data.class ~= "UNKNOWN" then
        local classColor = RAID_CLASS_COLORS[data.class]
        if classColor then
            classText:SetTextColor(classColor.r, classColor.g, classColor.b)
        end
    else
        classText:SetTextColor(0.6, 0.6, 0.6)
    end
    classText:SetText(className)
    
    -- Reason label
    local reasonLabel = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    reasonLabel:SetPoint("TOPLEFT", classText, "BOTTOMLEFT", 0, -6)
    reasonLabel:SetText("|cffffaa00Reason:|r")
    
    local reasonText = card:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    reasonText:SetPoint("TOPLEFT", reasonLabel, "BOTTOMLEFT", 0, -3)
    reasonText:SetWidth(260)
    reasonText:SetJustifyH("LEFT")
    reasonText:SetText("|cffff4444" .. (data.reason or "No reason") .. "|r")
    
    -- Date
    local dateText = card:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dateText:SetPoint("BOTTOMLEFT", card, "BOTTOMLEFT", 10, 28)
    dateText:SetText("|cff888888" .. date("%m/%d/%Y", data.dateAdded) .. "|r")
    
    -- Remove button
    local removeBtn = CreateFrame("Button", nil, card, "UIPanelButtonTemplate")
    removeBtn:SetSize(80, 22)
    removeBtn:SetPoint("BOTTOMRIGHT", card, "BOTTOMRIGHT", -8, 5)
    removeBtn:SetText("Remove")
    removeBtn:GetFontString():SetTextColor(1, 0.3, 0.3)
    removeBtn:SetScript("OnClick", function()
        self:RemoveFromBlacklist(data.fullName)
    end)
    
    -- Edit button
    local editBtn = CreateFrame("Button", nil, card, "UIPanelButtonTemplate")
    editBtn:SetSize(60, 22)
    editBtn:SetPoint("RIGHT", removeBtn, "LEFT", -5, 0)
    editBtn:SetText("Edit")
    editBtn:SetScript("OnClick", function()
        self:ShowEditDialog(data)
    end)
    
    -- Hover effect
    card:EnableMouse(true)
    card:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
    end)
    card:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    end)
    
    -- Tooltip
    card:SetScript("OnEnter", function(self)
        if data.notes and data.notes ~= "" then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(data.name, 1, 1, 1)
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Notes:", 1, 0.82, 0, true)
            GameTooltip:AddLine(data.notes, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    card:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)
    
    card:Show()
    return card
end

-- Update display with card grid
function NA:UpdateBlacklistDisplay(filter)
    if not self.listFrame then return end
    
    local scrollChild = self.listFrame.scrollChild
    
    -- Clear
    for i = scrollChild:GetNumChildren(), 1, -1 do
        local child = select(i, scrollChild:GetChildren())
        child:Hide()
        child:SetParent(nil)
    end
    
    -- Get blacklist
    local blacklist = self:GetBlacklistArray()
    
    -- Filter
    if filter and filter ~= "" then
        local filtered = {}
        filter = filter:lower()
        for _, entry in ipairs(blacklist) do
            if entry.name:lower():find(filter) or 
               (entry.reason and entry.reason:lower():find(filter)) or
               (entry.realm and entry.realm:lower():find(filter)) then
                table.insert(filtered, entry)
            end
        end
        blacklist = filtered
    end
    
    -- Update stats
    self.listFrame.statsText:SetText(#blacklist .. " blacklisted")
    
    -- Create cards in grid (3 columns)
    local cardsPerRow = 3
    local cardWidth = 285
    local cardHeight = 145
    local xPadding = 10
    local yPadding = 10
    
    for i, data in ipairs(blacklist) do
        local row = math.floor((i - 1) / cardsPerRow)
        local col = (i - 1) % cardsPerRow
        
        local card = self:CreateCardEntry(scrollChild, data, i)
        card:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 
            col * (cardWidth + xPadding), 
            -(row * (cardHeight + yPadding)))
    end
    
    -- Set scroll height
    local rows = math.ceil(#blacklist / cardsPerRow)
    scrollChild:SetHeight(math.max(1, rows * (cardHeight + yPadding)))
end

-- Filter blacklist
function NA:FilterBlacklist(text)
    self:UpdateBlacklistDisplay(text)
end

-- Create add dialog
function NA:CreateAddDialog()
    local dialog = CreateFrame("Frame", "NeverAgainAddDialog", UIParent, "BackdropTemplate")
    dialog:SetSize(450, 400)
    dialog:SetPoint("CENTER")
    dialog:SetFrameStrata("DIALOG")
    dialog:SetFrameLevel(100)
    dialog:SetMovable(true)
    dialog:EnableMouse(true)
    dialog:RegisterForDrag("LeftButton")
    dialog:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    dialog:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)
    dialog:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 32, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 }
    })
    dialog:SetBackdropColor(0.05, 0.05, 0.05, 0.98)
    dialog:SetBackdropBorderColor(0.8, 0.1, 0.1, 1)
    dialog:Hide()
    
    -- Title
    local title = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    title:SetPoint("TOP", 0, -20)
    title:SetText("|cffff3333Add to Blacklist|r")
    dialog.title = title
    
    -- Name
    local nameLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nameLabel:SetPoint("TOPLEFT", 30, -60)
    nameLabel:SetText("Player Name")
    nameLabel:SetTextColor(1, 0.82, 0)
    
    local nameInput = CreateFrame("EditBox", nil, dialog, "InputBoxTemplate")
    nameInput:SetSize(200, 30)
    nameInput:SetPoint("TOPLEFT", nameLabel, "BOTTOMLEFT", 5, -5)
    nameInput:SetAutoFocus(false)
    nameInput:SetTextInsets(10, 10, 3, 3)
    dialog.nameInput = nameInput
    
    -- Realm
    local realmLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    realmLabel:SetPoint("TOPLEFT", 250, -60)
    realmLabel:SetText("Realm")
    realmLabel:SetTextColor(1, 0.82, 0)
    
    local realmInput = CreateFrame("EditBox", nil, dialog, "InputBoxTemplate")
    realmInput:SetSize(150, 30)
    realmInput:SetPoint("TOPLEFT", realmLabel, "BOTTOMLEFT", 5, -5)
    realmInput:SetAutoFocus(false)
    realmInput:SetText(GetRealmName())
    realmInput:SetTextInsets(10, 10, 3, 3)
    dialog.realmInput = realmInput
    
    -- Reason dropdown
    local reasonLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    reasonLabel:SetPoint("TOPLEFT", 30, -130)
    reasonLabel:SetText("Reason")
    reasonLabel:SetTextColor(1, 0.82, 0)
    
    local reasonDropdown = CreateFrame("Frame", "NeverAgainReasonDropdown2", dialog, "UIDropDownMenuTemplate")
    reasonDropdown:SetPoint("TOPLEFT", reasonLabel, "BOTTOMLEFT", -15, -5)
    UIDropDownMenu_SetWidth(reasonDropdown, 200)
    UIDropDownMenu_SetText(reasonDropdown, REASONS[1])
    
    UIDropDownMenu_Initialize(reasonDropdown, function()
        for _, reason in ipairs(REASONS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = reason
            info.func = function(self)
                UIDropDownMenu_SetText(reasonDropdown, self:GetText())
                dialog.selectedReason = self:GetText()
            end
            UIDropDownMenu_AddButton(info)
        end
    end)
    dialog.reasonDropdown = reasonDropdown
    dialog.selectedReason = REASONS[1]
    
    -- Notes
    local notesLabel = dialog:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    notesLabel:SetPoint("TOPLEFT", 30, -195)
    notesLabel:SetText("Notes (optional)")
    notesLabel:SetTextColor(1, 0.82, 0)
    
    local notesScroll = CreateFrame("ScrollFrame", nil, dialog, "UIPanelScrollFrameTemplate")
    notesScroll:SetPoint("TOPLEFT", notesLabel, "BOTTOMLEFT", 5, -5)
    notesScroll:SetSize(380, 80)
    
    local notesBg = CreateFrame("Frame", nil, notesScroll, "BackdropTemplate")
    notesBg:SetAllPoints()
    notesBg:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = false, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 }
    })
    notesBg:SetBackdropColor(0.1, 0.1, 0.1, 1)
    
    local notesInput = CreateFrame("EditBox", nil, notesScroll)
    notesInput:SetMultiLine(true)
    notesInput:SetFontObject(ChatFontNormal)
    notesInput:SetWidth(360)
    notesInput:SetAutoFocus(false)
    notesInput:SetTextInsets(10, 10, 5, 5)
    notesScroll:SetScrollChild(notesInput)
    dialog.notesInput = notesInput
    
    -- Buttons
    local addBtn = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    addBtn:SetSize(100, 30)
    addBtn:SetPoint("BOTTOM", -55, 20)
    addBtn:SetText("Add")
    addBtn:SetScript("OnClick", function()
        local name = nameInput:GetText()
        local realm = realmInput:GetText()
        local reason = dialog.selectedReason
        local notes = notesInput:GetText()
        local detectedClass = dialog.detectedClass or "UNKNOWN"
        
        if name and name ~= "" then
            local fullName = name
            if realm and realm ~= "" then
                fullName = name .. "-" .. realm
            end
            
            if self:AddToBlacklistManual(fullName, reason, notes, detectedClass, false) then
                nameInput:SetText("")
                realmInput:SetText(GetRealmName())
                notesInput:SetText("")
                dialog.detectedClass = nil  -- Reset
                dialog:Hide()
            end
        end
    end)
    dialog.addBtn = addBtn
    
    local cancelBtn = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    cancelBtn:SetSize(100, 30)
    cancelBtn:SetPoint("BOTTOM", 55, 20)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetScript("OnClick", function()
        dialog:Hide()
    end)
    dialog.cancelBtn = cancelBtn
    
    self.addDialog = dialog
end

-- Manual add
function NA:AddToBlacklistManual(fullName, reason, notes, class, mute)
    local normalizedName = self:NormalizeName(fullName)
    if not normalizedName then
        self:Print("Unable to process player name.")
        return false
    end
    
    local realm = GetRealmName()  -- Default value
    local success, matchResult = pcall(function() return fullName:match("%-(.+)$") end)
    if success and matchResult then
        realm = matchResult
    end
    
    if self.db.profile.blacklist[fullName] then
        self:Print(normalizedName .. " is already blacklisted.")
        return false
    end
    
    -- Try to detect class if not provided
    local detectedClass = class
    if not detectedClass or detectedClass == "UNKNOWN" then
        -- Helper function to safely compare unit name
        local function SafeUnitNameMatch(unit, targetName)
            if not UnitExists(unit) then return false end
            local success, unitName = pcall(UnitName, unit)
            if not success then return false end
            local compareSuccess, isMatch = pcall(function() return unitName == targetName end)
            if not compareSuccess then return false end
            return isMatch
        end
        
        -- Check if player is nearby or in group
        if SafeUnitNameMatch("target", normalizedName) then
            local _, className = UnitClass("target")
            detectedClass = className
        elseif SafeUnitNameMatch("mouseover", normalizedName) then
            local _, className = UnitClass("mouseover")
            detectedClass = className
        else
            -- Check party members
            for i = 1, 4 do
                local unit = "party" .. i
                if SafeUnitNameMatch(unit, normalizedName) then
                    local _, className = UnitClass(unit)
                    detectedClass = className
                    break
                end
            end
            
            -- Check raid members if not found in party
            if not detectedClass and IsInRaid() then
                for i = 1, 40 do
                    local unit = "raid" .. i
                    if SafeUnitNameMatch(unit, normalizedName) then
                        local _, className = UnitClass(unit)
                        detectedClass = className
                        break
                    end
                end
            end
        end
    end
    
    self.db.profile.blacklist[fullName] = {
        name = normalizedName,
        fullName = fullName,
        realm = realm,
        reason = reason,
        notes = notes or "",
        dateAdded = time(),
        class = detectedClass or "UNKNOWN",
        muted = false,
    }
    
    self:Print(normalizedName .. " has been blacklisted.")
    
    if self.listFrame and self.listFrame:IsShown() then
        self:UpdateBlacklistDisplay()
    end
    
    return true
end

-- Show/hide
function NA:ToggleMainWindow()
    if not self.listFrame then
        self:CreateMainWindow()
    end
    
    if self.listFrame:IsShown() then
        self.listFrame:Hide()
    else
        self:UpdateBlacklistDisplay()
        self.listFrame:Show()
    end
end

function NA:ShowAddDialog()
    if not self.addDialog then
        self:CreateAddDialog()
    end
    self.addDialog:Show()
end

function NA:ShowEditDialog(data)
    if not self.addDialog then
        self:CreateAddDialog()
    end
    
    local dialog = self.addDialog
    
    -- Store original data
    dialog.editingData = data
    
    -- Fill fields
    dialog.nameInput:SetText(data.name)
    dialog.realmInput:SetText(data.realm or GetRealmName())
    UIDropDownMenu_SetText(dialog.reasonDropdown, data.reason)
    dialog.selectedReason = data.reason
    dialog.notesInput:SetText(data.notes or "")
    
    -- Change title and button
    dialog.title:SetText("|cff33ff33Edit Blacklist Entry|r")
    dialog.addBtn:SetText("Update")
    
    -- Change button action
    dialog.addBtn:SetScript("OnClick", function()
        local name = dialog.nameInput:GetText()
        local realm = dialog.realmInput:GetText()
        local reason = dialog.selectedReason
        local notes = dialog.notesInput:GetText()
        
        if name and name ~= "" then
            -- Remove old entry
            self:RemoveFromBlacklist(data.fullName)
            
            -- Add new one
            local fullName = name
            if realm and realm ~= "" then
                fullName = name .. "-" .. realm
            end
            
            if self:AddToBlacklistManual(fullName, reason, notes, data.class, false) then
                -- Restore Add mode
                dialog.editingData = nil
                dialog.title:SetText("|cffff3333Add to Blacklist|r")
                dialog.addBtn:SetText("Add")
                self:ResetAddDialogScript()
                
                dialog.nameInput:SetText("")
                dialog.realmInput:SetText(GetRealmName())
                dialog.notesInput:SetText("")
                dialog:Hide()
            end
        end
    end)
    
    dialog:Show()
end

-- Restore original Add button script
function NA:ResetAddDialogScript()
    local dialog = self.addDialog
    if not dialog then return end
    
    dialog.addBtn:SetScript("OnClick", function()
        local name = dialog.nameInput:GetText()
        local realm = dialog.realmInput:GetText()
        local reason = dialog.selectedReason
        local notes = dialog.notesInput:GetText()
        local detectedClass = dialog.detectedClass or "UNKNOWN"
        
        if name and name ~= "" then
            local fullName = name
            if realm and realm ~= "" then
                fullName = name .. "-" .. realm
            end
            
            if self:AddToBlacklistManual(fullName, reason, notes, detectedClass, false) then
                dialog.nameInput:SetText("")
                dialog.realmInput:SetText(GetRealmName())
                dialog.notesInput:SetText("")
                dialog.detectedClass = nil  -- Reset
                dialog:Hide()
            end
        end
    end)
end

-- Get localized class name
function NA:GetLocalizedClass(classFilename)
    if not classFilename or classFilename == "UNKNOWN" then return "Unknown" end
    
    -- Map of class filenames to localized names
    local classNames = {
        DEATHKNIGHT = "Death Knight",
        DEMONHUNTER = "Demon Hunter",
        DRUID = "Druid",
        EVOKER = "Evoker",
        HUNTER = "Hunter",
        MAGE = "Mage",
        MONK = "Monk",
        PALADIN = "Paladin",
        PRIEST = "Priest",
        ROGUE = "Rogue",
        SHAMAN = "Shaman",
        WARLOCK = "Warlock",
        WARRIOR = "Warrior"
    }
    
    return classNames[classFilename] or classFilename
end