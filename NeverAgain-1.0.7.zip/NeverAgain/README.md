# NeverAgain (NA) - Your Personal Blacklist Manager

**NeverAgain** is a modern, intuitive blacklist management tool for World of Warcraft. Stop wasting time with toxic players, ninja looters, or griefers. With a sleek interface and deep game integration, NeverAgain helps you keep track of your social experiences and ensures you don't group with the same problematic players twice.

***

## ✨ Key Features

### 📋 Advanced Player Management

*   **Detailed Entries:** Add players to your personal blacklist with specific reasons (Toxic, Ninja Looter, AFK, etc.) and custom notes.
*   **Modern UI:** A clean, card-based 3-column grid layout.
*   **Class Coloring:** Player names are automatically colored by their class for quick identification.
*   **Cross-Realm Support:** Fully functional detection and storage for players from other servers.

### 🔍 Seamless Integration

*   **Enhanced Tooltips:** View blacklist status, reasons, and notes directly on player tooltips (mouseover, target, or raid frames).
*   **Context Menus:** Right-click any name in chat or a unit frame to add them to your list instantly.
*   **Smart Search:** Real-time filtering to find specific entries in a large database.
*   **Minimap Icon:** Quick-access button with drag support and a right-click menu for target/focus management.

***

## 🛠 Slash Commands

*   `/na` or `/neveragain` — Toggle the main management window.
*   `/na add [name]` — Quick-add a player.
*   `/na remove [name]` — Quick-remove a player.
*   `/na minimap` — Toggle the minimap button.

***

## 📋 Predefined Reasons

NeverAgain includes one-click categorization for common issues:

*   Toxic Behavior
*   Ninja Looter
*   Rage Quit
*   AFK / Leeching
*   Trolling / Griefing
*   Scammer
*   Bad Performance
*   Harassment

***

**Remember**: This addon is for personal use to help you curate your gaming experience. Use it responsibly and avoid harassment of other players.

**Stay safe and enjoy your time in Azeroth!**