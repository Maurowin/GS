-- NeverAgain Group Scanner
-- Scans groups and LFG for blacklisted players

local NA = NeverAgain

function NA:InitializeGroupScanner()
    self.scannedPlayers = {}
end

-- Event handler for group roster updates
function NA:GROUP_ROSTER_UPDATE()
    self:ScanGroup()
end

-- Scan current group for blacklisted players
function NA:ScanGroup()
    if not IsInGroup() then 
        self.scannedPlayers = {}
        return 
    end
    
    local blacklistedInGroup = {}
    local groupType = IsInRaid() and "raid" or "party"
    local success, numMembers = pcall(GetNumGroupMembers)
    if not success or not numMembers then return end
    
    for i = 1, numMembers do
        local unit = groupType .. i
        if UnitExists(unit) then
            local success, name, realm = pcall(UnitName, unit)
            if success and name then
                local fullName = name
                if realm and realm ~= "" then
                    fullName = name .. "-" .. realm
                else
                    fullName = name .. "-" .. GetRealmName()
                end
                
                if self:IsBlacklisted(name) then
                    local entry = self:GetBlacklistEntry(name)
                    if entry and not self.scannedPlayers[fullName] then
                        table.insert(blacklistedInGroup, entry)
                        self.scannedPlayers[fullName] = true
                    end
                end
            end
        end
    end
    
    -- Also check player themselves
    local success, playerName = pcall(UnitName, "player")
    if success and playerName and not self:IsBlacklisted(playerName) then
        -- Player is OK
    end
    
    -- Show notification if any blacklisted players found
    if #blacklistedInGroup > 0 then
        self:ShowBlacklistedInGroupNotification(blacklistedInGroup)
    end
end

-- LFG Search results handler
function NA:LFG_LIST_SEARCH_RESULTS_RECEIVED()
    C_Timer.After(0.5, function()
        self:ScanLFGResults()
    end)
end

function NA:LFG_LIST_SEARCH_RESULT_UPDATED(_, resultID)
    C_Timer.After(0.1, function()
        self:ScanLFGResult(resultID)
    end)
end

-- Scan LFG results for blacklisted players
function NA:ScanLFGResults()
    if not self.db.profile.settings.queueIndicator then return end
    
    -- GetSearchResults returns the number of results, not a table
    local success, numResults = pcall(C_LFGList.GetSearchResults)
    if not success or not numResults or numResults == 0 then return end
    
    -- Iterate through results by index (1-based)
    for i = 1, numResults do
        -- GetSearchResultInfo takes an index and returns the resultID
        self:ScanLFGResult(i)
    end
end

-- Scan a single LFG result
function NA:ScanLFGResult(searchResultIndex)
    if not searchResultIndex then return end
    
    local success, searchResultInfo = pcall(C_LFGList.GetSearchResultInfo, searchResultIndex)
    if not success or not searchResultInfo then return end
    
    -- Check leader (using pcall to handle tainted values safely)
    local success, leaderName = pcall(function() return searchResultInfo.leaderName end)
    if success and leaderName then
        local name = self:NormalizeName(leaderName)
        if name and self:IsBlacklisted(name) then
            self:MarkLFGResultAsBlacklisted(searchResultIndex)
            return
        end
    end
    
    -- Check members (using tonumber to clean taint)
    local successNum, numMembersRaw = pcall(function() return searchResultInfo.numMembers end)
    if successNum and numMembersRaw then
        -- Convert to clean number to avoid taint comparison issues
        local numMembers = tonumber(tostring(numMembersRaw)) or 0
        if numMembers > 0 then
            for i = 1, numMembers do
                local successMember, memberInfo = pcall(C_LFGList.GetSearchResultMemberInfo, searchResultIndex, i)
                if successMember and memberInfo then
                    local successName, memberName = pcall(function() return memberInfo.name end)
                    if successName and memberName then
                        local name = self:NormalizeName(memberName)
                        if name and self:IsBlacklisted(name) then
                            self:MarkLFGResultAsBlacklisted(searchResultIndex)
                            return
                        end
                    end
                end
            end
        end
    end
end

-- Mark LFG result as containing blacklisted player
function NA:MarkLFGResultAsBlacklisted(resultID)
    -- This would require hooking into the LFG frame buttons
    -- We'll add a visual indicator using a simple overlay
    
    -- Find the LFG result button
    local LFGListFrame = LFGListFrame
    if not LFGListFrame or not LFGListFrame.SearchPanel or not LFGListFrame.SearchPanel.results then
        return
    end
    
    for i, button in ipairs(LFGListFrame.SearchPanel.results) do
        if button.resultID == resultID then
            -- Add red overlay or indicator
            if not button.blacklistIndicator then
                local indicator = button:CreateTexture(nil, "OVERLAY")
                indicator:SetColorTexture(1, 0, 0, 0.3)
                indicator:SetAllPoints(button)
                button.blacklistIndicator = indicator
                
                -- Add warning icon
                local icon = button:CreateTexture(nil, "OVERLAY")
                icon:SetTexture("Interface\\RaidFrame\\ReadyCheck-NotReady")
                icon:SetSize(20, 20)
                icon:SetPoint("LEFT", button, "LEFT", 5, 0)
                button.blacklistIcon = icon
            end
            
            if button.blacklistIndicator then
                button.blacklistIndicator:Show()
                button.blacklistIcon:Show()
            end
        end
    end
end

-- Hook into LFG tooltips
function NA:HookLFGTooltips()
    -- Hook GameTooltip to show warning on LFG entries
    GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
        local name, unit = tooltip:GetUnit()
        if name and self:IsBlacklisted(name) then
            local entry = self:GetBlacklistEntry(name)
            if entry then
                tooltip:AddLine(" ")
                tooltip:AddLine("|cffff0000[BLACKLISTED]|r", 1, 0, 0)
                tooltip:AddLine("Reason: " .. entry.reason, 1, 1, 0)
                if entry.notes and entry.notes ~= "" then
                    tooltip:AddLine("Notes: " .. entry.notes, 0.7, 0.7, 0.7)
                end
                tooltip:Show()
            end
        end
    end)
end

-- Monitor group invites
hooksecurefunc("StaticPopup_Show", function(which, text)
    if which == "PARTY_INVITE" or which == "PARTY_INVITE_XREALM" then
        -- Extract player name from invite text
        local name = text and text:match("^(.+) has invited you")
        if name then
            name = NA:NormalizeName(name)
            if name and NA:IsBlacklisted(name) then
                local entry = NA:GetBlacklistEntry(name)
                if entry then
                    NA:ShowNotification("⚠ WARNING: " .. name .. " is on your blacklist! (" .. entry.reason .. ")", {r=1, g=0, b=0})
                end
            end
        end
    end
end)
