# CrossIgnore

## [v12.0.25](https://github.com/LoyalFTW/CrossIgnore/tree/v12.0.25) (2026-05-20)
[Full Changelog](https://github.com/LoyalFTW/CrossIgnore/compare/v12.0.24...v12.0.25) [Previous Releases](https://github.com/LoyalFTW/CrossIgnore/releases)

- Update options.lua  
    * Fixed options error  
