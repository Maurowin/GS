﻿local addonName = "BlackListTBC"
local BL = { L = {} }

-- ==========================================
-- 🌍 ЛОКАЛИЗАЦИЯ
-- ==========================================
local L = BL.L
L["enUS"] = {
    title = "BlackList TBC — Version 12.0.0",
    h_idx = "#", h_name = "NAME", h_date = "DATE", h_reason = "REASON", h_hide = "HIDE CHAT", h_del = "DELETE",
    add = "Add", hint_n = "Name...", hint_r = "Reason...",
    m_desc = "|cff00ff00LMB:|r Settings\n|cff00ff00RMB:|r Sync Toggle",
    sync_on = "Sync: |cff00ff00ON|r", sync_off = "Sync: |cffff0000OFF|r",
    guild_ann = "[BlackList] %s added. Reason: %s",
    guild_ann_colored = "|cff00ff00[BlackList]|r |cffff0000%s|r added. Reason: |cffffcc00%s|r",
    detected_local = "|cff808080[BlackList] Player found nearby: %s|r",
    detected_whisper = "|cff808080[BlackList] Whisper received from: %s|r",
    added_local = "|cff00ff00[BlackList] Player %s successfully added/updated.|r",
    declined = "[BlackList] Auto-declined invite from: %s",
    warning = "!!! BLACKLISTED !!!",
    alert_msg = "[BlackList Warning]: Detected player <%s> from the blacklist! Date: %s. Reason: %s",
    alert_proof = "[BlackListTBC]_PROOF(link): %s",
    update_btn = "Up GL list",
    update_cooldown = "Update available no more than once every 30 minutes of game time.",
    update_cooldown_remaining = "Time remaining: %d min.",
    update_wrong_realm = "Global lists are only available for Spineshatter and Thunderstrike realms.",
    update_complete = "Global list updated to version %s. Added new players: %d, updated proof for existing players: %d.",
    update_already = "Global list is already up to date (version %s).",
    update_file_not_found = "File %s loaded but does not contain list data.\nExpected variable '%s' with 'case_table' or 'list'.\nPlease check the file: all 't.' should be renamed to '%s.'",
    update_file_missing = "File %s not found.\nPlease place the file in the addon folder.",
    confirm_title = "Confirm global list update",
    confirm_text = "WARNING! Are you sure you want to load the global blacklist?",
    confirm_yes = "Yes",
    confirm_no = "No",
    migrate_old_data = "Old blacklist data migrated to realm %s.",
    move_hint = "|cffcc5500Left mouse button drag to move around minimap|r",
}

L["ruRU"] = {
    title = "BlackList TBC — Version 12.0.0",
    h_idx = "#", h_name = "ИМЯ", h_date = "ДАТА", h_reason = "ПРИЧИНА", h_hide = "СКРЫТЬ ЧАТ", h_del = "УДАЛИТЬ",
    add = "Добавить", hint_n = "Имя...", hint_r = "Причина...",
    m_desc = "|cff00ff00ЛКМ:|r Настройки\n|cff00ff00ПКМ:|r Синхронизация",
    sync_on = "Синхронизация: |cff00ff00ВКЛ|r", sync_off = "Синхронизация: |cffff0000ВЫКЛ|r",
    guild_ann = "[BlackList] %s добавлен в ЧС. Причина: %s",
    guild_ann_colored = "|cff00ff00[BlackList]|r |cffff0000%s|r добавлен в ЧС. Причина: |cffffcc00%s|r",
    detected_local = "|cff808080[BlackList] Игрок из черного списка обнаружен: %s|r",
    detected_whisper = "|cff808080[BlackList] Личное сообщение от игрока: %s|r",
    added_local = "|cff00ff00[BlackList] Игрок %s успешно добавлен/обновлен.|r",
    declined = "[BlackList] Авто-отклонение приглашения от: %s",
    warning = "!!! В ЧЕРНОМ СПИСКЕ !!!",
    alert_msg = "[BlackList Warning]: Обнаружен игрок <%s> из черного списка! Дата: %s. Причина: %s",
    alert_proof = "[BlackListTBC]_PROOF(link): %s",
    update_btn = "Up GL list",
    update_cooldown = "Обновление доступно не чаще чем раз в 30 минут игрового времени.",
    update_cooldown_remaining = "Осталось: %d мин.",
    update_wrong_realm = "Глобальные списки доступны только для серверов Spineshatter и Thunderstrike.",
    update_complete = "Глобальный список обновлён до версии %s. Добавлено новых игроков: %d, обновлено proof у существующих: %d.",
    update_already = "Глобальный список уже актуален (версия %s).",
    update_file_not_found = "Файл %s загружен, но не содержит данных списка.\nОжидается переменная '%s' с полем 'case_table' или 'list'.\nПроверьте файл: все 't.' должны быть заменены на '%s.'",
    update_file_missing = "Файл %s не найден.\nПоместите файл в папку аддона.",
    confirm_title = "Подтверждение обновления глобального списка",
    confirm_text = "ОСТОРОЖНО! Вы точно хотите загрузить глобальную версию игроков, которых добавили в Черный список?",
    confirm_yes = "Да",
    confirm_no = "Нет",
    migrate_old_data = "Старый чёрный список перенесён на сервер %s.",
    move_hint = "|cffcc5500Зажмите левую кнопку мыши для перемещения по карте|r",
}

setmetatable(L, { __index = function(t, k) return t["enUS"] end })
local function GetL()
    local db = BlackListTBC_DB
    return L[(db and db.lang) or "ruRU"]
end

-- ==========================================
-- ⚙️ ЯДРО И БАЗА (раздельные списки по серверам)
-- ==========================================
local function InitDB()
    if not BlackListTBC_DB then
        BlackListTBC_DB = { lang = "ruRU", sync = true, servers = {} }
    end
    if not BlackListTBC_DB.servers then
        BlackListTBC_DB.servers = {}
    end
    return BlackListTBC_DB
end

local function NormalizeRealmName(realm)
    if not realm then return nil end
    local normalized = string.lower(string.gsub(realm, "%s+", ""))
    if normalized == "thunderstrike" then return "Thunderstrike"
    elseif normalized == "spineshatter" then return "Spineshatter"
    else return nil end
end

local function GetCurrentRealm()
    local realm = GetRealmName()
    if not realm then return nil end
    return NormalizeRealmName(realm)
end

local function GetCurrentServerData()
    local realm = GetCurrentRealm()
    if not realm then
        realm = "Default"
    end
    local db = InitDB()
    if not db.servers[realm] then
        db.servers[realm] = { list = {}, removed = {}, globalListVersion = nil, lastRefreshTime = nil }
    end
    return db.servers[realm]
end

local function MigrateOldData()
    local db = InitDB()
    local currentRealm = GetCurrentRealm()
    if not currentRealm then currentRealm = "Default" end
    if db.list and #db.list > 0 then
        if not db.servers[currentRealm] then
            db.servers[currentRealm] = { list = {}, removed = {}, globalListVersion = nil, lastRefreshTime = nil }
        end
        for _, v in ipairs(db.list) do
            table.insert(db.servers[currentRealm].list, v)
        end
        if db.removed then
            db.servers[currentRealm].removed = db.removed
        end
        if db.globalListVersion then
            db.servers[currentRealm].globalListVersion = db.globalListVersion
        end
        if db.lastRefreshTime then
            db.servers[currentRealm].lastRefreshTime = db.lastRefreshTime
        end
        print("|cff00ff00[BlackList]|r " .. string.format(GetL().migrate_old_data, currentRealm))
        db.list = nil
        db.removed = nil
        db.globalListVersion = nil
        db.lastRefreshTime = nil
    end
end

local function GetClassColor(name, class)
    if class and RAID_CLASS_COLORS[class] then
        local c = RAID_CLASS_COLORS[class]
        return string.format("|cff%02x%02x%02x%s|r", c.r*255, c.g*255, c.b*255, name)
    end
    return "|cffffffff"..name.."|r"
end

local function GetBLPlayer(name)
    if not name then return nil end
    local serverData = GetCurrentServerData()
    if not serverData then return nil end
    for _, v in ipairs(serverData.list) do
        if v.name == name then return v end
    end
    return nil
end

-- ==========================================
-- ➕ ЕДИНАЯ ФУНКЦИЯ ДОБАВЛЕНИЯ
-- ==========================================
function AddPlayer(name, reason, syncMode)
    if not name or name == "" then return false end
    local serverData = GetCurrentServerData()
    if not serverData then return false end
    name = name:gsub("^%l", string.upper)
    reason = (reason == nil or reason == "" or reason == GetL().hint_r) and "-" or reason

    if syncMode and serverData.removed and serverData.removed[name] then
        return false
    end

    if not syncMode and serverData.removed then
        serverData.removed[name] = nil
    end

    local existingIdx = nil
    for i, v in ipairs(serverData.list) do
        if v.name == name then
            existingIdx = i
            break
        end
    end

    if existingIdx then
        serverData.list[existingIdx].reason = reason
        serverData.list[existingIdx].date = date("%d.%m.%y")
        local entry = table.remove(serverData.list, existingIdx)
        table.insert(serverData.list, 1, entry)
    else
        local _, class = UnitClass(name)
        table.insert(serverData.list, 1, { name = name, date = date("%d.%m.%y"), reason = reason, hide = false, class = class })
    end

    if not syncMode then
        local sl = GetL()
        local db = InitDB()
        if db.sync and IsInGuild() then
            SendChatMessage(sl.guild_ann:format(name, reason), "GUILD")
            local coloredName = GetClassColor(name, (existingIdx and serverData.list[1].class) or nil)
            SendChatMessage(string.format(sl.guild_ann_colored, coloredName, reason), "GUILD")
            C_ChatInfo.SendAddonMessage("BLTBC_V7", "ADD:" .. name .. ":" .. reason, "GUILD")
        else
            print(sl.added_local:format(name))
        end
    end

    if Main and Main.UpdateList and Main:IsShown() then
        Main:UpdateList()
    end
    return true
end

-- ==========================================
-- 🚨 ОЧЕРЕДЬ ОПОВЕЩЕНИЙ В ГРУППУ/РЕЙД
-- ==========================================
local alertQueue = {}
local isProcessingQueue = false
local announcedThisSession = {}

local function ProcessAlertQueue()
    if #alertQueue == 0 then
        isProcessingQueue = false
        return
    end
    isProcessingQueue = true
    local data = table.remove(alertQueue, 1)
    if IsInGroup() then
        local channel = IsInRaid() and "RAID" or "PARTY"
        SendChatMessage(data, channel)
    end
    C_Timer.After(4, ProcessAlertQueue)
end

local function CheckGroupForBlacklist()
    if not IsInGroup() then
        announcedThisSession = {}
        return
    end
    local serverData = GetCurrentServerData()
    if not serverData then return end
    local prefix = IsInRaid() and "raid" or "party"
    for i = 1, GetNumGroupMembers() do
        local name = GetUnitName(prefix .. i, true)
        if name then
            name = name:match("([^%-]+)")
            if not announcedThisSession[name] then
                local data = GetBLPlayer(name)
                if data then
                    local sl = GetL()
                    local msg = sl.alert_msg:format(data.name, data.date, data.reason)
                    table.insert(alertQueue, msg)
                    if not isProcessingQueue then
                        ProcessAlertQueue()
                    end
                    announcedThisSession[name] = true
                    -- Отправляем proof отдельным сообщением, если есть
                    if data.proof and data.proof ~= "" then
                        local proofMsg = sl.alert_proof:format(data.proof)
                        table.insert(alertQueue, proofMsg)
                        if not isProcessingQueue then
                            ProcessAlertQueue()
                        end
                    end
                end
            end
        end
    end
end

-- ==========================================
-- 🛡️ ФИЛЬТРЫ ЧАТА И ТУЛТИП
-- ==========================================
local function BlackListChatFilter(self, event, msg, author, ...)
    local name = author and author:match("([^%-]+)")
    local data = GetBLPlayer(name)

    if data then
        if data.hide then return true end
        msg = "|cff808080[BlackList] " .. msg .. "|r"
        return false, msg, author, ...
    end
    return false, msg, author, ...
end

local chatEvents = {
    "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_WHISPER", "CHAT_MSG_PARTY",
    "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_GUILD", "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE", "CHAT_MSG_CHANNEL"
}
for _, e in ipairs(chatEvents) do
    ChatFrame_AddMessageEventFilter(e, BlackListChatFilter)
end

local function SystemMsgFilter(self, event, msg)
    local serverData = GetCurrentServerData()
    if not serverData then return false end
    for _, v in ipairs(serverData.list) do
        if v.hide and msg:find(v.name) then
            if msg:find("приглашает") or msg:find("обменяться") or msg:find("invites") or msg:find("trade") then
                return true
            end
        end
    end
    return false
end
ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", SystemMsgFilter)

GameTooltip:HookScript("OnTooltipSetUnit", function(self)
    local _, u = self:GetUnit()
    if u and UnitIsPlayer(u) then
        local data = GetBLPlayer(UnitName(u))
        if data then
            self:AddLine(" ")
            self:AddLine("|cffff0000" .. GetL().warning .. "|r")
            self:AddLine("|cffffffff" .. GetL().h_reason .. ": " .. data.reason .. "|r")
            self:AddLine("|cffaaaaaa" .. GetL().h_date .. ": " .. data.date .. "|r")
            if data.proof and data.proof ~= "" then
                self:AddLine("|cffffcc00Proof:|r " .. data.proof)
            end
            self:Show()
        end
    end
end)

-- ==========================================
-- 🖥️ ИНТЕРФЕЙС
-- ==========================================
local Main = CreateFrame("Frame", "BLTBC_MainFrame", UIParent, "BackdropTemplate")
Main:SetSize(680, 520); Main:SetPoint("CENTER"); Main:SetFrameStrata("HIGH")
Main:SetMovable(true); Main:EnableMouse(true); Main:RegisterForDrag("LeftButton")
Main:SetScript("OnDragStart", Main.StartMoving); Main:SetScript("OnDragStop", Main.StopMovingOrSizing)
Main:SetBackdrop({ bgFile = "Interface\\ChatFrame\\ChatFrameBackground", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 8, right = 8, top = 8, bottom = 8 } })
Main:SetBackdropColor(0, 0, 0, 0.95); Main:Hide()
tinsert(UISpecialFrames, "BLTBC_MainFrame")

local CloseBtn = CreateFrame("Button", nil, Main, "UIPanelCloseButton")
CloseBtn:SetPoint("TOPRIGHT", -5, -5)
CloseBtn:SetScript("OnClick", function()
    Main:Hide()
    ForceClearInputs()
end)

local titleText = Main:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
titleText:SetPoint("TOP", 0, -16)
titleText:SetText("|cffff0000" .. GetL().title .. "|r")

-- Поле поиска
local searchBox = CreateFrame("EditBox", nil, Main, "InputBoxTemplate")
searchBox:SetSize(200, 30)
searchBox:SetPoint("TOP", 0, -45)
searchBox:SetAutoFocus(false)
local SEARCH_PLACEHOLDER = "Search for player"
searchBox:SetText(SEARCH_PLACEHOLDER)
searchBox:SetTextColor(0.5, 0.5, 0.5)

local searchFilter = ""

searchBox:SetScript("OnEditFocusGained", function(self)
    if self:GetText() == SEARCH_PLACEHOLDER then
        self:SetText("")
        self:SetTextColor(1, 1, 1)
    end
end)

searchBox:SetScript("OnEditFocusLost", function(self)
    if self:GetText() == "" then
        self:SetText(SEARCH_PLACEHOLDER)
        self:SetTextColor(0.5, 0.5, 0.5)
        searchFilter = ""
        Main:UpdateList()
    end
end)

searchBox:SetScript("OnTextChanged", function(self)
    local text = self:GetText()
    if text == SEARCH_PLACEHOLDER or text == "" then
        searchFilter = ""
    else
        searchFilter = string.lower(text)
    end
    Main:UpdateList()
end)

local function CreateHeader(text, x, width)
    local h = Main:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", x, -85); h:SetWidth(width); h:SetJustifyH("LEFT"); h:SetText(text)
    return h
end
Main.hIdx = CreateHeader("#", 25, 30)
Main.hName = CreateHeader("NAME", 60, 110)
Main.hDate = CreateHeader("DATE", 180, 80)
Main.hReason = CreateHeader("REASON", 280, 200)
Main.hHide = CreateHeader("HIDE CHAT", 480, 80)
Main.hDel = CreateHeader("DELETE", 570, 60)

local rows = {}
for i=1, 13 do
    local r = CreateFrame("Frame", nil, Main, "BackdropTemplate")
    r:SetSize(610, 28); r:SetPoint("TOPLEFT", 20, -105 - (i-1)*29)
    r:SetBackdrop({bgFile = "Interface\\Tooltips\\UI-Tooltip-Background"}); r:SetBackdropColor(1, 1, 1, 0.05)

    r.tIdx = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall"); r.tIdx:SetPoint("LEFT", 5, 0); r.tIdx:SetWidth(30)
    r.tName = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); r.tName:SetPoint("LEFT", 40, 0); r.tName:SetWidth(110); r.tName:SetJustifyH("LEFT")
    r.tDate = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.tDate:SetPoint("LEFT", 160, 0); r.tDate:SetWidth(80); r.tDate:SetJustifyH("LEFT")
    r.tReason = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall"); r.tReason:SetPoint("LEFT", 260, 0); r.tReason:SetWidth(190); r.tReason:SetJustifyH("LEFT")

    r.hideCB = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
    r.hideCB:SetSize(24, 24); r.hideCB:SetPoint("LEFT", 485, 0)
    r.hideCB:SetScript("OnClick", function(self)
        local serverData = GetCurrentServerData()
        if serverData and serverData.list[r.idx] then
            serverData.list[r.idx].hide = self:GetChecked()
        end
    end)

    r.del = CreateFrame("Button", nil, r, "UIPanelButtonTemplate")
    r.del:SetSize(24, 24); r.del:SetPoint("LEFT", 565, 0); r.del:SetText("x")
    r.del:SetScript("OnClick", function()
        local serverData = GetCurrentServerData()
        if not serverData or not r.entry then return end
        local player = r.entry
        if player then
            if not serverData.removed then serverData.removed = {} end
            serverData.removed[player.name] = true
        end
        for i, v in ipairs(serverData.list) do
            if v == player then
                table.remove(serverData.list, i)
                break
            end
        end
        Main:UpdateList()
    end)
    rows[i] = r
end

function Main:UpdateList()
    local serverData = GetCurrentServerData()
    if not serverData or not serverData.list then return end
    local filtered = {}
    if searchFilter == "" then
        filtered = serverData.list
    else
        for _, v in ipairs(serverData.list) do
            if string.find(string.lower(v.name), searchFilter, 1, true) then
                table.insert(filtered, v)
            end
        end
    end
    
    FauxScrollFrame_Update(BLTBC_Scroll, #filtered, 13, 29)
    local offset = FauxScrollFrame_GetOffset(BLTBC_Scroll)
    for i=1, 13 do
        local idx = offset + i
        if idx <= #filtered then
            local d = filtered[idx]
            rows[i].idx = idx
            rows[i].entry = d
            rows[i].tIdx:SetText(#filtered - idx + 1)
            rows[i].tName:SetText(GetClassColor(d.name, d.class))
            rows[i].tDate:SetText(d.date); rows[i].tReason:SetText(d.reason)
            rows[i].hideCB:SetChecked(d.hide)
            rows[i]:Show()
        else rows[i]:Hide() end
    end
end

local Scroll = CreateFrame("ScrollFrame", "BLTBC_Scroll", Main, "FauxScrollFrameTemplate")
Scroll:SetPoint("TOPLEFT", 15, -105)
Scroll:SetPoint("BOTTOMRIGHT", -45, 140)
Scroll:SetScript("OnVerticalScroll", function(self, offset)
    FauxScrollFrame_OnVerticalScroll(self, offset, 29, function() Main:UpdateList() end)
end)

local function CreateInput(parent, width, x, mode)
    local eb = CreateFrame("EditBox", nil, parent, "InputBoxTemplate")
    eb:SetSize(width, 30)
    eb:SetPoint("BOTTOMLEFT", x, 12)
    eb:SetAutoFocus(false)
    eb:SetScript("OnEditFocusGained", function(self)
        local hint = (mode == "n") and GetL().hint_n or GetL().hint_r
        if self:GetText() == hint then self:SetText(""); self:SetTextColor(1, 1, 1) end
    end)
    eb:SetScript("OnEditFocusLost", function(self)
        if self:GetText() == "" then
            local hint = (mode == "n") and GetL().hint_n or GetL().hint_r
            self:SetText(hint); self:SetTextColor(0.5, 0.5, 0.5)
        end
    end)
    return eb
end

local nInp = CreateInput(Main, 140, 30, "n"); nInp:SetMaxLetters(16)
local rInp = CreateInput(Main, 240, 185, "r"); rInp:SetMaxLetters(35)

local AddBtn = CreateFrame("Button", nil, Main, "UIPanelButtonTemplate")
AddBtn:SetSize(100, 30)
AddBtn:SetPoint("LEFT", rInp, "RIGHT", 15, 0)
AddBtn:SetText(GetL().add)
AddBtn:SetScript("OnClick", function()
    local nameText = nInp:GetText()
    local reasonText = rInp:GetText()
    local added = AddPlayer(nameText, reasonText, false)
    if added then
        ForceClearInputs()
        C_Timer.After(0.05, ForceClearInputs)
        C_Timer.After(0.1, ForceClearInputs)
        C_Timer.After(0.2, ForceClearInputs)
        if Main:IsShown() then Main:UpdateList() end
    end
end)

local function ForceClearInputs()
    nInp:ClearFocus()
    rInp:ClearFocus()
    nInp:SetText("")
    rInp:SetText("")
    nInp:SetTextColor(0.5, 0.5, 0.5)
    rInp:SetTextColor(0.5, 0.5, 0.5)
    nInp:SetFocus(false)
    rInp:SetFocus(false)
    local sl = GetL()
    if nInp:GetText() == "" then
        nInp:SetText(sl.hint_n)
        nInp:SetTextColor(0.5, 0.5, 0.5)
    end
    if rInp:GetText() == "" then
        rInp:SetText(sl.hint_r)
        rInp:SetTextColor(0.5, 0.5, 0.5)
    end
end

Main:SetScript("OnShow", function()
    ForceClearInputs()
    if searchBox:GetText() == SEARCH_PLACEHOLDER then
        searchFilter = ""
    else
        local text = searchBox:GetText()
        if text == "" or text == SEARCH_PLACEHOLDER then
            searchFilter = ""
        else
            searchFilter = string.lower(text)
        end
    end
    Main:UpdateList()
end)
Main:SetScript("OnHide", function()
    ForceClearInputs()
end)

local function RefreshUI()
    local sl = GetL()
    titleText:SetText("|cffff0000" .. sl.title .. "|r")
    Main.hIdx:SetText(sl.h_idx); Main.hName:SetText(sl.h_name); Main.hDate:SetText(sl.h_date)
    Main.hReason:SetText(sl.h_reason); Main.hHide:SetText(sl.h_hide); Main.hDel:SetText(sl.h_del)
    AddBtn:SetText(sl.add); nInp:SetText(sl.hint_n); rInp:SetText(sl.hint_r)
    nInp:SetTextColor(0.5, 0.5, 0.5); rInp:SetTextColor(0.5, 0.5, 0.5)
end

local LangBtn = CreateFrame("Button", nil, Main, "UIPanelButtonTemplate")
LangBtn:SetSize(50, 22); LangBtn:SetPoint("TOPLEFT", 15, -15); LangBtn:SetText("LNG")
LangBtn:SetScript("OnClick", function()
    local db = InitDB()
    db.lang = (db.lang == "ruRU") and "enUS" or "ruRU"
    RefreshUI(); Main:UpdateList()
end)

-- ==========================================
-- ⚙️ СКАНЕР, СОБЫТИЯ И СИНХРОНИЗАЦИЯ
-- ==========================================
Main:RegisterEvent("UNIT_SPELLCAST_START")
Main:SetScript("OnEvent", function(self, event, unit)
    if event == "UNIT_SPELLCAST_START" and unit == "player" then Main:Hide() end
end)

local scanCache = {}
C_Timer.NewTicker(2, function()
    local units = {"target", "mouseover"}
    for i=1, 40 do table.insert(units, "raid"..i); table.insert(units, "party"..i) end
    for _, u in ipairs(units) do
        local name = UnitName(u); local data = GetBLPlayer(name)
        if data then
            local now = GetTime()
            if not scanCache[name] or (now - scanCache[name] > 80) then
                print(GetL().detected_local:format(GetClassColor(name, data.class)))
                scanCache[name] = now
            end
            if (UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")) and GetRaidTargetIndex(u) ~= 7 then
                SetRaidTarget(u, 7)
            end
        end
    end
end)

-- Proof для мыши/таргета (локально)
local proofCache = {}
C_Timer.NewTicker(2, function()
    local units = {"target", "mouseover"}
    for _, u in ipairs(units) do
        local name = UnitName(u)
        if name then
            local data = GetBLPlayer(name)
            if data and data.proof and data.proof ~= "" then
                local now = GetTime()
                if not proofCache[name] or (now - proofCache[name] > 80) then
                    print("|cffffcc00Proof:|r " .. data.proof)
                    proofCache[name] = now
                end
            end
        end
    end
end)

-- ==========================================
-- 🧭 ПЕРЕТАСКИВАЕМАЯ КНОПКА ВОКРУГ МИНИКАРТЫ (левая кнопка мыши, мягкий оранжевый цвет)
-- ==========================================
local MBtn = CreateFrame("Button", "BLTBC_Minimap", Minimap)
MBtn:SetSize(31, 31)
MBtn:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

local icon = MBtn:CreateTexture(nil, "BACKGROUND")
icon:SetSize(20, 20)
icon:SetTexture("Interface\\Icons\\Spell_Shadow_FingerOfDeath")
icon:SetPoint("CENTER")

-- Параметры позиции
local radius = 80                -- расстояние от центра миникарты
local angle = 0                  -- текущий угол (в радианах)

-- Загрузка сохранённого угла
local db = InitDB()
if db.minimapButtonAngle then
    angle = db.minimapButtonAngle
else
    -- Начальный угол, соответствующий точке TOPLEFT (52, -20)
    angle = math.atan2(52, -20)   -- приблизительно 1.94 радиана
end

-- Функция обновления позиции кнопки
local function UpdateButtonPosition()
    local x = math.sin(angle) * radius
    local y = math.cos(angle) * radius
    MBtn:SetPoint("CENTER", Minimap, "CENTER", x, y)
end
UpdateButtonPosition()

-- Переменные для перетаскивания (левая кнопка)
local dragging = false
local startAngle, startX

MBtn:SetScript("OnMouseDown", function(self, button)
    if button == "LeftButton" then
        dragging = true
        startX = GetCursorPosition()
        startAngle = angle
        self:SetScript("OnUpdate", function(self)
            if not dragging then return end
            local curX = GetCursorPosition()
            local dx = curX - startX
            local newAngle = startAngle + dx * 0.005   -- чувствительность
            -- Нормализация угла в [0, 2π)
            while newAngle < 0 do newAngle = newAngle + 2 * math.pi end
            while newAngle > 2 * math.pi do newAngle = newAngle - 2 * math.pi end
            angle = newAngle
            UpdateButtonPosition()
        end)
    end
end)

MBtn:SetScript("OnMouseUp", function(self, button)
    if button == "LeftButton" then
        dragging = false
        self:SetScript("OnUpdate", nil)
        -- Сохраняем угол в БД
        local db = InitDB()
        db.minimapButtonAngle = angle
    end
end)

-- Клики (левая кнопка) – сработают только при быстром отпускании без движения
MBtn:RegisterForClicks("LeftButtonUp", "RightButtonUp")
MBtn:SetScript("OnClick", function(self, b)
    if b == "LeftButton" then
        -- Если не было перетаскивания, открываем/закрываем окно
        if not dragging then
            local db = InitDB()
            if Main:IsShown() then
                Main:Hide()
                ForceClearInputs()
            else
                ForceClearInputs()
                Main:Show()
                Main:UpdateList()
            end
        end
    else
        -- Правая кнопка (синхронизация) – оставляем как было
        local db = InitDB()
        db.sync = not db.sync
        print(db.sync and GetL().sync_on or GetL().sync_off)
    end
end)

-- Тултип с подсказкой (мягкий оранжевый цвет)
MBtn:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine(GetL().title, 1, 1, 1)
    GameTooltip:AddLine(GetL().m_desc, 0.8, 0.8, 0.8)
    GameTooltip:AddLine(GetL().move_hint, 0.8, 0.8, 0.8)
    GameTooltip:Show()
end)
MBtn:SetScript("OnLeave", function()
    GameTooltip:Hide()
end)
local eF = CreateFrame("Frame")
eF:RegisterEvent("ADDON_LOADED")
eF:RegisterEvent("PARTY_INVITE_REQUEST")
eF:RegisterEvent("CHAT_MSG_GUILD")
eF:RegisterEvent("TRADE_REQUEST")
eF:RegisterEvent("CHAT_MSG_WHISPER")
eF:RegisterEvent("CHAT_MSG_ADDON")
eF:RegisterEvent("PLAYER_ENTERING_WORLD")
eF:RegisterEvent("GROUP_ROSTER_UPDATE")

eF:SetScript("OnEvent", function(self, event, a1, a2, a3, a4, a5)
    local db = InitDB()
    local sl = GetL()

    if event == "ADDON_LOADED" and a1 == addonName then
        MigrateOldData()
        RefreshUI()
        if db.sync and IsInGuild() then
            C_Timer.After(5, function() C_ChatInfo.SendAddonMessage("BLTBC_V7", "REQ", "GUILD") end)
        end
    elseif event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(2, CheckGroupForBlacklist)
    elseif event == "GROUP_ROSTER_UPDATE" then
        CheckGroupForBlacklist()
    elseif event == "PARTY_INVITE_REQUEST" then
        local inviter = a1
        local name = inviter:match("([^%-]+)")
        local data = GetBLPlayer(name)
        if data then
            DeclineGroup(); StaticPopup_Hide("PARTY_INVITE")
            if not data.hide then print("|cffff0000" .. sl.declined:format(name) .. "|r") end
        end
    elseif event == "TRADE_REQUEST" then
        local data = GetBLPlayer(a1)
        if data and data.hide then CancelTrade() end
    elseif event == "CHAT_MSG_WHISPER" then
        local name = a2 and a2:match("([^%-]+)")
        local data = GetBLPlayer(name)
        if data and data.proof and data.proof ~= "" then
            local now = GetTime()
            if not proofCache[name.."_w"] or (now - proofCache[name.."_w"] > 80) then
                print("|cffffcc00Proof:|r " .. data.proof)
                proofCache[name.."_w"] = now
            end
        end
    elseif event == "CHAT_MSG_GUILD" and db.sync then
        local n, r = a1:match("%[BlackList%] (.+) добавлен в ЧС. Причина: (.+)")
        if not n then n, r = a1:match("%[BlackList%] (.+) added. Reason: (.+)") end
        if n and a4:match("([^%-]+)") ~= UnitName("player") then
            if AddPlayer(n, r, true) and Main:IsShown() then Main:UpdateList() end
        end
    elseif event == "CHAT_MSG_ADDON" and a1 == "BLTBC_V7" then
        local sender = a4 and a4:match("([^%-]+)")
        if sender == UnitName("player") then return end
        if a2 == "REQ" then
            local serverData = GetCurrentServerData()
            if not serverData then return end
            local data = ""
            for i=1, math.min(#serverData.list, 10) do
                data = data .. serverData.list[i].name .. "," .. serverData.list[i].reason .. ";"
            end
            C_ChatInfo.SendAddonMessage("BLTBC_V7", "DATA:" .. data, "GUILD")
        elseif a2:sub(1,5) == "DATA:" then
            local dataStr = a2:sub(6)
            local added = false
            for n, r in dataStr:gmatch("([^,]+),([^;]+);") do
                if AddPlayer(n, r, true) then added = true end
            end
            if added and Main:IsShown() then Main:UpdateList() end
        elseif a2:sub(1,4) == "ADD:" then
            local n, r = a2:sub(5):match("([^:]+):(.+)")
            if n and AddPlayer(n, r, true) and Main:IsShown() then Main:UpdateList() end
        end
    end
end)

SLASH_BLTBC1 = "/bl"
SlashCmdList["BLTBC"] = function()
    if Main:IsShown() then
        Main:Hide()
        ForceClearInputs()
    else
        ForceClearInputs()
        Main:Show()
        Main:UpdateList()
    end
end

-- ==========================================
-- 🌐 МОДУЛЬ ГЛОБАЛЬНЫХ СПИСКОВ (с корректным таймером на time())
-- ==========================================
do
    local RefreshBtn = CreateFrame("Button", nil, Main, "UIPanelButtonTemplate")
    RefreshBtn:SetSize(100, 30)
    RefreshBtn:SetPoint("LEFT", AddBtn, "RIGHT", 10, 0)
    RefreshBtn:SetText(GetL().update_btn)

    local VersionText = Main:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    VersionText:SetPoint("TOPLEFT", RefreshBtn, "BOTTOMLEFT", 0, -5)
    VersionText:SetText("")

    local function GetGlobalList()
        local realm = GetCurrentRealm()
        if not realm then
            print("|cffff0000[BlackList]|r " .. GetL().update_wrong_realm)
            return nil, nil
        end
        local tableName = realm .. "List"
        local ext = _G[tableName]
        local usedVar = tableName
        
        if not ext then
            ext = _G["t"]
            if ext then usedVar = "t" end
        end
        
        if not ext then
            print("|cffff0000[BlackList]|r " .. string.format(GetL().update_file_missing, tableName .. ".lua"))
            return nil, nil
        end
        
        local entries = ext.case_table or ext.list
        if not entries then
            print("|cffff0000[BlackList]|r " .. string.format(GetL().update_file_not_found, tableName .. ".lua", tableName, tableName))
            if usedVar == "t" then
                print("|cffff0000[BlackList]|r Hint: Your file uses variable 't', but the addon expects '" .. tableName .. "'. Please rename 't' to '" .. tableName .. "' in the file.")
            else
                print("|cffff0000[BlackList]|r Hint: Your file defines '" .. tableName .. "' but it has no 'case_table' or 'list' field. Make sure data is stored in '" .. tableName .. ".case_table'.")
            end
            return nil, nil
        end
        return entries, ext.version
    end

    local function PerformUpdate()
        local serverData = GetCurrentServerData()
        if not serverData then return end
        local entries, version = GetGlobalList()
        if not entries then return end

        if serverData.globalListVersion and serverData.globalListVersion == version then
            print("|cffff0000[BlackList]|r " .. string.format(GetL().update_already, version))
            return
        end

        local addedCount = 0
        local updatedCount = 0
        
        for _, entry in pairs(entries) do
            if type(entry) == "table" and entry.name and entry.name ~= "" then
                local name = entry.name:gsub("^%l", string.upper)
                local description = entry.description or "-"
                local url = entry.url or ""
                
                local existing = nil
                for i, v in ipairs(serverData.list) do
                    if v.name == name then
                        existing = v
                        break
                    end
                end
                if existing then
                    if url ~= "" and existing.proof ~= url then
                        existing.proof = url
                        updatedCount = updatedCount + 1
                    end
                else
                    local _, class = UnitClass(name)
                    table.insert(serverData.list, 1, {
                        name = name,
                        date = date("%d.%m.%y"),
                        reason = description,
                        proof = url,
                        hide = false,
                        class = class
                    })
                    addedCount = addedCount + 1
                end
            end
        end

        serverData.globalListVersion = version
        serverData.lastRefreshTime = time()
        VersionText:SetText("Version: " .. version)
        if Main:IsShown() then Main:UpdateList() end
        
        print("|cff00ff00[BlackList]|r " .. string.format(GetL().update_complete, version, addedCount, updatedCount))
    end

    local function OnRefreshClick()
        local currentRealm = GetCurrentRealm()
        if not currentRealm then
            print("|cffff0000[BlackList]|r " .. GetL().update_wrong_realm)
            return
        end

        local serverData = GetCurrentServerData()
        if not serverData then return end

        local now = time()
        local cooldown = 30 * 60
        local last = serverData.lastRefreshTime
        
        local isOnCooldown = false
        local remaining = 0
        if last and (now - last) < cooldown then
            isOnCooldown = true
            remaining = math.ceil((cooldown - (now - last)) / 60)
        end
        
        if isOnCooldown and (remaining <= 0 or remaining > 30) then
            isOnCooldown = false
            remaining = 0
        end

        if isOnCooldown then
            print("|cffff0000[BlackList]|r " .. GetL().update_cooldown .. " " .. string.format(GetL().update_cooldown_remaining, remaining))
            return
        end

        local dialogText = GetL().confirm_text
        StaticPopupDialogs["BLTBC_CONFIRM_UPDATE"] = {
            text = dialogText,
            button1 = GetL().confirm_yes,
            button2 = GetL().confirm_no,
            OnAccept = function()
                PerformUpdate()
            end,
            OnCancel = function() end,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            preferredIndex = 3,
        }
        StaticPopup_Show("BLTBC_CONFIRM_UPDATE")
    end

    RefreshBtn:SetScript("OnClick", OnRefreshClick)

    local serverData = GetCurrentServerData()
    if serverData then
        if serverData.globalListVersion then
            VersionText:SetText("Version: " .. serverData.globalListVersion)
        end
        if serverData.lastRefreshTime then
            local now = time()
            if now - serverData.lastRefreshTime > 30 * 60 then
                serverData.lastRefreshTime = nil
            end
        end
    end
end
-- END OF FILE
