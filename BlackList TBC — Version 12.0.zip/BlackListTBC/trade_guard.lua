﻿local f = CreateFrame("Frame")

-- ===== SavedVariables =====
-- SavedVariables: TradeGuardDB
TradeGuardDB = TradeGuardDB or {}
TradeGuardDB.enabled = TradeGuardDB.enabled == nil and true or TradeGuardDB.enabled
TradeGuardDB.locale = TradeGuardDB.locale or "en"   -- язык по умолчанию

-- ===== Localization =====
local LOCALES = {
    en = {
        enabled = "TradeGuard ENABLED. Trade protection active.",
        disabled = "TradeGuard DISABLED. Trade protection inactive.",
        usage = "Usage: /tradeguard on | off | lang en|ru",
        currentStatus = "Current status: %s",
        loaded = "Loaded. Protection: %s",
        target70 = "Target is level 70. Initial verification popup skipped.",
        firstConfirm = "First popup confirmed. You may now trade.",
        tradeCanceled = "Trade canceled by player.",
        blockedFirst = "Trade blocked! Confirm first popup first.",
        blockedWarning = "Trade blocked! Confirm warning popup.",
        warningConfirm = "Warning confirmed. You may now trade.",
        tradeStarted = "Trade started.",
        tradeClosed = "Trade closed. All states reset.",
        langChanged = "Language set to English.",
        invalidLang = "Invalid language. Use 'en' or 'ru'.",

        -- Popup titles / buttons
        firstPopupTitle = "TradeGuard Verification",
        confirm = "Confirm",
        cancelTrade = "Cancel Trade",

        -- First popup text
        tradeInitiated = "Trade initiated with:",
        level = "Level",
        class = "Class",
        guild = "Guild",
        noGuild = "No Guild",
        inGroup = "In Group/Raid",
        yes = "Yes",
        no = "No",
        warningUnder70 = "WARNING: Character under level 70.\nMay not be able to apply some enchants/recipes.",
        verifyPlayer = "Verify the player before trading.",
        continueQuestion = "Continue?",

        -- Change messages
        targetReplaced = "[TradeGuard] Target replaced item in slot %d: %s -> %s x%d",
        targetAdded = "[TradeGuard] Target added item in slot %d: %s x%d",
        targetRemoved = "[TradeGuard] Target removed item in slot %d: %s",
        targetStack = "[TradeGuard] Target stack size of %s changed: %d -> %d",
        yourReplaced = "[TradeGuard] Your item in slot %d changed: %s -> %s x%d",
        yourAdded = "[TradeGuard] You added item in slot %d: %s x%d",
        yourRemoved = "[TradeGuard] You removed item in slot %d: %s",
        yourStack = "[TradeGuard] Your stack size of %s changed: %d -> %d",
        goldChangedYours = "[TradeGuard] Your gold changed: %s -> %s",
        goldChangedTarget = "[TradeGuard] Target gold changed: %s -> %s",

        -- Misc
        unknown = "Unknown",
    },
    ru = {
        enabled = "TradeGuard ВКЛЮЧЕН. Защита обмена активна.",
        disabled = "TradeGuard ВЫКЛЮЧЕН. Защита обмена неактивна.",
        usage = "Использование: /tradeguard on | off | lang en|ru",
        currentStatus = "Текущий статус: %s",
        loaded = "Загружен. Защита: %s",
        target70 = "Цель 70-го уровня. Первое окно проверки пропущено.",
        firstConfirm = "Первое окно подтверждено. Можно продолжать обмен.",
        tradeCanceled = "Обмен отменён игроком.",
        blockedFirst = "Обмен заблокирован! Сначала подтвердите первое окно.",
        blockedWarning = "Обмен заблокирован! Подтвердите предупреждение.",
        warningConfirm = "Предупреждение подтверждено. Можно продолжать обмен.",
        tradeStarted = "Обмен начат.",
        tradeClosed = "Обмен закрыт. Все состояния сброшены.",
        langChanged = "Язык изменён на русский.",
        invalidLang = "Неверный язык. Используйте 'en' или 'ru'.",

        firstPopupTitle = "Проверка TradeGuard",
        confirm = "Подтвердить",
        cancelTrade = "Отменить обмен",

        tradeInitiated = "Обмен начат с:",
        level = "Уровень",
        class = "Класс",
        guild = "Гильдия",
        noGuild = "Нет гильдии",
        inGroup = "В группе/рейде",
        yes = "Да",
        no = "Нет",
        warningUnder70 = "ПРЕДУПРЕЖДЕНИЕ: Персонаж ниже 70 уровня.\nМожет не иметь возможности наложить некоторые чары/рецепты.",
        verifyPlayer = "Проверьте игрока перед обменом.",
        continueQuestion = "Продолжить?",

        targetReplaced = "[TradeGuard] Цель заменила предмет в ячейке %d: %s -> %s x%d",
        targetAdded = "[TradeGuard] Цель добавила предмет в ячейку %d: %s x%d",
        targetRemoved = "[TradeGuard] Цель убрала предмет из ячейки %d: %s",
        targetStack = "[TradeGuard] Размер стака цели %s изменился: %d -> %d",
        yourReplaced = "[TradeGuard] Ваш предмет в ячейке %d изменился: %s -> %s x%d",
        yourAdded = "[TradeGuard] Вы добавили предмет в ячейку %d: %s x%d",
        yourRemoved = "[TradeGuard] Вы убрали предмет из ячейки %d: %s",
        yourStack = "[TradeGuard] Размер вашего стака %s изменился: %d -> %d",
        goldChangedYours = "[TradeGuard] Ваше золото изменилось: %s -> %s",
        goldChangedTarget = "[TradeGuard] Золото цели изменилось: %s -> %s",

        unknown = "Неизвестно",
    }
}

local function L(key, ...)
    local locale = TradeGuardDB.locale
    local tbl = LOCALES[locale] or LOCALES.en
    local str = tbl[key] or key
    if select("#", ...) > 0 then
        return string.format(str, ...)
    end
    return str
end

-- ===== Commands =====
SLASH_TRADEGUARD1 = "/tradeguard"
SlashCmdList["TRADEGUARD"] = function(msg)
    msg = msg:lower()
    local args = {}
    for arg in msg:gmatch("%S+") do
        table.insert(args, arg)
    end

    if #args == 0 then
        print("|cffff4444[TradeGuard]|r " .. L("usage"))
        print(L("currentStatus", TradeGuardDB.enabled and L("enabled"):gsub("TradeGuard ","") or L("disabled"):gsub("TradeGuard ","")))
        return
    end

    local cmd = args[1]
    if cmd == "on" then
        TradeGuardDB.enabled = true
        print("|cffff4444[TradeGuard]|r " .. L("enabled"))
    elseif cmd == "off" then
        TradeGuardDB.enabled = false
        print("|cffff4444[TradeGuard]|r " .. L("disabled"))
    elseif cmd == "lang" then
        local lang = args[2]
        if lang == "en" or lang == "ru" then
            TradeGuardDB.locale = lang
            print("|cffff4444[TradeGuard]|r " .. L("langChanged"))
            -- Показать текущий статус на новом языке
            -- print("|cffff4444[TradeGuard]|r " .. L("loaded", TradeGuardDB.enabled and L("enabled"):gsub("TradeGuard ","") or L("disabled"):gsub("TradeGuard ","")))
        else
            print("|cffff4444[TradeGuard]|r " .. L("invalidLang"))
        end
    else
        print("|cffff4444[TradeGuard]|r " .. L("usage"))
    end
end

-- ===== Events =====
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("TRADE_SHOW")
f:RegisterEvent("TRADE_ACCEPT_UPDATE")
f:RegisterEvent("TRADE_TARGET_ITEM_CHANGED")
f:RegisterEvent("TRADE_PLAYER_ITEM_CHANGED")
f:RegisterEvent("TRADE_CLOSED")

-- State variables
local playerAccepted = false
local firstPopupConfirmed = false
local blockTrade = false
local tradeHit = false
local lastPlayerGold = 0
local lastTargetGold = 0
local targetItems = {}
local targetCounts = {}
local playerItems = {}
local playerCounts = {}
local pendingChanges = {}
local tradeClosedProcessed = false

-- Utility: color name by class
local function ColorName(unit)
    local name = UnitName(unit)
    local _, class = UnitClass(unit)
    if not name then return L("unknown") end
    if class and RAID_CLASS_COLORS[class] then
        local c = RAID_CLASS_COLORS[class]
        return string.format("|cFF%02x%02x%02x%s|r", c.r*255, c.g*255, c.b*255, name)
    end
    return name
end

-- Utility: format money with coin icons
local function FormatMoney(amount)
    if amount == 0 then
        return GetCoinTextureString(0)
    end
    return GetCoinTextureString(amount)
end

-- Determine unit
local function GetUnit()
    if UnitExists("NPC") then return "NPC" end
    if UnitExists("target") then return "target" end
end

-- Check if target is in party/raid
local function IsTargetInGroup()
    local targetName = UnitName("target")
    if not targetName then return false end

    for i = 1,4 do
        if UnitExists("party"..i) and UnitName("party"..i) == targetName then
            return true
        end
    end

    for i = 1,40 do
        if UnitExists("raid"..i) and UnitName("raid"..i) == targetName then
            return true
        end
    end

    return false
end

-- Reset trade state
local function ResetTradeState()
    playerAccepted = false
    firstPopupConfirmed = false
    blockTrade = false
    tradeHit = false

    wipe(targetItems)
    wipe(targetCounts)
    wipe(playerItems)
    wipe(playerCounts)
    wipe(pendingChanges)

    StaticPopup_Hide("TRADE_GUARD_FIRST")
    StaticPopup_Hide("TRADE_GUARD_WARNING")
end

-- First popup
local function ShowFirstPopup()
    if not TradeGuardDB.enabled then return end

    local unit = GetUnit()
    if not unit then return end

    local level = UnitLevel(unit) or 0

    if level == 70 then
        firstPopupConfirmed = true
        playerAccepted = true
        print("|cffff4444[TradeGuard]|r " .. L("target70"))
        return
    end

    local name = ColorName(unit)
    local race = UnitRace(unit) or L("unknown")
    local classLocalized = select(1, UnitClass(unit)) or L("unknown")
    local guild = GetGuildInfo(unit) or L("noGuild")
    local inGroup = IsTargetInGroup() and L("yes") or L("no")

    local levelWarning = ""
    if level < 70 then
        levelWarning = "\n\n|cffff0000" .. L("warningUnder70") .. "|r"
    end

    local text = L("tradeInitiated") .. "\n\n" ..
        name .. "\n" ..
        L("level") .. ": "..level.." "..race.."\n" ..
        L("class") .. ": "..classLocalized.."\n" ..
        L("guild") .. ": <"..guild..">\n" ..
        L("inGroup") .. ": "..inGroup ..
        levelWarning ..
        "\n\n|cffffcc00" .. L("verifyPlayer") .. "|r\n\n" .. L("continueQuestion")

    StaticPopupDialogs["TRADE_GUARD_FIRST"] = {
        text = text,
        button1 = L("confirm"),
        button2 = L("cancelTrade"),

        OnAccept = function()
            firstPopupConfirmed = true
            playerAccepted = true
            print("|cffff4444[TradeGuard]|r " .. L("firstConfirm"))
        end,

        OnCancel = function()
            CancelTrade()
            print("|cffff4444[TradeGuard]|r " .. L("tradeCanceled"))
        end,

        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3
    }

    StaticPopup_Show("TRADE_GUARD_FIRST")
end

-- Warning popup
local function ShowWarningPopupStatic()
    if not TradeGuardDB.enabled or #pendingChanges == 0 then return end

    local text = table.concat(pendingChanges,"\n")
    text = text:gsub("(%[TradeGuard%] Your.-)\n?", "|cffff4444%1|r\n")
    text = text:gsub("(%[TradeGuard%] Target.-)\n?", "|cffff8800%1|r\n")
    text = text:gsub("(%[TradeGuard%].-gold.-)\n?", "|cffffff00%1|r\n")

    StaticPopupDialogs["TRADE_GUARD_WARNING"] = {
        text = text,
        button1 = L("confirm"),
        button2 = L("cancelTrade"),

        OnAccept = function()
            blockTrade = false
            tradeHit = false
            wipe(pendingChanges)
            print("|cffff4444[TradeGuard]|r " .. L("warningConfirm"))
        end,

        OnCancel = function()
            CancelTrade()
            print("|cffff4444[TradeGuard]|r " .. L("tradeCanceled"))
        end,

        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
        preferredIndex = 3
    }

    StaticPopup_Show("TRADE_GUARD_WARNING")
    blockTrade = true
end

-- Scan target items
local function ScanTargetItems()
    for i=1,6 do
        local link = GetTradeTargetItemLink(i)
        local _,_,count = GetTradeTargetItemInfo(i)
        count = count or 1

        if link ~= targetItems[i] or count ~= targetCounts[i] then
            local oldCount = targetCounts[i] or 0
            local msg

            if targetItems[i] and link and targetItems[i] ~= link then
                msg = L("targetReplaced", i, targetItems[i], link, count)
            elseif link and not targetItems[i] then
                msg = L("targetAdded", i, link, count)
            elseif not link and targetItems[i] then
                msg = L("targetRemoved", i, targetItems[i])
            elseif link and count ~= oldCount then
                msg = L("targetStack", link, oldCount, count)
            end

            if msg then
                print(msg)
                if tradeHit then
                    table.insert(pendingChanges,msg)
                end
            end
        end

        targetItems[i] = link
        targetCounts[i] = count
    end
end

-- Scan player items
local function ScanPlayerItems()
    for i=1,6 do
        local link = GetTradePlayerItemLink(i)
        local _,_,count = GetTradePlayerItemInfo(i)
        count = count or 1

        if link ~= playerItems[i] or count ~= playerCounts[i] then
            local oldCount = playerCounts[i] or 0
            local msg

            if playerItems[i] and link and playerItems[i] ~= link then
                msg = L("yourReplaced", i, playerItems[i], link, count)
            elseif link and not playerItems[i] then
                msg = L("yourAdded", i, link, count)
            elseif not link and playerItems[i] then
                msg = L("yourRemoved", i, playerItems[i])
            elseif link and count ~= oldCount then
                msg = L("yourStack", link, oldCount, count)
            end

            if msg then
                print(msg)
                if tradeHit then
                    table.insert(pendingChanges,msg)
                end
            end
        end

        playerItems[i] = link
        playerCounts[i] = count
    end
end

-- Event handler
f:SetScript("OnEvent", function(self,event,...)
    if event == "PLAYER_LOGIN" then
        -- print("|cffff4444[TradeGuard]|r " .. L("loaded", TradeGuardDB.enabled and L("enabled"):gsub("TradeGuard ","") or L("disabled"):gsub("TradeGuard ","")))
        return
    end

    if not TradeGuardDB.enabled then return end

    if event == "TRADE_SHOW" then
        tradeClosedProcessed = false
        ResetTradeState()
        lastPlayerGold = GetPlayerTradeMoney()
        lastTargetGold = GetTargetTradeMoney()
        ShowFirstPopup()
        print("|cffff4444[TradeGuard]|r " .. L("tradeStarted"))
    end

    if event == "TRADE_ACCEPT_UPDATE" then
        local playerState = ...
        if playerState == 1 then
            tradeHit = true
            if not firstPopupConfirmed then
                CancelTrade()
                print("|cffff4444[TradeGuard]|r " .. L("blockedFirst"))
                return
            end
            if blockTrade then
                CancelTrade()
                print("|cffff4444[TradeGuard]|r " .. L("blockedWarning"))
                ShowWarningPopupStatic()
                return
            end
        end
    end

    if event == "TRADE_TARGET_ITEM_CHANGED" then ScanTargetItems() end
    if event == "TRADE_PLAYER_ITEM_CHANGED" then ScanPlayerItems() end

    local playerGold = GetPlayerTradeMoney()
    local targetGold = GetTargetTradeMoney()

    if playerGold ~= lastPlayerGold then
        local msg = L("goldChangedYours", FormatMoney(lastPlayerGold), FormatMoney(playerGold))
        print(msg)
        if tradeHit then table.insert(pendingChanges,msg) end
        lastPlayerGold = playerGold
    end

    if targetGold ~= lastTargetGold then
        local msg = L("goldChangedTarget", FormatMoney(lastTargetGold), FormatMoney(targetGold))
        print(msg)
        if tradeHit then table.insert(pendingChanges,msg) end
        lastTargetGold = targetGold
    end

    if tradeHit and firstPopupConfirmed and #pendingChanges > 0 and not blockTrade then
        ShowWarningPopupStatic()
    end

    if event == "TRADE_CLOSED" then
        if not tradeClosedProcessed then
            tradeClosedProcessed = true
            ResetTradeState()
            print("|cffff4444[TradeGuard]|r " .. L("tradeClosed"))
        end
    end
end)
