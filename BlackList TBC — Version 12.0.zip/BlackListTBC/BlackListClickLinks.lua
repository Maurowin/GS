﻿---------------------------------------------------------------------
-- Overlay frame (closes dialog on outside clicks)
---------------------------------------------------------------------
local overlay = CreateFrame("Frame", "BlackListClickLinkOverlay", UIParent)
overlay:SetAllPoints(UIParent)
overlay:SetFrameStrata("HIGH")
overlay:EnableMouse(true)
overlay:SetScript("OnMouseDown", function()
    BlackListClickLinkFrame:Hide()
    overlay:Hide()
end)
overlay:Hide()

---------------------------------------------------------------------
-- Main dialog frame
---------------------------------------------------------------------
local frame = CreateFrame("Frame", "BlackListClickLinkFrame", UIParent)
frame:SetSize(400, 140)
frame:SetPoint("CENTER")
frame:SetFrameStrata("DIALOG")
frame:EnableMouse(true)
frame:SetClampedToScreen(true)
frame:SetToplevel(true)
frame:SetScript("OnKeyDown", function(self, key)
    if key == "ESCAPE" then
        self:Hide()
        overlay:Hide()
    end
end)
frame:EnableKeyboard(true)
frame:SetPropagateKeyboardInput(true)

-- Dark background
local bg = frame:CreateTexture(nil, "BACKGROUND")
bg:SetAllPoints(frame)
bg:SetColorTexture(0, 0, 0, 0.92)

-- Borders
local border = frame:CreateTexture(nil, "BORDER")
border:SetAllPoints(frame)
border:SetColorTexture(0.25, 0.25, 0.25, 1)
local innerBorder = frame:CreateTexture(nil, "ARTWORK")
innerBorder:SetPoint("TOPLEFT", 1, -1)
innerBorder:SetPoint("BOTTOMRIGHT", -1, 1)
innerBorder:SetColorTexture(0.1, 0.1, 0.1, 1)

frame:Hide()

-- Title
frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
frame.title:SetPoint("TOP", 0, -15)
frame.title:SetText("BlackList – Copy URL:")

---------------------------------------------------------------------
-- EditBox background
---------------------------------------------------------------------
local editBoxBg = CreateFrame("Frame", nil, frame)
editBoxBg:SetSize(364, 34)
editBoxBg:SetPoint("TOP", 0, -45)

local editBoxBgTex = editBoxBg:CreateTexture(nil, "BACKGROUND")
editBoxBgTex:SetAllPoints(editBoxBg)
editBoxBgTex:SetColorTexture(0.15, 0.15, 0.15, 0.95)

local editBoxBorder = editBoxBg:CreateTexture(nil, "BORDER")
editBoxBorder:SetAllPoints(editBoxBg)
editBoxBorder:SetColorTexture(0.3, 0.3, 0.3, 1)

---------------------------------------------------------------------
-- EditBox
---------------------------------------------------------------------
local editBox = CreateFrame("EditBox", "BlackListClickLink_EditBox", frame)
editBox:SetSize(360, 30)
editBox:SetPoint("CENTER", editBoxBg, "CENTER")
editBox:SetFontObject(GameFontHighlight)
editBox:SetAutoFocus(false)
editBox:EnableMouse(true)
editBox:EnableKeyboard(true)
editBox:SetTextColor(0.12, 0.56, 1)
editBox:SetScript("OnEscapePressed", function()
    frame:Hide()
    overlay:Hide()
end)
editBox:SetScript("OnEditFocusGained", function(self)
    self:HighlightText()
end)
editBox:SetScript("OnChar", function(self)
    self:SetText(editBox.lastUrl or "")
end)
editBox.lastUrl = ""

local function setUrl(url)
    editBox.lastUrl = url
    editBox:SetText(url)
    editBox:HighlightText()
end

frame:SetScript("OnShow", function()
    editBox:SetFocus()
    editBox:HighlightText()
end)

---------------------------------------------------------------------
-- Copy logic
---------------------------------------------------------------------
local hasSetClipboard = (type(SetClipboardText) == "function")
local function doCopy()
    local url = editBox.lastUrl
    if not url or url == "" then
        if _G.ChatFrame1 then
            _G.ChatFrame1:AddMessage("|cffff0000[BlackListTBC]: No URL to copy.|r")
        end
        frame:Hide()
        overlay:Hide()
        return
    end

    if hasSetClipboard then
        local ok, err = pcall(SetClipboardText, url)
        if ok then
            if _G.ChatFrame1 then
                _G.ChatFrame1:AddMessage("|cff00ff00[BlackListTBC]: The website URL has been copied to clipboard.|r")
            end
            frame:Hide()
            overlay:Hide()
        else
            if _G.ChatFrame1 then
                _G.ChatFrame1:AddMessage("|cffffff00[BlackListTBC]: Automatic copy unavailable. The URL is selected – press Ctrl+C to copy.|r")
            end
            editBox:SetFocus()
            editBox:HighlightText()
        end
    else
        if _G.ChatFrame1 then
            _G.ChatFrame1:AddMessage("|cffffff00[BlackListTBC]: The URL is selected. Press Ctrl+C to copy it.|r")
        end
        editBox:SetFocus()
        editBox:HighlightText()
    end
end

-- Buttons
local copyBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
copyBtn:SetSize(100, 22)
copyBtn:SetPoint("BOTTOMLEFT", 20, 15)
copyBtn:SetText(hasSetClipboard and "Copy" or "Select URL")
copyBtn:SetScript("OnClick", doCopy)

local closeBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
closeBtn:SetSize(100, 22)
closeBtn:SetPoint("BOTTOMRIGHT", -20, 15)
closeBtn:SetText("Close")
closeBtn:SetScript("OnClick", function()
    frame:Hide()
    overlay:Hide()
end)

-- Auto-close on cast
local spellFrame = CreateFrame("Frame")
spellFrame:RegisterEvent("UNIT_SPELLCAST_SENT")
spellFrame:SetScript("OnEvent", function(self, event, unit)
    if unit == "player" then
        frame:Hide()
        overlay:Hide()
    end
end)

---------------------------------------------------------------------
-- URL detection with PROOF filter (case insensitive)
---------------------------------------------------------------------
local function replaceUrls(msg)
    if not msg then return msg end
    -- Only process messages containing the word "proof" (any case)
    if not msg:lower():find("proof") then
        return msg
    end
    -- Do not double-process existing hyperlinks
    if msg:find("|Hcopylink:") then
        return msg
    end
    local s = msg
    s = s:gsub("((https?://%S+))",
               "|cff1e90ff|Hcopylink:%1|h[%1]|h|r")
    s = s:gsub("((www%.[%w_%-%.]+%S*))",
               "|cff1e90ff|Hcopylink:%1|h[%1]|h|r")
    return s
end

---------------------------------------------------------------------
-- Chat message filter
---------------------------------------------------------------------
local function chatFilter(self, event, msg, ...)
    local newMsg = replaceUrls(msg)
    return false, newMsg, ...
end

local chatEvents = {
    "CHAT_MSG_SAY", "CHAT_MSG_YELL",
    "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
    "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER",
    "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
    "CHAT_MSG_BN_WHISPER", "CHAT_MSG_BN_WHISPER_INFORM",
    "CHAT_MSG_CHANNEL", "CHAT_MSG_EMOTE",
}
for _, event in ipairs(chatEvents) do
    ChatFrame_AddMessageEventFilter(event, chatFilter)
end

---------------------------------------------------------------------
-- Hyperlink click handler
---------------------------------------------------------------------
local function hyperlinkClick(self, linkData, text, button)
    if linkData and linkData:find("^copylink:") then
        local url = linkData:match("^copylink:(.+)$")
        if url then
            setUrl(url)
            BlackListClickLinkFrame:Show()
            BlackListClickLinkOverlay:Show()
        end
        return
    end
    local orig = self._origOnHyperlinkClick
    if orig then
        orig(self, linkData, text, button)
    end
end

for i = 1, 10 do
    local cf = _G["ChatFrame" .. i]
    if cf then
        cf:SetHyperlinksEnabled(true)
        cf._origOnHyperlinkClick = cf:GetScript("OnHyperlinkClick")
        cf:SetScript("OnHyperlinkClick", hyperlinkClick)
    end
end

---------------------------------------------------------------------
-- Recursive scanner with safety and performance tweaks
---------------------------------------------------------------------
local scanner = CreateFrame("Frame")
scanner.timer = 0
scanner:SetScript("OnUpdate", function(self, elapsed)
    self.timer = self.timer + elapsed
    if self.timer < 0.5 then return end
    self.timer = 0

    local function scanRecursive(parent)
        if not parent then return end
        -- Skip hidden parents to avoid unnecessary recursion
        if not parent:IsVisible() then return end

        -- Safe GetRegions call (fix for frames without this method)
        if parent.GetRegions then
            local regions = {parent:GetRegions()}
            for _, child in ipairs(regions) do
                if child and child.GetText and child.IsVisible and child:IsVisible() then
                    local text = child:GetText()
                    if type(text) == "string" and (text:find("https?://") or text:find("www%.")) and not text:find("|Hcopylink:") then
                        local newText = replaceUrls(text)
                        if newText ~= text then
                            child:SetText(newText)
                        end
                    end
                end
            end
        end

        -- Recurse into children
        local children = {parent:GetChildren()}
        for _, child in ipairs(children) do
            scanRecursive(child)
        end
    end

    scanRecursive(UIParent)
end)
