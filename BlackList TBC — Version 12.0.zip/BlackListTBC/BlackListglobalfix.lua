﻿local f = CreateFrame("Frame")

local interval = 50 * 60 -- 50 минут в секундах
local elapsed = 0

local function RunMacroLogic()
    local s = BlackListTBC_DB and BlackListTBC_DB.servers
    local r = GetRealmName():gsub("%s+", ""):lower()

    if r == "thunderstrike" then
        r = "Thunderstrike"
    elseif r == "spineshatter" then
        r = "Spineshatter"
    end

    if s and s[r] then
        s[r].lastRefreshTime = nil
    end

    print("Done")
end

f:SetScript("OnUpdate", function(self, delta)
    elapsed = elapsed + delta
    if elapsed >= interval then
        RunMacroLogic()
        elapsed = 0
    end
end)

-- запуск при входе в игру
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
    elapsed = 0
end)
