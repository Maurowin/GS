----------------------------------------------------------------------
-- MPBlacklist - Database.lua
-- Saved variables management and data operations
----------------------------------------------------------------------

local addonName, addon = ...

-- Default database structure
local defaults = {
    blacklist = {},   -- key: "name-server" -> player data
    settings = {
        enableHighlight = true,
        enableTooltip = true,
        highlightColor = { r = 1, g = 0, b = 0, a = 0.3 },
        showMinimapButton = true,
        alertSound = true,
        autoCheckParty = true,
        partyAnnounce = true,  -- 小队通告总开关 (默认开启)
        announceFormat = "【飞鸟黑名单】避雷警告: {name} ({class}) - {reason} / 备注: {notes}",  -- 自定义通告消息格式 (不可使用|管道符)
    },
    stats = {
        totalAdded = 0,
        totalRemoved = 0,
    },
}

-- Initialize the database
function addon:InitDB()
    if not MPBlacklistDB then
        MPBlacklistDB = CopyTable(defaults)
    end
    -- Merge any missing fields from defaults
    for k, v in pairs(defaults) do
        if MPBlacklistDB[k] == nil then
            MPBlacklistDB[k] = CopyTable(v)
        end
    end
    if not MPBlacklistDB.settings then
        MPBlacklistDB.settings = CopyTable(defaults.settings)
    end
    for k, v in pairs(defaults.settings) do
        if MPBlacklistDB.settings[k] == nil then
            MPBlacklistDB.settings[k] = v
        end
    end
    -- v1.1.2 migration: fix announceFormat containing pipe characters (causes SendChatMessage errors)
    if MPBlacklistDB.settings.announceFormat and MPBlacklistDB.settings.announceFormat:find("|") then
        MPBlacklistDB.settings.announceFormat = MPBlacklistDB.settings.announceFormat:gsub("|", "/")
    end

    self.db = MPBlacklistDB
end

-- Add a player to blacklist
function addon:AddPlayer(data)
    if not data or not data.name or data.name == "" then
        self:Print(self.colors.warning .. "错误：角色名不能为空！")
        return false
    end

    local key = self:MakeKey(data.name, data.server or "")

    local entry = {
        name    = strtrim(data.name),
        server  = strtrim(data.server or ""),
        class   = data.class or "未知",
        reason  = data.reason or "",
        notes   = data.notes or "",
        date    = data.date or self:GetCurrentDate(),
        dungeon = data.dungeon or "",
        rating  = data.rating or 0,    -- severity 1-5
        screenshots = data.screenshots or {},  -- list of screenshot paths/notes
        addedBy = UnitName("player") or "Unknown",
        records = data.records or {},  -- multiple incident records
    }

    -- If already exists, add as a new record
    if self.db.blacklist[key] then
        local existing = self.db.blacklist[key]
        -- Add new incident record
        table.insert(existing.records, {
            reason = entry.reason,
            notes = entry.notes,
            date = entry.date,
            dungeon = entry.dungeon,
            rating = entry.rating,
            screenshots = entry.screenshots,
        })
        -- Update main fields
        existing.class = entry.class ~= "未知" and entry.class or existing.class
        existing.reason = entry.reason  -- latest reason
        existing.date = entry.date
        self:Print(self.colors.info .. "已更新 " .. data.name .. " 的避雷记录（新增一条事件）")
    else
        -- First record
        entry.records = {{
            reason = entry.reason,
            notes = entry.notes,
            date = entry.date,
            dungeon = entry.dungeon,
            rating = entry.rating,
            screenshots = entry.screenshots,
        }}
        self.db.blacklist[key] = entry
        self.db.stats.totalAdded = (self.db.stats.totalAdded or 0) + 1
        self:Print(self.colors.warning .. "⚠ 已将 " .. data.name .. " 加入避雷名单！")
    end

    -- Refresh UI if open
    if addon.mainFrame and addon.mainFrame:IsShown() then
        addon:RefreshPlayerList()
    end

    return true
end

-- Remove a player from blacklist
function addon:RemovePlayer(key)
    if self.db.blacklist[key] then
        local name = self.db.blacklist[key].name
        self.db.blacklist[key] = nil
        self.db.stats.totalRemoved = (self.db.stats.totalRemoved or 0) + 1
        self:Print(self.colors.success .. "已将 " .. name .. " 从避雷名单中移除")

        if addon.mainFrame and addon.mainFrame:IsShown() then
            addon:RefreshPlayerList()
        end
        return true
    end
    return false
end

-- Check if a player is in blacklist (fuzzy match by name)
function addon:CheckPlayer(name)
    if not name or name == "" then return nil end
    if not self.db or not self.db.blacklist or type(self.db.blacklist) ~= "table" then return nil end

    name = strtrim(name):lower()

    -- Strip color codes if any
    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")

    -- Split input: take first segment before "-" as short name
    local inputName = name:match("^([^%-]+)") or name

    -- 1. Exact key match (name-server)
    for key, data in pairs(self.db.blacklist) do
        if data and key == name then
            return data
        end
    end

    -- 2. Match by data.name field
    for key, data in pairs(self.db.blacklist) do
        if data and data.name and data.name:lower() == name then
            return data
        end
    end

    -- 3. Match input short-name against DB name
    if inputName ~= name then
        for key, data in pairs(self.db.blacklist) do
            if data and data.name and data.name:lower() == inputName then
                return data
            end
        end
    end

    -- 4. Match input against DB key's short-name (non-greedy: first "-")
    for key, data in pairs(self.db.blacklist) do
        if data then
            local dbShortName = key:match("^([^%-]+)") or key
            if dbShortName == name or dbShortName == inputName then
                return data
            end
        end
    end

    -- 5. Match by data.name short part
    for key, data in pairs(self.db.blacklist) do
        if data and data.name then
            local dataShortName = data.name:lower():match("^([^%-]+)") or data.name:lower()
            if dataShortName == inputName then
                return data
            end
        end
    end

    return nil
end

-- Search players (returns list of matches)
function addon:SearchPlayer(query)
    if not query or query == "" then return {} end
    query = strtrim(query):lower()

    local results = {}
    for key, data in pairs(self.db.blacklist) do
        local match = false
        -- Match name
        if data.name:lower():find(query, 1, true) then match = true end
        -- Match server
        if data.server:lower():find(query, 1, true) then match = true end
        -- Match reason
        if data.reason:lower():find(query, 1, true) then match = true end
        -- Match class
        if data.class:lower():find(query, 1, true) then match = true end

        if match then
            table.insert(results, { key = key, data = data })
        end
    end

    if #results > 0 then
        self:Print(self.colors.info .. "找到 " .. #results .. " 条匹配记录：")
        for i, r in ipairs(results) do
            local d = r.data
            local classStr = self:GetColoredClass(d.class)
            self:Print(string.format("  %d. %s (%s) - %s | %s",
                i, d.name, d.server ~= "" and d.server or "未知服务器",
                classStr, d.reason or "无备注"))
        end
    else
        self:Print(self.colors.gray .. "未找到匹配 \"" .. query .. "\" 的记录")
    end

    return results
end

-- Get all blacklist entries as sorted list
function addon:GetSortedBlacklist()
    local list = {}
    for key, data in pairs(self.db.blacklist) do
        table.insert(list, { key = key, data = data })
    end
    -- Sort by date (newest first)
    table.sort(list, function(a, b)
        return (a.data.date or "") > (b.data.date or "")
    end)
    return list
end

-- Get total count
function addon:GetBlacklistCount()
    local count = 0
    for _ in pairs(self.db.blacklist) do
        count = count + 1
    end
    return count
end

-- Clear all data
function addon:ClearAllData()
    wipe(self.db.blacklist)
    self.db.stats.totalAdded = 0
    self.db.stats.totalRemoved = 0
    if addon.mainFrame and addon.mainFrame:IsShown() then
        addon:RefreshPlayerList()
    end
end

-- Deep copy utility (only if not already defined by WoW)
if not CopyTable then
    function CopyTable(t)
        if type(t) ~= "table" then return t end
        local copy = {}
        for k, v in pairs(t) do
            copy[k] = CopyTable(v)
        end
        return copy
    end
end
