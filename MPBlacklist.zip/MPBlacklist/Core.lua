----------------------------------------------------------------------
-- MPBlacklist - Core.lua
-- Mythic+ Blacklist Addon for World of Warcraft 12.0.1
-- Main initialization and slash commands
----------------------------------------------------------------------

-- Create the main addon namespace
local addonName, addon = ...
MPBlacklist = addon

addon.version = "1.1.4"
addon.name = "飞鸟的黑名单"
addon.prefix = "MPBlackli" -- max 16 chars for comm prefix

-- Color constants
addon.colors = {
    title    = "|cff00ccff",
    warning  = "|cffff4444",
    success  = "|cff44ff44",
    info     = "|cffffff00",
    white    = "|cffffffff",
    gray     = "|cff888888",
    highlight = "|cffff8800",
}

-- WoW class colors
addon.classColors = {
    ["战士"]   = "|cffc79c6e",
    ["圣骑士"] = "|cfff58cba",
    ["猎人"]   = "|cffabd473",
    ["盗贼"]   = "|cfffff569",
    ["牧师"]   = "|cffffffff",
    ["死亡骑士"] = "|cffc41f3b",
    ["萨满祭司"] = "|cff0070de",
    ["法师"]   = "|cff69ccf0",
    ["术士"]   = "|cff9482c9",
    ["武僧"]   = "|cff00ff96",
    ["德鲁伊"] = "|cffff7d0a",
    ["恶魔猎手"] = "|cffa330c9",
    ["唤魔师"] = "|cff33937f",
    -- English fallbacks
    ["WARRIOR"]     = "|cffc79c6e",
    ["PALADIN"]     = "|cfff58cba",
    ["HUNTER"]      = "|cffabd473",
    ["ROGUE"]       = "|cfffff569",
    ["PRIEST"]      = "|cffffffff",
    ["DEATHKNIGHT"] = "|cffc41f3b",
    ["SHAMAN"]      = "|cff0070de",
    ["MAGE"]        = "|cff69ccf0",
    ["WARLOCK"]     = "|cff9482c9",
    ["MONK"]        = "|cff00ff96",
    ["DRUID"]       = "|cffff7d0a",
    ["DEMONHUNTER"] = "|cffa330c9",
    ["EVOKER"]      = "|cff33937f",
}

-- Class list for dropdown
addon.classList = {
    "战士", "圣骑士", "猎人", "盗贼", "牧师",
    "死亡骑士", "萨满祭司", "法师", "术士",
    "武僧", "德鲁伊", "恶魔猎手", "唤魔师",
}

-- Main event frame
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("PLAYER_LOGOUT")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddon = ...
        if loadedAddon == addonName then
            addon:InitDB()
            addon:Print(addon.colors.title .. addon.name .. "|r v" .. addon.version .. " 已加载！输入 /sblist 打开主界面")
        end
    elseif event == "PLAYER_LOGIN" then
        addon:InitMinimapButton()
        addon:HookGroupFinder()
        addon:HookUnitMenus()
        -- Register comm channel for potential future sync
        if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
            C_ChatInfo.RegisterAddonMessagePrefix(addon.prefix)
        end
    end
end)

-- Print helper
function addon:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00ccff[飞鸟的黑名单]|r " .. (msg or ""))
end

-- Slash commands
SLASH_MPBLACKLIST1 = "/sblist"
SLASH_MPBLACKLIST2 = "/blacklist"
SLASH_MPBLACKLIST3 = "/avoidlist"

SlashCmdList["MPBLACKLIST"] = function(msg)
    msg = strtrim(msg or "")
    local cmd, rest = msg:match("^(%S+)%s*(.*)$")
    cmd = cmd and cmd:lower() or ""

    if cmd == "" or cmd == "show" or cmd == "open" then
        addon:ToggleMainUI()
    elseif cmd == "add" then
        addon:ShowAddPlayerUI()
    elseif cmd == "search" or cmd == "find" then
        if rest and rest ~= "" then
            addon:SearchPlayer(rest)
        else
            addon:Print("用法: /sblist search <角色名>")
        end
    elseif cmd == "check" then
        if rest and rest ~= "" then
            local result = addon:CheckPlayer(rest)
            if result then
                addon:Print(addon.colors.warning .. "⚠ 避雷警告！" .. "|r " .. rest .. " 在黑名单中！")
                addon:Print("  原因: " .. (result.reason or "未知"))
                addon:Print("  日期: " .. (result.date or "未知"))
            else
                addon:Print(addon.colors.success .. rest .. " 不在黑名单中 ✓")
            end
        else
            addon:Print("用法: /sblist check <角色名>")
        end
    elseif cmd == "target" or cmd == "t" then
        addon:QuickAddTarget(rest)
    elseif cmd == "import" then
        addon:ShowImportUI()
    elseif cmd == "export" then
        addon:ShowExportUI()
    elseif cmd == "clear" then
        StaticPopup_Show("MPBL_CONFIRM_CLEAR")
    elseif cmd == "help" then
        addon:Print(addon.colors.info .. "=== 飞鸟的黑名单 命令列表 ===")
        addon:Print("/sblist " .. addon.colors.gray .. "- 打开/关闭主界面")
        addon:Print("/sblist add " .. addon.colors.gray .. "- 添加新的避雷玩家")
        addon:Print("/sblist target [原因] " .. addon.colors.gray .. "- 将当前目标加入黑名单 (可用于宏)")
        addon:Print("/sblist search <名字> " .. addon.colors.gray .. "- 搜索玩家")
        addon:Print("/sblist check <名字> " .. addon.colors.gray .. "- 快速检查玩家")
        addon:Print("/sblist import " .. addon.colors.gray .. "- 导入黑名单")
        addon:Print("/sblist export " .. addon.colors.gray .. "- 导出黑名单")
        addon:Print("/sblist clear " .. addon.colors.gray .. "- 清空所有记录")
        addon:Print("/sblist help " .. addon.colors.gray .. "- 显示帮助")
        addon:Print(" ")
        addon:Print(addon.colors.info .. "宏示例:")
        addon:Print(addon.colors.highlight .. "/sblist target " .. addon.colors.gray .. "- 选中目标直接拉黑")
        addon:Print(addon.colors.highlight .. "/sblist target 挂机摸鱼 " .. addon.colors.gray .. "- 选中目标并注明原因")
    else
        addon:Print("未知命令。输入 /sblist help 查看帮助")
    end
end

-- Static popup for clear confirmation
StaticPopupDialogs["MPBL_CONFIRM_CLEAR"] = {
    text = "|cffff4444飞鸟的黑名单|r\n\n确定要清空所有避雷记录吗？\n此操作不可撤销！",
    button1 = "确定清空",
    button2 = "取消",
    OnAccept = function()
        addon:ClearAllData()
        addon:Print(addon.colors.warning .. "所有避雷记录已清空！")
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

-- Utility: generate a unique key from name-server
function addon:MakeKey(name, server)
    name = name and strtrim(name) or ""
    server = server and strtrim(server) or ""
    return (name .. "-" .. server):lower()
end

-- Utility: format date
function addon:GetCurrentDate()
    return date("%Y-%m-%d %H:%M")
end

-- Utility: get colored class name
function addon:GetColoredClass(class)
    local color = self.classColors[class]
    if color then
        return color .. class .. "|r"
    end
    return class or "未知"
end

----------------------------------------------------------------------
-- Quick Add Target (macro support)
-- Usage: /sblist target [reason]
-- Macro example: /mpbl target
-- Macro example: /mpbl target 挂机摸鱼
----------------------------------------------------------------------
function addon:QuickAddTarget(reason)
    if not UnitExists("target") then
        self:Print(self.colors.warning .. "请先选中一个目标玩家！")
        return
    end

    if not UnitIsPlayer("target") then
        self:Print(self.colors.warning .. "目标不是玩家！")
        return
    end

    if UnitIsUnit("target", "player") then
        self:Print(self.colors.warning .. "不能把自己加入黑名单！")
        return
    end

    local name = GetUnitName("target", false) or "未知"
    local fullName = GetUnitName("target", true) or name
    local server = ""

    -- Extract server from full name (Name-Server format)
    if fullName:find("-") then
        local n, s = fullName:match("^(.+)-(.+)$")
        if n then
            name = n
            server = s
        end
    else
        -- Same server
        server = GetRealmName() or ""
    end

    -- Get class info
    local _, classToken = UnitClass("target")
    local classLocalized = UnitClass("target") or "未知"

    -- Use provided reason or default
    reason = reason and strtrim(reason) or ""
    if reason == "" then
        reason = "宏快速添加"
    end

    local success = self:AddPlayer({
        name = name,
        server = server,
        class = classLocalized,
        reason = reason,
        notes = "通过宏快速添加",
        date = self:GetCurrentDate(),
    })

    if success then
        -- Show a flashy message
        self:Print(self.colors.warning .. "⚠ 已将 |cffff8800" .. name .. "|r (" .. server .. ") 加入黑名单！")
        self:Print("  原因: " .. reason)

        -- Also show RaidWarning style message for visibility
        if RaidNotice_AddMessage then
            pcall(RaidNotice_AddMessage, RaidWarningFrame,
                "飞鸟黑名单: " .. name .. " 已拉黑！",
                ChatTypeInfo["RAID_WARNING"])
        end
    end
end
