----------------------------------------------------------------------
-- MPBlacklist - MinimapButton.lua
-- Minimap button for quick access
-- Uses custom menu (no UIDropDownMenu to avoid taint in 12.0+)
----------------------------------------------------------------------

local addonName, addon = ...

local minimapButton
local quickMenu  -- custom context menu frame

function addon:InitMinimapButton()
    if minimapButton then return end

    minimapButton = CreateFrame("Button", "MPBlacklistMinimapBtn", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel(8)
    minimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT", 2, -2)

    -- Icon
    local icon = minimapButton:CreateTexture(nil, "ARTWORK")
    icon:SetTexture("Interface\\Icons\\INV_Misc_Map_01")
    icon:SetSize(20, 20)
    icon:SetPoint("CENTER")
    minimapButton.icon = icon

    -- Border
    local border = minimapButton:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
    border:SetSize(56, 56)
    border:SetPoint("TOPLEFT", minimapButton, "TOPLEFT", -4, 4)

    -- Background
    local bg = minimapButton:CreateTexture(nil, "BACKGROUND")
    bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    bg:SetSize(25, 25)
    bg:SetPoint("CENTER")

    -- Highlight (simple glow on hover, no black circle)
    local highlight = minimapButton:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetColorTexture(1, 1, 1, 0.2)
    highlight:SetSize(20, 20)
    highlight:SetPoint("CENTER")

    -- Dragging support
    local isDragging = false

    local function UpdatePosition()
        local cx, cy = Minimap:GetCenter()
        local mx, my = GetCursorPosition()
        local scale = Minimap:GetEffectiveScale()
        mx, my = mx / scale, my / scale
        local angle = math.atan2(my - cy, mx - cx)
        local radius = 80
        local x = math.cos(angle) * radius
        local y = math.sin(angle) * radius
        minimapButton:ClearAllPoints()
        minimapButton:SetPoint("CENTER", Minimap, "CENTER", x, y)
    end

    minimapButton:SetMovable(true)
    minimapButton:RegisterForDrag("LeftButton")

    minimapButton:SetScript("OnDragStart", function(self)
        isDragging = true
        self:SetScript("OnUpdate", UpdatePosition)
    end)

    minimapButton:SetScript("OnDragStop", function(self)
        isDragging = false
        self:SetScript("OnUpdate", nil)
    end)

    -- Click handler
    minimapButton:SetScript("OnClick", function(self, button)
        if button == "LeftButton" then
            addon:ToggleMainUI()
        elseif button == "RightButton" then
            addon:ShowQuickMenu()
        end
    end)

    minimapButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    -- Tooltip
    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("|cff00ccff飞鸟的黑名单|r", 1, 1, 1)
        GameTooltip:AddLine(" ")
        local count = addon:GetBlacklistCount()
        GameTooltip:AddDoubleLine("避雷名单", count .. " 人", 1, 0.82, 0, 1, 1, 1)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cff44ff44左键|r 打开主界面", 0.7, 0.7, 0.7)
        GameTooltip:AddLine("|cff44ff44右键|r 快捷菜单", 0.7, 0.7, 0.7)
        GameTooltip:Show()
    end)

    minimapButton:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)

    -- Visibility
    if self.db and self.db.settings and not self.db.settings.showMinimapButton then
        minimapButton:Hide()
    end
end

----------------------------------------------------------------------
-- Custom Quick Menu (replaces UIDropDownMenu to avoid taint)
----------------------------------------------------------------------
function addon:ShowQuickMenu()
    if quickMenu and quickMenu:IsShown() then
        quickMenu:Hide()
        return
    end

    if not quickMenu then
        quickMenu = CreateFrame("Frame", "MPBlacklistQuickMenu", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
        quickMenu:SetSize(160, 190)
        quickMenu:SetFrameStrata("TOOLTIP")
        quickMenu:SetClampedToScreen(true)
        quickMenu:EnableMouse(true)
        if quickMenu.SetBackdrop then
            quickMenu:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            quickMenu:SetBackdropColor(0.05, 0.05, 0.1, 0.95)
            quickMenu:SetBackdropBorderColor(0.6, 0.5, 0.2, 0.8)
        end

        -- Title
        local title = quickMenu:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        title:SetPoint("TOP", quickMenu, "TOP", 0, -10)
        title:SetText("|cff00ccff飞鸟的黑名单|r")

        -- Separator
        local sep = quickMenu:CreateTexture(nil, "ARTWORK")
        sep:SetHeight(1)
        sep:SetPoint("TOPLEFT", quickMenu, "TOPLEFT", 8, -26)
        sep:SetPoint("TOPRIGHT", quickMenu, "TOPRIGHT", -8, -26)
        sep:SetColorTexture(0.5, 0.4, 0.2, 0.6)

        local menuItems = {
            { text = "打开主界面", func = function() addon:ToggleMainUI() end },
            { text = "添加避雷玩家", func = function() addon:ShowAddPlayerUI() end },
            { text = "导入名单", func = function() addon:ShowImportUI() end },
            { text = "导出名单", func = function() addon:ShowExportUI() end },
            { text = "|cffff4444关闭|r", func = function() quickMenu:Hide() end },
        }

        local yOff = -32
        for i, item in ipairs(menuItems) do
            local btn = CreateFrame("Button", nil, quickMenu)
            btn:SetSize(144, 22)
            btn:SetPoint("TOP", quickMenu, "TOP", 0, yOff)
            yOff = yOff - 26

            local btnBg = btn:CreateTexture(nil, "BACKGROUND")
            btnBg:SetAllPoints()
            btnBg:SetColorTexture(0, 0, 0, 0)

            local hl = btn:CreateTexture(nil, "HIGHLIGHT")
            hl:SetAllPoints()
            hl:SetColorTexture(0.4, 0.35, 0.1, 0.4)

            local label = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            label:SetPoint("CENTER")
            label:SetText(item.text)

            btn:SetScript("OnClick", function()
                quickMenu:Hide()
                if item.func then item.func() end
            end)
        end

        -- Close when clicking elsewhere
        quickMenu:SetScript("OnShow", function()
            quickMenu:SetScript("OnUpdate", function(self, elapsed)
                if not self:IsMouseOver() and IsMouseButtonDown("LeftButton") then
                    self:Hide()
                end
            end)
        end)
        quickMenu:SetScript("OnHide", function()
            quickMenu:SetScript("OnUpdate", nil)
        end)
    end

    -- Position near cursor
    local cx, cy = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    quickMenu:ClearAllPoints()
    quickMenu:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", cx / scale, cy / scale)
    quickMenu:Show()
end

function addon:ToggleMinimapButton(show)
    if minimapButton then
        if show then
            minimapButton:Show()
        else
            minimapButton:Hide()
        end
    end
end
