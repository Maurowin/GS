----------------------------------------------------------------------
-- MPBlacklist - ImportExport.lua
-- Import and export blacklist data for sharing between players
-- Uses a simple serialization format with base64-like encoding
----------------------------------------------------------------------

local addonName, addon = ...

----------------------------------------------------------------------
-- Simple Serializer (no external libs needed in WoW)
----------------------------------------------------------------------
local function SerializeTable(t)
    local parts = {}
    for key, data in pairs(t) do
        local fields = {
            key,
            data.name or "",
            data.server or "",
            data.class or "",
            data.reason or "",
            data.notes or "",
            data.date or "",
            data.dungeon or "",
            tostring(data.rating or 0),
            data.addedBy or "",
        }

        -- Encode records
        local recordParts = {}
        if data.records then
            for _, rec in ipairs(data.records) do
                local rFields = {
                    rec.reason or "",
                    rec.notes or "",
                    rec.date or "",
                    rec.dungeon or "",
                    tostring(rec.rating or 0),
                }
                table.insert(recordParts, table.concat(rFields, "\003"))
            end
        end
        table.insert(fields, table.concat(recordParts, "\004"))

        table.insert(parts, table.concat(fields, "\002"))
    end
    return table.concat(parts, "\001")
end

local function DeserializeTable(str)
    local result = {}
    local entries = { strsplit("\001", str) }

    for _, entryStr in ipairs(entries) do
        if entryStr and entryStr ~= "" then
            local fields = { strsplit("\002", entryStr) }
            local key = fields[1]

            if key and key ~= "" then
                local records = {}
                if fields[11] and fields[11] ~= "" then
                    local recordStrs = { strsplit("\004", fields[11]) }
                    for _, rStr in ipairs(recordStrs) do
                        if rStr ~= "" then
                            local rFields = { strsplit("\003", rStr) }
                            table.insert(records, {
                                reason = rFields[1] or "",
                                notes = rFields[2] or "",
                                date = rFields[3] or "",
                                dungeon = rFields[4] or "",
                                rating = tonumber(rFields[5]) or 0,
                                screenshots = {},
                            })
                        end
                    end
                end

                result[key] = {
                    name = fields[2] or "",
                    server = fields[3] or "",
                    class = fields[4] or "",
                    reason = fields[5] or "",
                    notes = fields[6] or "",
                    date = fields[7] or "",
                    dungeon = fields[8] or "",
                    rating = tonumber(fields[9]) or 0,
                    addedBy = fields[10] or "",
                    records = records,
                    screenshots = {},
                }
            end
        end
    end

    return result
end

----------------------------------------------------------------------
-- Base64 Encode/Decode (WoW compatible)
----------------------------------------------------------------------
local b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

local function Base64Encode(data)
    local result = {}
    local pad = ""
    local len = #data

    -- Pad to multiple of 3
    local remainder = len % 3
    if remainder > 0 then
        pad = string.rep("=", 3 - remainder)
        data = data .. string.rep("\0", 3 - remainder)
        len = len + (3 - remainder)
    end

    for i = 1, len, 3 do
        local b1, b2, b3 = data:byte(i, i + 2)
        local n = b1 * 65536 + b2 * 256 + b3

        local c1 = math.floor(n / 262144) % 64
        local c2 = math.floor(n / 4096) % 64
        local c3 = math.floor(n / 64) % 64
        local c4 = n % 64

        table.insert(result, b64chars:sub(c1 + 1, c1 + 1))
        table.insert(result, b64chars:sub(c2 + 1, c2 + 1))
        table.insert(result, b64chars:sub(c3 + 1, c3 + 1))
        table.insert(result, b64chars:sub(c4 + 1, c4 + 1))
    end

    local encoded = table.concat(result)
    if #pad > 0 then
        encoded = encoded:sub(1, #encoded - #pad) .. pad
    end

    return encoded
end

local function Base64Decode(data)
    data = data:gsub("[^A-Za-z0-9+/=]", "")
    local padLen = 0
    if data:sub(-2) == "==" then
        padLen = 2
    elseif data:sub(-1) == "=" then
        padLen = 1
    end
    data = data:gsub("=", "A")

    local result = {}
    for i = 1, #data, 4 do
        local c1, c2, c3, c4
        c1 = (b64chars:find(data:sub(i, i)) or 1) - 1
        c2 = (b64chars:find(data:sub(i + 1, i + 1)) or 1) - 1
        c3 = (b64chars:find(data:sub(i + 2, i + 2)) or 1) - 1
        c4 = (b64chars:find(data:sub(i + 3, i + 3)) or 1) - 1

        local n = c1 * 262144 + c2 * 4096 + c3 * 64 + c4

        table.insert(result, string.char(math.floor(n / 65536) % 256))
        table.insert(result, string.char(math.floor(n / 256) % 256))
        table.insert(result, string.char(n % 256))
    end

    local decoded = table.concat(result)
    if padLen > 0 then
        decoded = decoded:sub(1, #decoded - padLen)
    end
    return decoded
end

----------------------------------------------------------------------
-- Export blacklist to shareable string
----------------------------------------------------------------------
function addon:ExportBlacklist()
    if not self.db or not self.db.blacklist then return "" end

    local count = self:GetBlacklistCount()
    if count == 0 then
        self:Print(self.colors.warning .. "避雷名单为空，无法导出！")
        return ""
    end

    local serialized = SerializeTable(self.db.blacklist)
    local encoded = "MPBL1:" .. Base64Encode(serialized)

    self:Print(self.colors.success .. "已导出 " .. count .. " 条避雷记录")
    return encoded
end

----------------------------------------------------------------------
-- Import blacklist from shared string
----------------------------------------------------------------------
function addon:ImportBlacklist(str, mode)
    if not str or str == "" then
        self:Print(self.colors.warning .. "导入字符串为空！")
        return 0
    end

    -- Try plain text import first (not starting with MPBL1:)
    if not str:find("^MPBL1:") then
        return self:ImportPlainText(str, mode)
    end

    local encoded = str:sub(7)  -- Remove "MPBL1:" prefix
    local ok, serialized = pcall(Base64Decode, encoded)
    if not ok or not serialized then
        self:Print(self.colors.warning .. "解码失败！数据可能已损坏")
        return 0
    end

    local ok2, imported = pcall(DeserializeTable, serialized)
    if not ok2 or not imported then
        self:Print(self.colors.warning .. "反序列化失败！数据可能已损坏")
        return 0
    end

    local count = 0
    local skipped = 0
    mode = mode or "merge"  -- "merge" or "replace"

    if mode == "replace" then
        wipe(self.db.blacklist)
    end

    for key, data in pairs(imported) do
        if mode == "merge" and self.db.blacklist[key] then
            -- Merge records
            local existing = self.db.blacklist[key]
            if data.records then
                for _, rec in ipairs(data.records) do
                    table.insert(existing.records, rec)
                end
            end
            skipped = skipped + 1
        else
            self.db.blacklist[key] = data
            count = count + 1
        end
    end

    self:Print(self.colors.success .. "导入完成！新增 " .. count .. " 条记录")
    if skipped > 0 then
        self:Print(self.colors.info .. "合并了 " .. skipped .. " 条已存在的记录")
    end

    if addon.mainFrame and addon.mainFrame:IsShown() then
        addon:RefreshPlayerList()
    end

    return count
end

----------------------------------------------------------------------
-- Plain Text Import
-- Supported formats (one entry per line):
--   角色名-服务器 原因
--   角色名 原因
--   角色名-服务器
--   角色名
-- Lines starting with # are comments and will be skipped
----------------------------------------------------------------------
function addon:ImportPlainText(str, mode)
    if not str or str == "" then
        self:Print(self.colors.warning .. "导入内容为空！")
        return 0
    end

    local count = 0
    local skipped = 0
    mode = mode or "merge"

    if mode == "replace" then
        wipe(self.db.blacklist)
    end

    -- Build a lookup set of known class names for detection
    local knownClasses = {}
    if addon.classList then
        for _, cls in ipairs(addon.classList) do
            knownClasses[cls] = true
        end
    end

    -- Split by newlines
    for line in str:gmatch("[^\r\n]+") do
        line = strtrim(line)
        -- Skip empty lines and comments
        if line ~= "" and not line:find("^#") and not line:find("^//") then
            local name, server, class, reason = "", "", "未知", ""

            -- Try to parse: name-server [class] reason
            local nameServer, rest = line:match("^(%S+)%s+(.+)$")
            if not nameServer then
                nameServer = line
                rest = ""
            end

            -- Split name-server
            local n, s = nameServer:match("^(.+)-(.+)$")
            if n and s then
                name = strtrim(n)
                server = strtrim(s)
            else
                name = strtrim(nameServer)
            end

            -- Try to detect class from the first word of 'rest'
            if rest and rest ~= "" then
                local firstWord, remainder = rest:match("^(%S+)%s*(.*)")
                if firstWord and knownClasses[firstWord] then
                    class = firstWord
                    reason = strtrim(remainder or "")
                else
                    reason = strtrim(rest)
                end
            end

            if name ~= "" then
                local key = self:MakeKey(name, server)
                if mode == "merge" and self.db.blacklist[key] then
                    skipped = skipped + 1
                else
                    self.db.blacklist[key] = {
                        name = name,
                        server = server,
                        class = class,
                        reason = reason,
                        notes = "",
                        date = self:GetCurrentDate(),
                        dungeon = "",
                        rating = 0,
                        addedBy = UnitName("player") or "Unknown",
                        records = {{
                            reason = reason,
                            notes = "",
                            date = self:GetCurrentDate(),
                            dungeon = "",
                            rating = 0,
                            screenshots = {},
                        }},
                        screenshots = {},
                    }
                    count = count + 1
                end
            end
        end
    end

    if count > 0 then
        self:Print(self.colors.success .. "纯文本导入完成！新增 " .. count .. " 条记录")
    else
        self:Print(self.colors.warning .. "未能从文本中解析出有效记录")
    end
    if skipped > 0 then
        self:Print(self.colors.info .. "跳过了 " .. skipped .. " 条已存在的记录")
    end

    if addon.mainFrame and addon.mainFrame:IsShown() then
        addon:RefreshPlayerList()
    end

    return count
end

-- Shared UI helper reference (CreateStyledButton defined in UI.lua loads first)
local function CreateStyledButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(width or 100, height or 24)
    btn:SetText(text)
    return btn
end
function addon:ShowImportUI()
    if self.importFrame and self.importFrame:IsShown() then
        self.importFrame:Hide()
        return
    end

    if not self.importFrame then
        local imf = CreateFrame("Frame", "MPBlacklistImportFrame", UIParent, "BasicFrameTemplateWithInset")
        imf:SetSize(500, 440)
        imf:SetPoint("CENTER")
        imf:SetMovable(true)
        imf:EnableMouse(true)
        imf:RegisterForDrag("LeftButton")
        imf:SetScript("OnDragStart", imf.StartMoving)
        imf:SetScript("OnDragStop", imf.StopMovingOrSizing)
        imf:SetFrameStrata("DIALOG")
        imf:SetClampedToScreen(true)
        tinsert(UISpecialFrames, "MPBlacklistImportFrame")

        imf.TitleText:SetText("|cff44ff44导入避雷名单|r")

        -- Instructions
        local instrText = imf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        instrText:SetPoint("TOPLEFT", imf, "TOPLEFT", 16, -35)
        instrText:SetWidth(468)
        instrText:SetJustifyH("LEFT")
        instrText:SetText("粘贴导入数据到下方（支持插件导出字符串和纯文本格式）：")

        -- Format example
        local exampleText = imf:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        exampleText:SetPoint("TOPLEFT", imf, "TOPLEFT", 16, -55)
        exampleText:SetWidth(468)
        exampleText:SetJustifyH("LEFT")
        exampleText:SetText("|cffffff00纯文本格式示例（每行一条）:|r\n" ..
            "张三-凤凰之翼 战士 挂机摸鱼\n" ..
            "李四-暗影之月 猎人 低分乱进\n" ..
            "王五 恶意拉怪\n" ..
            "|cff888888# 以 # 开头的行为注释会被跳过|r\n" ..
            "|cff888888# 格式: 名字-服务器 职业 原因|r")

        -- Text area background
        local textBg = CreateFrame("Frame", nil, imf, BackdropTemplateMixin and "BackdropTemplate" or nil)
        textBg:SetSize(468, 150)
        textBg:SetPoint("TOPLEFT", imf, "TOPLEFT", 16, -165)
        if textBg.SetBackdrop then
            textBg:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            textBg:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
            textBg:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8)
        end

        local scrollFrame = CreateFrame("ScrollFrame", nil, textBg, "UIPanelScrollFrameTemplate")
        scrollFrame:SetPoint("TOPLEFT", textBg, "TOPLEFT", 8, -6)
        scrollFrame:SetPoint("BOTTOMRIGHT", textBg, "BOTTOMRIGHT", -26, 6)

        local editBox = CreateFrame("EditBox", nil, scrollFrame)
        editBox:SetSize(430, 150)
        editBox:SetFontObject(ChatFontNormal)
        editBox:SetMultiLine(true)
        editBox:SetAutoFocus(false)
        editBox:SetMaxLetters(0)
        scrollFrame:SetScrollChild(editBox)
        editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        imf.editBox = editBox

        -- Mode selection
        local modeLabel = imf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        modeLabel:SetPoint("TOPLEFT", textBg, "BOTTOMLEFT", 0, -10)
        modeLabel:SetText("导入模式:")

        local mergeBtn = CreateFrame("CheckButton", nil, imf, "UIRadioButtonTemplate")
        mergeBtn:SetPoint("LEFT", modeLabel, "RIGHT", 10, 0)
        local mergeBtnText = mergeBtn.text or mergeBtn.Text
        if not mergeBtnText then
            mergeBtnText = mergeBtn:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
            mergeBtnText:SetPoint("LEFT", mergeBtn, "RIGHT", 2, 0)
            mergeBtn.text = mergeBtnText
        end
        mergeBtnText:SetText("合并（推荐）")
        mergeBtn:SetChecked(true)
        imf.mergeBtn = mergeBtn

        local replaceBtn = CreateFrame("CheckButton", nil, imf, "UIRadioButtonTemplate")
        replaceBtn:SetPoint("LEFT", mergeBtn, "RIGHT", 100, 0)
        local replaceBtnText = replaceBtn.text or replaceBtn.Text
        if not replaceBtnText then
            replaceBtnText = replaceBtn:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
            replaceBtnText:SetPoint("LEFT", replaceBtn, "RIGHT", 2, 0)
            replaceBtn.text = replaceBtnText
        end
        replaceBtnText:SetText("替换全部")
        imf.replaceBtn = replaceBtn

        mergeBtn:SetScript("OnClick", function()
            mergeBtn:SetChecked(true)
            replaceBtn:SetChecked(false)
        end)
        replaceBtn:SetScript("OnClick", function()
            replaceBtn:SetChecked(true)
            mergeBtn:SetChecked(false)
        end)

        -- Import button
        local importBtn = CreateStyledButton(imf, "|cff44ff44确认导入|r", 120, 28)
        importBtn:SetPoint("BOTTOMLEFT", imf, "BOTTOMLEFT", 16, 14)
        importBtn:SetScript("OnClick", function()
            local text = imf.editBox:GetText()
            local mode = imf.mergeBtn:GetChecked() and "merge" or "replace"

            if mode == "replace" then
                StaticPopupDialogs["MPBL_CONFIRM_IMPORT_REPLACE"] = {
                    text = "|cffff4444警告|r\n\n替换模式将清空当前所有避雷记录！\n确定要继续吗？",
                    button1 = "确定替换",
                    button2 = "取消",
                    OnAccept = function()
                        addon:ImportBlacklist(text, "replace")
                        imf:Hide()
                    end,
                    timeout = 0,
                    whileDead = true,
                    hideOnEscape = true,
                    preferredIndex = 3,
                }
                StaticPopup_Show("MPBL_CONFIRM_IMPORT_REPLACE")
            else
                addon:ImportBlacklist(text, mode)
                imf:Hide()
            end
        end)

        -- Cancel button
        local cancelBtn = CreateStyledButton(imf, "取消", 80, 28)
        cancelBtn:SetPoint("LEFT", importBtn, "RIGHT", 10, 0)
        cancelBtn:SetScript("OnClick", function() imf:Hide() end)

        self.importFrame = imf
    end

    self.importFrame.editBox:SetText("")
    self.importFrame:Show()
    self.importFrame.editBox:SetFocus()
end

----------------------------------------------------------------------
-- Export UI
----------------------------------------------------------------------
function addon:ShowExportUI()
    if self.exportFrame and self.exportFrame:IsShown() then
        self.exportFrame:Hide()
        return
    end

    if not self.exportFrame then
        local exf = CreateFrame("Frame", "MPBlacklistExportFrame", UIParent, "BasicFrameTemplateWithInset")
        exf:SetSize(500, 300)
        exf:SetPoint("CENTER")
        exf:SetMovable(true)
        exf:EnableMouse(true)
        exf:RegisterForDrag("LeftButton")
        exf:SetScript("OnDragStart", exf.StartMoving)
        exf:SetScript("OnDragStop", exf.StopMovingOrSizing)
        exf:SetFrameStrata("DIALOG")
        exf:SetClampedToScreen(true)
        tinsert(UISpecialFrames, "MPBlacklistExportFrame")

        exf.TitleText:SetText("|cffff8800导出避雷名单|r")

        -- Instructions
        local instrText = exf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        instrText:SetPoint("TOPLEFT", exf, "TOPLEFT", 16, -35)
        instrText:SetText("复制下方字符串分享给其他玩家（Ctrl+A 全选，Ctrl+C 复制）：")

        -- Text area background
        local textBg = CreateFrame("Frame", nil, exf, BackdropTemplateMixin and "BackdropTemplate" or nil)
        textBg:SetSize(468, 180)
        textBg:SetPoint("TOPLEFT", exf, "TOPLEFT", 16, -58)
        if textBg.SetBackdrop then
            textBg:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            textBg:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
            textBg:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8)
        end

        local scrollFrame = CreateFrame("ScrollFrame", nil, textBg, "UIPanelScrollFrameTemplate")
        scrollFrame:SetPoint("TOPLEFT", textBg, "TOPLEFT", 8, -6)
        scrollFrame:SetPoint("BOTTOMRIGHT", textBg, "BOTTOMRIGHT", -26, 6)

        local editBox = CreateFrame("EditBox", nil, scrollFrame)
        editBox:SetSize(430, 170)
        editBox:SetFontObject(ChatFontNormal)
        editBox:SetMultiLine(true)
        editBox:SetAutoFocus(false)
        editBox:SetMaxLetters(0)
        scrollFrame:SetScrollChild(editBox)
        editBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        exf.editBox = editBox

        -- Select all button
        local selectBtn = CreateStyledButton(exf, "全选复制", 100, 28)
        selectBtn:SetPoint("BOTTOMLEFT", exf, "BOTTOMLEFT", 16, 14)
        selectBtn:SetScript("OnClick", function()
            exf.editBox:SetFocus()
            exf.editBox:HighlightText()
        end)

        -- Close button
        local closeBtn = CreateStyledButton(exf, "关闭", 80, 28)
        closeBtn:SetPoint("LEFT", selectBtn, "RIGHT", 10, 0)
        closeBtn:SetScript("OnClick", function() exf:Hide() end)

        self.exportFrame = exf
    end

    -- Generate export data
    local exportStr = self:ExportBlacklist()
    self.exportFrame.editBox:SetText(exportStr)
    self.exportFrame:Show()
    self.exportFrame.editBox:SetFocus()
    self.exportFrame.editBox:HighlightText()
end
