----------------------------------------------------------------------
-- MPBlacklist - UI.lua
-- Main user interface for the blacklist system
-- All custom widgets (no UIDropDownMenu to avoid taint in 12.0+)
----------------------------------------------------------------------

local addonName, addon = ...

local FRAME_WIDTH = 700
local FRAME_HEIGHT = 550
local ROW_HEIGHT = 28

----------------------------------------------------------------------
-- Helper: Create styled button
----------------------------------------------------------------------
local function CreateStyledButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    btn:SetSize(width or 100, height or 24)
    btn:SetText(text)
    return btn
end

----------------------------------------------------------------------
-- Helper: Create input box (no InputBoxTemplate - manual creation for 12.0+ compat)
----------------------------------------------------------------------
local function CreateInputBox(parent, width, height, placeholder)
    local box = CreateFrame("EditBox", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    box:SetSize(width or 150, height or 22)
    box:SetAutoFocus(false)
    box:SetFontObject(ChatFontNormal or GameFontHighlightSmall)

    -- Manual backdrop (replaces InputBoxTemplate visuals)
    if box.SetBackdrop then
        box:SetBackdrop({
            bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
            edgeFile = "Interface\\ChatFrame\\ChatFrameBackground",
            tile = true, tileSize = 5, edgeSize = 1,
            insets = { left = 2, right = 2, top = 2, bottom = 2 },
        })
        box:SetBackdropColor(0.05, 0.05, 0.05, 0.8)
        box:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8)
    end

    box:SetTextInsets(6, 4, 0, 0)
    box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)

    if placeholder then
        box.placeholder = box:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
        box.placeholder:SetPoint("LEFT", box, "LEFT", 6, 0)
        box.placeholder:SetText(placeholder)
        box:SetScript("OnTextChanged", function(self)
            if self:GetText() == "" then
                self.placeholder:Show()
            else
                self.placeholder:Hide()
            end
        end)
    end
    return box
end

----------------------------------------------------------------------
-- Helper: Custom Dropdown (no taint)
----------------------------------------------------------------------
local function CreateCustomDropdown(parent, width, items, onSelect)
    local dd = CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
    dd:SetSize(width or 200, 26)
    dd:EnableMouse(true)

    -- Button area
    local ddBtn = CreateFrame("Button", nil, dd)
    ddBtn:SetAllPoints()

    local ddBg = ddBtn:CreateTexture(nil, "BACKGROUND")
    ddBg:SetAllPoints()
    ddBg:SetColorTexture(0.1, 0.1, 0.1, 0.8)

    local ddBorder = ddBtn:CreateTexture(nil, "BORDER")
    ddBorder:SetPoint("TOPLEFT", -1, 1)
    ddBorder:SetPoint("BOTTOMRIGHT", 1, -1)
    ddBorder:SetColorTexture(0.4, 0.35, 0.2, 0.8)

    local ddInner = ddBtn:CreateTexture(nil, "ARTWORK")
    ddInner:SetPoint("TOPLEFT", 1, -1)
    ddInner:SetPoint("BOTTOMRIGHT", -1, 1)
    ddInner:SetColorTexture(0.12, 0.12, 0.15, 0.9)

    local ddText = ddBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ddText:SetPoint("LEFT", ddBtn, "LEFT", 8, 0)
    ddText:SetPoint("RIGHT", ddBtn, "RIGHT", -20, 0)
    ddText:SetJustifyH("LEFT")
    ddText:SetText("选择...")
    dd.text = ddText

    local ddArrow = ddBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ddArrow:SetPoint("RIGHT", ddBtn, "RIGHT", -6, 0)
    ddArrow:SetText("|cffffd100▼|r")

    -- Popup list
    local popup = CreateFrame("Frame", nil, dd, BackdropTemplateMixin and "BackdropTemplate" or nil)
    popup:SetFrameStrata("TOOLTIP")
    popup:SetClampedToScreen(true)
    popup:EnableMouse(true)
    if popup.SetBackdrop then
        popup:SetBackdrop({
            bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true, tileSize = 16, edgeSize = 16,
            insets = { left = 4, right = 4, top = 4, bottom = 4 },
        })
        popup:SetBackdropColor(0.08, 0.08, 0.12, 0.95)
        popup:SetBackdropBorderColor(0.5, 0.4, 0.2, 0.8)
    end
    popup:Hide()
    dd.popup = popup

    local function BuildItems(itemList)
        -- Clear old
        if popup.buttons then
            for _, b in ipairs(popup.buttons) do b:Hide() end
        end
        popup.buttons = {}

        local itemH = 22
        local maxVisible = math.min(#itemList, 12)
        popup:SetSize(width or 200, maxVisible * itemH + 10)
        popup:SetPoint("TOPLEFT", dd, "BOTTOMLEFT", 0, -2)

        for i, item in ipairs(itemList) do
            if i > 12 then break end
            local ibtn = CreateFrame("Button", nil, popup)
            ibtn:SetSize((width or 200) - 10, itemH)
            ibtn:SetPoint("TOPLEFT", popup, "TOPLEFT", 5, -5 - (i - 1) * itemH)

            local ihl = ibtn:CreateTexture(nil, "HIGHLIGHT")
            ihl:SetAllPoints()
            ihl:SetColorTexture(0.4, 0.35, 0.1, 0.4)

            local ilabel = ibtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            ilabel:SetPoint("LEFT", ibtn, "LEFT", 6, 0)
            ilabel:SetText(item.display or item.value or "")

            ibtn:SetScript("OnClick", function()
                ddText:SetText(item.display or item.value or "")
                dd.selectedValue = item.value
                popup:Hide()
                if onSelect then onSelect(item.value, item.display) end
            end)

            table.insert(popup.buttons, ibtn)
        end
    end

    if items then BuildItems(items) end
    dd.BuildItems = BuildItems

    ddBtn:SetScript("OnClick", function()
        if popup:IsShown() then
            popup:Hide()
        else
            popup:Show()
        end
    end)

    -- Close popup when clicking elsewhere
    popup:SetScript("OnShow", function(self)
        self:SetScript("OnUpdate", function(self2)
            if not self2:IsMouseOver() and not dd:IsMouseOver() and IsMouseButtonDown("LeftButton") then
                self2:Hide()
            end
        end)
    end)
    popup:SetScript("OnHide", function(self)
        self:SetScript("OnUpdate", nil)
    end)

    function dd:SetSelectedText(txt)
        ddText:SetText(txt or "选择...")
    end

    function dd:GetSelectedValue()
        return self.selectedValue
    end

    return dd
end

----------------------------------------------------------------------
-- MAIN FRAME
----------------------------------------------------------------------
function addon:ToggleMainUI()
    if not self.mainFrame then
        self:CreateMainUI()
    end
    if self.mainFrame:IsShown() then
        self.mainFrame:Hide()
    else
        self.mainFrame:Show()
        self:RefreshPlayerList()
    end
end

function addon:CreateMainUI()
    if self.mainFrame then return end

    -- Main frame
    local f = CreateFrame("Frame", "MPBlacklistMainFrame", UIParent, "BasicFrameTemplateWithInset")
    f:SetSize(FRAME_WIDTH, FRAME_HEIGHT)
    f:SetPoint("CENTER")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetFrameStrata("HIGH")
    f:SetClampedToScreen(true)
    f:Hide()
    tinsert(UISpecialFrames, "MPBlacklistMainFrame")

    -- Title
    f.TitleText:SetText("|cff00ccff飞鸟的黑名单|r - 避雷名单 v" .. addon.version)

    -- ===== Row 1: Stats =====
    local statsText = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    statsText:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -32)
    f.statsText = statsText

    -- ===== Row 2: Search bar + Action buttons =====
    local searchBox = CreateInputBox(f, 200, 24, "搜索角色名/区服/原因...")
    searchBox:SetPoint("TOPLEFT", f, "TOPLEFT", 14, -52)
    searchBox:SetScript("OnEnterPressed", function(self)
        addon:RefreshPlayerList(self:GetText())
        self:ClearFocus()
    end)
    searchBox:SetScript("OnTextChanged", function(self)
        if self.placeholder then
            if self:GetText() == "" then
                self.placeholder:Show()
            else
                self.placeholder:Hide()
            end
        end
        addon:RefreshPlayerList(self:GetText())
    end)
    f.searchBox = searchBox

    local addBtn = CreateStyledButton(f, "添加避雷", 90, 24)
    addBtn:SetPoint("LEFT", searchBox, "RIGHT", 10, 0)
    addBtn:SetScript("OnClick", function() addon:ShowAddPlayerUI() end)

    local importBtn = CreateStyledButton(f, "导入", 60, 24)
    importBtn:SetPoint("LEFT", addBtn, "RIGHT", 6, 0)
    importBtn:SetScript("OnClick", function() addon:ShowImportUI() end)

    local exportBtn = CreateStyledButton(f, "导出", 60, 24)
    exportBtn:SetPoint("LEFT", importBtn, "RIGHT", 6, 0)
    exportBtn:SetScript("OnClick", function() addon:ShowExportUI() end)

    local settingsBtn = CreateStyledButton(f, "设置", 60, 24)
    settingsBtn:SetPoint("LEFT", exportBtn, "RIGHT", 6, 0)
    settingsBtn:SetScript("OnClick", function() addon:ShowSettingsUI() end)

    -- ===== Row 3: Column headers (below search row with proper gap) =====
    local headerFrame = CreateFrame("Frame", nil, f)
    headerFrame:SetSize(FRAME_WIDTH - 20, 22)
    headerFrame:SetPoint("TOPLEFT", f, "TOPLEFT", 10, -84)

    local headerBg = headerFrame:CreateTexture(nil, "BACKGROUND")
    headerBg:SetAllPoints()
    headerBg:SetColorTexture(0.15, 0.15, 0.15, 0.8)

    local headers = {
        { text = "角色名",    x = 6 },
        { text = "区服",      x = 132 },
        { text = "职业",      x = 238 },
        { text = "失误/原因", x = 314 },
        { text = "日期",      x = 520 },
        { text = "操作",      x = 630 },
    }

    for _, h in ipairs(headers) do
        local text = headerFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        text:SetPoint("LEFT", headerFrame, "LEFT", h.x, 0)
        text:SetText("|cffffff00" .. h.text .. "|r")
    end

    -- ===== Scroll frame for player list =====
    local scrollParent = CreateFrame("Frame", nil, f)
    scrollParent:SetPoint("TOPLEFT", headerFrame, "BOTTOMLEFT", 0, -2)
    scrollParent:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -28, 10)
    scrollParent:SetClipsChildren(true)

    local scrollFrame = CreateFrame("ScrollFrame", "MPBlacklistScrollFrame", scrollParent, "UIPanelScrollFrameTemplate")
    scrollFrame:SetAllPoints()

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(FRAME_WIDTH - 48, 1)
    scrollFrame:SetScrollChild(scrollChild)

    f.scrollChild = scrollChild
    f.scrollFrame = scrollFrame
    f.rows = {}

    self.mainFrame = f
end

----------------------------------------------------------------------
-- Refresh the player list
----------------------------------------------------------------------
function addon:RefreshPlayerList(filter)
    if not self.mainFrame then return end

    local scrollChild = self.mainFrame.scrollChild
    -- Clear old rows
    for _, row in ipairs(self.mainFrame.rows) do
        row:Hide()
        row:SetParent(nil)
    end
    wipe(self.mainFrame.rows)

    local list = self:GetSortedBlacklist()
    filter = filter and strtrim(filter):lower() or ""

    local filtered = {}
    for _, entry in ipairs(list) do
        if filter == "" then
            table.insert(filtered, entry)
        else
            local d = entry.data
            if d.name:lower():find(filter, 1, true)
                or d.server:lower():find(filter, 1, true)
                or d.class:lower():find(filter, 1, true)
                or d.reason:lower():find(filter, 1, true) then
                table.insert(filtered, entry)
            end
        end
    end

    -- Update stats
    local total = self:GetBlacklistCount()
    self.mainFrame.statsText:SetText(string.format(
        "|cffffffff避雷名单: |cffff8800%d|r 人  |cff888888(显示 %d 条)|r",
        total, #filtered
    ))

    scrollChild:SetSize(FRAME_WIDTH - 48, math.max(#filtered * ROW_HEIGHT, 1))

    for i, entry in ipairs(filtered) do
        local d = entry.data
        local row = CreateFrame("Button", nil, scrollChild)
        row:SetSize(FRAME_WIDTH - 50, ROW_HEIGHT)
        row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -(i - 1) * ROW_HEIGHT)

        -- Alternating background
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        if i % 2 == 0 then
            bg:SetColorTexture(0.12, 0.12, 0.12, 0.6)
        else
            bg:SetColorTexture(0.08, 0.08, 0.08, 0.3)
        end

        local hl = row:CreateTexture(nil, "HIGHLIGHT")
        hl:SetAllPoints()
        hl:SetColorTexture(0.3, 0.3, 0.1, 0.3)

        -- Name
        local nameText = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameText:SetPoint("LEFT", row, "LEFT", 4, 0)
        nameText:SetWidth(120)
        nameText:SetJustifyH("LEFT")
        local visTag = ""
        nameText:SetText("|cffff4444" .. d.name .. "|r" .. visTag)

        -- Server
        local serverText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        serverText:SetPoint("LEFT", row, "LEFT", 130, 0)
        serverText:SetWidth(100)
        serverText:SetJustifyH("LEFT")
        serverText:SetText(d.server ~= "" and d.server or "-")

        -- Class
        local classText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        classText:SetPoint("LEFT", row, "LEFT", 236, 0)
        classText:SetWidth(70)
        classText:SetJustifyH("LEFT")
        classText:SetText(addon:GetColoredClass(d.class))

        -- Reason
        local reasonText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        reasonText:SetPoint("LEFT", row, "LEFT", 312, 0)
        reasonText:SetWidth(200)
        reasonText:SetJustifyH("LEFT")
        local reasonStr = d.reason or ""
        if #reasonStr > 24 then
            reasonStr = reasonStr:sub(1, 24) .. "..."
        end
        reasonText:SetText(reasonStr)

        -- Date
        local dateText = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        dateText:SetPoint("LEFT", row, "LEFT", 518, 0)
        dateText:SetWidth(100)
        dateText:SetJustifyH("LEFT")
        dateText:SetText("|cff888888" .. (d.date or "") .. "|r")

        -- Delete button
        local delBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        delBtn:SetSize(40, 20)
        delBtn:SetPoint("LEFT", row, "LEFT", 622, 0)
        delBtn:SetText("|cffff4444删|r")
        delBtn:SetScript("OnClick", function()
            StaticPopupDialogs["MPBL_CONFIRM_DELETE"] = {
                text = "确定要将 |cffff4444" .. d.name .. "|r 从避雷名单中移除吗？",
                button1 = "确定",
                button2 = "取消",
                OnAccept = function()
                    addon:RemovePlayer(entry.key)
                end,
                timeout = 0,
                whileDead = true,
                hideOnEscape = true,
                preferredIndex = 3,
            }
            StaticPopup_Show("MPBL_CONFIRM_DELETE")
        end)

        -- Tooltip
        row:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine("|cffff4444⚠ 避雷玩家|r", 1, 1, 1)
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine("角色名:", d.name, 0.7, 0.7, 0.7, 1, 1, 1)
            GameTooltip:AddDoubleLine("区服:", d.server ~= "" and d.server or "未知", 0.7, 0.7, 0.7, 1, 1, 1)
            GameTooltip:AddDoubleLine("职业:", d.class, 0.7, 0.7, 0.7, 1, 1, 1)
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("|cffffff00失误/原因:|r", 1, 0.82, 0)
            GameTooltip:AddLine(d.reason or "无", 1, 1, 1, true)
            if d.notes and d.notes ~= "" then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine("|cffffff00备注:|r", 1, 0.82, 0)
                GameTooltip:AddLine(d.notes, 0.8, 0.8, 0.8, true)
            end
            if d.dungeon and d.dungeon ~= "" then
                GameTooltip:AddDoubleLine("副本:", d.dungeon, 0.7, 0.7, 0.7, 1, 1, 1)
            end
            GameTooltip:AddLine(" ")
            GameTooltip:AddDoubleLine("添加日期:", d.date or "未知", 0.7, 0.7, 0.7, 0.5, 0.5, 0.5)
            GameTooltip:AddDoubleLine("添加者:", d.addedBy or "未知", 0.7, 0.7, 0.7, 0.5, 0.5, 0.5)

            if d.records and #d.records > 1 then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine("|cffffff00历史记录 (" .. #d.records .. " 条):|r")
                for ri, rec in ipairs(d.records) do
                    local recStr = string.format("[%s] %s", rec.date or "?", rec.reason or "")
                    GameTooltip:AddLine("  " .. ri .. ". " .. recStr, 0.7, 0.7, 0.7, true)
                end
            end

            if d.records then
                for _, rec in ipairs(d.records) do
                    if rec.screenshots and #rec.screenshots > 0 then
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine("|cff44ff44有截图记录|r")
                        break
                    end
                end
            end

            GameTooltip:Show()
        end)

        row:SetScript("OnLeave", function() GameTooltip:Hide() end)

        row:SetScript("OnDoubleClick", function()
            addon:ShowEditPlayerUI(entry.key, d)
        end)

        table.insert(self.mainFrame.rows, row)
    end
end

----------------------------------------------------------------------
-- ADD PLAYER UI (custom dropdown, no UIDropDownMenu)
----------------------------------------------------------------------
function addon:ShowAddPlayerUI(prefillName, prefillServer)
    if self.addFrame and self.addFrame:IsShown() then
        self.addFrame:Hide()
        return
    end

    if not self.addFrame then
        local af = CreateFrame("Frame", "MPBlacklistAddFrame", UIParent, "BasicFrameTemplateWithInset")
        af:SetSize(420, 420)
        af:SetPoint("CENTER", 200, 0)
        af:SetMovable(true)
        af:EnableMouse(true)
        af:RegisterForDrag("LeftButton")
        af:SetScript("OnDragStart", af.StartMoving)
        af:SetScript("OnDragStop", af.StopMovingOrSizing)
        af:SetFrameStrata("DIALOG")
        af:SetClampedToScreen(true)
        tinsert(UISpecialFrames, "MPBlacklistAddFrame")

        af.TitleText:SetText("|cffff4444添加避雷玩家|r")

        local y = -35
        local labelX = 16
        local inputX = 90

        -- Name
        local nameLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        nameLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        nameLabel:SetText("角色名:")
        local nameInput = CreateInputBox(af, 200, 22, "输入角色名")
        nameInput:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        af.nameInput = nameInput

        y = y - 32
        -- Server
        local serverLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        serverLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        serverLabel:SetText("区服:")
        local serverInput = CreateInputBox(af, 200, 22, "输入区服名称")
        serverInput:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        af.serverInput = serverInput

        y = y - 32
        -- Class (custom dropdown)
        local classLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        classLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        classLabel:SetText("职业:")

        local classItems = {}
        for _, cls in ipairs(addon.classList) do
            table.insert(classItems, {
                value = cls,
                display = addon:GetColoredClass(cls),
            })
        end
        af.selectedClass = "未知"

        local classDropdown = CreateCustomDropdown(af, 200, classItems, function(value)
            af.selectedClass = value
        end)
        classDropdown:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y + 2)
        classDropdown:SetSelectedText("选择职业")
        af.classDropdown = classDropdown

        y = y - 36
        -- Dungeon
        local dungeonLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        dungeonLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        dungeonLabel:SetText("副本:")
        local dungeonInput = CreateInputBox(af, 200, 22, "例: 千丝之城+15")
        dungeonInput:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        af.dungeonInput = dungeonInput

        y = y - 32
        -- Reason
        local reasonLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        reasonLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        reasonLabel:SetText("原因:")
        local reasonInput = CreateInputBox(af, 300, 22, "输入避雷原因")
        reasonInput:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        af.reasonInput = reasonInput

        y = y - 42
        -- Notes (multiline)
        local notesLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        notesLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        notesLabel:SetText("备注:")

        local notesBg = CreateFrame("Frame", nil, af, BackdropTemplateMixin and "BackdropTemplate" or nil)
        notesBg:SetSize(300, 70)
        notesBg:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y + 4)
        if notesBg.SetBackdrop then
            notesBg:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true, tileSize = 16, edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            notesBg:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
            notesBg:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8)
        end

        local notesScroll = CreateFrame("ScrollFrame", nil, notesBg, "UIPanelScrollFrameTemplate")
        notesScroll:SetPoint("TOPLEFT", notesBg, "TOPLEFT", 8, -6)
        notesScroll:SetPoint("BOTTOMRIGHT", notesBg, "BOTTOMRIGHT", -26, 6)

        local notesInput = CreateFrame("EditBox", nil, notesScroll)
        notesInput:SetSize(260, 60)
        notesInput:SetFontObject(ChatFontNormal)
        notesInput:SetMultiLine(true)
        notesInput:SetAutoFocus(false)
        notesInput:SetMaxLetters(500)
        notesScroll:SetScrollChild(notesInput)
        notesInput:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        af.notesInput = notesInput

        y = y - 86
        -- Screenshot note
        local ssLabel = af:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        ssLabel:SetPoint("TOPLEFT", af, "TOPLEFT", labelX, y)
        ssLabel:SetText("截图:")
        local ssInput = CreateInputBox(af, 300, 22, "截图文件名或描述（可选）")
        ssInput:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        af.ssInput = ssInput

        y = y - 36
        -- Take screenshot button
        local ssBtn = CreateStyledButton(af, "立即截图", 100, 24)
        ssBtn:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        ssBtn:SetScript("OnClick", function()
            Screenshot()
            local ssFile = "WoWScrnShot_" .. date("%m%d%y_%H%M%S") .. ".jpg"
            af.ssInput:SetText(ssFile)
            addon:Print(addon.colors.success .. "已截图: " .. ssFile)
        end)

        y = y - 36
        -- Save button
        local saveBtn = CreateStyledButton(af, "|cff44ff44确认添加|r", 120, 28)
        saveBtn:SetPoint("TOPLEFT", af, "TOPLEFT", inputX, y)
        saveBtn:SetScript("OnClick", function()
            local screenshots = {}
            local ssText = af.ssInput:GetText()
            if ssText and ssText ~= "" then
                table.insert(screenshots, {
                    file = ssText,
                    date = addon:GetCurrentDate(),
                })
            end

            local success = addon:AddPlayer({
                name = af.nameInput:GetText(),
                server = af.serverInput:GetText(),
                class = af.selectedClass,
                reason = af.reasonInput:GetText(),
                notes = af.notesInput:GetText(),
                dungeon = af.dungeonInput:GetText(),
                date = addon:GetCurrentDate(),
                screenshots = screenshots,
            })

            if success then
                af.nameInput:SetText("")
                af.serverInput:SetText("")
                af.reasonInput:SetText("")
                af.notesInput:SetText("")
                af.dungeonInput:SetText("")
                af.ssInput:SetText("")
                af.selectedClass = "未知"
                af.classDropdown:SetSelectedText("选择职业")
                af:Hide()
            end
        end)

        -- Cancel button
        local cancelBtn = CreateStyledButton(af, "取消", 80, 28)
        cancelBtn:SetPoint("LEFT", saveBtn, "RIGHT", 10, 0)
        cancelBtn:SetScript("OnClick", function() af:Hide() end)

        self.addFrame = af
    end

    -- Pre-fill if provided
    if prefillName then
        self.addFrame.nameInput:SetText(prefillName)
    end
    if prefillServer then
        self.addFrame.serverInput:SetText(prefillServer)
    end

    self.addFrame:Show()
end

----------------------------------------------------------------------
-- EDIT PLAYER UI
----------------------------------------------------------------------
function addon:ShowEditPlayerUI(key, data)
    self:ShowAddPlayerUI()
    if self.addFrame and data then
        self.addFrame.TitleText:SetText("|cffffff00编辑避雷记录|r - " .. data.name)
        self.addFrame.nameInput:SetText(data.name or "")
        self.addFrame.serverInput:SetText(data.server or "")
        self.addFrame.reasonInput:SetText(data.reason or "")
        self.addFrame.notesInput:SetText(data.notes or "")
        self.addFrame.dungeonInput:SetText(data.dungeon or "")
        self.addFrame.selectedClass = data.class or "未知"
        self.addFrame.classDropdown:SetSelectedText(addon:GetColoredClass(data.class or "未知"))
    end
end

----------------------------------------------------------------------
-- SETTINGS UI
----------------------------------------------------------------------
function addon:ShowSettingsUI()
    if self.settingsFrame and self.settingsFrame:IsShown() then
        self.settingsFrame:Hide()
        return
    end

    if not self.settingsFrame then
        local sf = CreateFrame("Frame", "MPBlacklistSettingsFrame", UIParent, "BasicFrameTemplateWithInset")
        sf:SetSize(420, 460)
        sf:SetPoint("CENTER", -200, 0)
        sf:SetMovable(true)
        sf:EnableMouse(true)
        sf:RegisterForDrag("LeftButton")
        sf:SetScript("OnDragStart", sf.StartMoving)
        sf:SetScript("OnDragStop", sf.StopMovingOrSizing)
        sf:SetFrameStrata("DIALOG")
        sf:SetClampedToScreen(true)
        tinsert(UISpecialFrames, "MPBlacklistSettingsFrame")

        sf.TitleText:SetText("|cff00ccff设置|r")

        local y = -40
        local settings = self.db.settings

        local function CreateCheckbox(parent, x, yy, text, key)
            local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
            cb:SetPoint("TOPLEFT", parent, "TOPLEFT", x, yy)
            -- Handle both .text (old) and .Text (new) checkbox label
            local textObj = cb.text or cb.Text
            if not textObj then
                textObj = cb:CreateFontString(nil, "ARTWORK", "GameFontNormal")
                textObj:SetPoint("LEFT", cb, "RIGHT", 2, 0)
                cb.text = textObj
            end
            textObj:SetText(text)
            textObj:SetFontObject(GameFontNormal)
            cb:SetChecked(settings[key])
            cb:SetScript("OnClick", function(self)
                settings[key] = self:GetChecked()
                if key == "showMinimapButton" then
                    addon:ToggleMinimapButton(settings[key])
                end
            end)
            return cb
        end

        CreateCheckbox(sf, 16, y, "在组队界面高亮避雷玩家", "enableHighlight")
        y = y - 34
        CreateCheckbox(sf, 16, y, "鼠标悬停显示避雷信息", "enableTooltip")
        y = y - 34
        CreateCheckbox(sf, 16, y, "显示小地图按钮", "showMinimapButton")
        y = y - 34
        CreateCheckbox(sf, 16, y, "发现避雷玩家时播放提示音", "alertSound")
        y = y - 34
        CreateCheckbox(sf, 16, y, "自动检查队伍成员", "autoCheckParty")
        y = y - 34
        CreateCheckbox(sf, 16, y, "小队通告 (向队友公告避雷信息)", "partyAnnounce")

        -- Party Announce description
        y = y - 20
        local announceDesc = sf:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        announceDesc:SetPoint("TOPLEFT", sf, "TOPLEFT", 52, y)
        announceDesc:SetWidth(350)
        announceDesc:SetJustifyH("LEFT")
        announceDesc:SetSpacing(2)
        announceDesc:SetText("开启后，所有避雷玩家进组时会自动在小队/团队聊天中公告警告信息")
        local descHeight = announceDesc:GetStringHeight() or 14

        -- Custom announce format
        y = y - descHeight - 10
        local formatLabel = sf:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        formatLabel:SetPoint("TOPLEFT", sf, "TOPLEFT", 20, y)
        formatLabel:SetText("|cffffff00自定义通告消息格式:|r")

        y = y - 18
        local formatDesc = sf:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        formatDesc:SetPoint("TOPLEFT", sf, "TOPLEFT", 20, y)
        formatDesc:SetWidth(380)
        formatDesc:SetJustifyH("LEFT")
        formatDesc:SetText("可用变量: {name} {class} {reason} {notes} {server}")

        y = y - 18
        local formatBg = CreateFrame("Frame", nil, sf, BackdropTemplateMixin and "BackdropTemplate" or nil)
        formatBg:SetSize(380, 50)
        formatBg:SetPoint("TOPLEFT", sf, "TOPLEFT", 18, y)
        if formatBg.SetBackdrop then
            formatBg:SetBackdrop({
                bgFile = "Interface\\ChatFrame\\ChatFrameBackground",
                edgeFile = "Interface\\ChatFrame\\ChatFrameBackground",
                tile = true, tileSize = 5, edgeSize = 1,
                insets = { left = 2, right = 2, top = 2, bottom = 2 },
            })
            formatBg:SetBackdropColor(0.05, 0.05, 0.05, 0.8)
            formatBg:SetBackdropBorderColor(0.4, 0.4, 0.4, 0.8)
        end

        local formatScroll = CreateFrame("ScrollFrame", nil, formatBg, "UIPanelScrollFrameTemplate")
        formatScroll:SetPoint("TOPLEFT", formatBg, "TOPLEFT", 6, -4)
        formatScroll:SetPoint("BOTTOMRIGHT", formatBg, "BOTTOMRIGHT", -22, 4)

        local formatInput = CreateFrame("EditBox", nil, formatScroll)
        formatInput:SetSize(348, 42)
        formatInput:SetFontObject(ChatFontNormal or GameFontHighlightSmall)
        formatInput:SetMultiLine(true)
        formatInput:SetAutoFocus(false)
        formatInput:SetMaxLetters(255)
        formatScroll:SetScrollChild(formatInput)

        formatInput:SetText(settings.announceFormat or "【飞鸟黑名单】避雷警告: {name} ({class}) - {reason} / 备注: {notes}")
        formatInput:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
        formatInput:SetScript("OnTextChanged", function(self)
            local text = self:GetText()
            if text and text ~= "" then
                settings.announceFormat = text
            end
        end)

        -- Reset format button
        y = y - 58
        local resetFmtBtn = CreateFrame("Button", nil, sf, "UIPanelButtonTemplate")
        resetFmtBtn:SetSize(100, 22)
        resetFmtBtn:SetPoint("TOPLEFT", sf, "TOPLEFT", 20, y)
        resetFmtBtn:SetText("重置为默认")
        resetFmtBtn:SetScript("OnClick", function()
            local defaultFmt = "【飞鸟黑名单】避雷警告: {name} ({class}) - {reason} / 备注: {notes}"
            formatInput:SetText(defaultFmt)
            settings.announceFormat = defaultFmt
        end)

        -- Stats
        y = y - 30
        local statsLabel = sf:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        statsLabel:SetPoint("TOPLEFT", sf, "TOPLEFT", 20, y)
        local total = addon:GetBlacklistCount()
        statsLabel:SetText(string.format(
            "|cff888888统计: 共 %d 人 | 累计添加 %d | 累计移除 %d|r",
            total,
            addon.db.stats.totalAdded or 0,
            addon.db.stats.totalRemoved or 0
        ))

        self.settingsFrame = sf
    end

    self.settingsFrame:Show()
end
