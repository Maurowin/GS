----------------------------------------------------------------------
-- MPBlacklist - GroupFinder.lua
-- Hook into Group Finder (LFG) to highlight blacklisted players
-- and add tooltip warnings. Compatible with WoW 12.0.1 (Midnight)
----------------------------------------------------------------------

local addonName, addon = ...

-- Safe pcall wrapper to avoid error flood
local function safecall(func, ...)
    local ok, err = pcall(func, ...)
    if not ok then
        -- Silently suppress to avoid error flood
    end
end

----------------------------------------------------------------------
-- Hook Group Finder Search Results
----------------------------------------------------------------------
function addon:HookGroupFinder()
    -- 1. Tooltip: Use modern TooltipDataProcessor (10.0.2+)
    self:HookTooltips()

    -- 2. Hook LFG List frame updates via ScrollBox (modern API)
    self:HookLFGScrollBox()

    -- 3. Hook legacy global functions if they still exist
    self:HookLegacyLFGFunctions()

    -- 4. Listen for group roster changes
    local partyFrame = CreateFrame("Frame")
    partyFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
    partyFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    partyFrame:RegisterEvent("LFG_LIST_SEARCH_RESULTS_RECEIVED")
    pcall(partyFrame.RegisterEvent, partyFrame, "GROUP_JOINED")
    pcall(partyFrame.RegisterEvent, partyFrame, "GROUP_LEFT")

    -- Retry mechanism: check again after longer delays for PLAYER_ENTERING_WORLD
    local pendingCheck = nil
    local retryCount = 0

    local function DoCheck()
        pendingCheck = nil
        addon:CheckPartyMembers()
    end

    local function ScheduleCheck(delay, isRetry)
        if pendingCheck then pendingCheck:Cancel() end
        if not isRetry then retryCount = 0 end
        pendingCheck = C_Timer.NewTimer(delay, function()
            DoCheck()
            -- Auto-retry: if we're in group but found 0 units with valid names, retry
            -- (handles PLAYER_ENTERING_WORLD where names aren't loaded yet)
            retryCount = retryCount + 1
            if retryCount <= 3 and IsInGroup() then
                local hasValidUnit = false
                for i = 1, 4 do
                    if UnitExists("party" .. i) and UnitName("party" .. i) ~= UNKNOWNOBJECT then
                        hasValidUnit = true
                        break
                    end
                end
                if not hasValidUnit then
                    pendingCheck = C_Timer.NewTimer(retryCount, DoCheck)
                end
            end
        end)
    end

    partyFrame:SetScript("OnEvent", function(self, event, ...)
        if event == "GROUP_ROSTER_UPDATE" or event == "GROUP_JOINED" or event == "PLAYER_ENTERING_WORLD" then
            ScheduleCheck(0.5, false)
        elseif event == "GROUP_LEFT" then
            if addon.announcedPlayers then wipe(addon.announcedPlayers) end
            if addon.previousMembers then wipe(addon.previousMembers) end
        elseif event == "LFG_LIST_SEARCH_RESULTS_RECEIVED" then
            C_Timer.After(0.2, function()
                safecall(addon.RefreshGroupFinderHighlights, addon)
            end)
        end
    end)
end

----------------------------------------------------------------------
-- Modern Tooltip Hook (TooltipDataProcessor, 10.0.2+)
----------------------------------------------------------------------
function addon:HookTooltips()
    -- Method 1: TooltipDataProcessor (preferred for 10.0+)
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall then
        if Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
            TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip, data)
                safecall(addon.OnTooltipUnit, addon, tooltip, data)
            end)
        end
    else
        -- Fallback: try legacy HookScript (pre-10.0)
        if GameTooltip and GameTooltip.HookScript then
            local ok = pcall(function()
                GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
                    safecall(addon.OnTooltipUnitLegacy, addon, tooltip)
                end)
            end)
        end
    end
end

-- Modern tooltip callback (10.0.2+)
function addon:OnTooltipUnit(tooltip, data)
    if not self.db or not self.db.settings.enableTooltip then return end
    if tooltip ~= GameTooltip then return end

    local name, unit
    -- Try modern data first
    if data and data.guid then
        name = data.guid and select(6, GetPlayerInfoByGUID(data.guid))
        unit = data.guid and UnitTokenFromGUID and UnitTokenFromGUID(data.guid)
    end

    -- Fallback to GetUnit
    if not name then
        local ok, n, u = pcall(tooltip.GetUnit, tooltip)
        if ok then
            name = n
            unit = u
        end
    end

    if not name then return end

    -- Try full name with server
    local fullName = name
    if unit and UnitExists(unit) then
        fullName = GetUnitName(unit, true) or name
    end

    local result = self:CheckPlayer(name)
    if not result and fullName and fullName ~= name then
        result = self:CheckPlayer(fullName)
    end

    if result then
        tooltip:AddLine(" ")
        tooltip:AddLine("|cffff4444━━━ 飞鸟黑名单警告 ━━━|r", 1, 0, 0)
        tooltip:AddDoubleLine("职业:", result.class or "未知", 0.7, 0.7, 0.7, 1, 1, 1)
        tooltip:AddDoubleLine("区服:", result.server ~= "" and result.server or "未知", 0.7, 0.7, 0.7, 1, 1, 1)
        tooltip:AddLine("|cffffff00原因:|r " .. (result.reason or "无"), 1, 0.8, 0, true)
        if result.records and #result.records > 1 then
            tooltip:AddLine("|cffff8800记录次数: " .. #result.records .. " 次|r")
        end
        tooltip:AddLine("|cff888888日期: " .. (result.date or "未知") .. "|r", 0.5, 0.5, 0.5)
        tooltip:AddLine("|cffff4444━━━━━━━━━━━━━━|r")
        tooltip:Show()

        -- Play alert sound
        if self.db.settings.alertSound then
            local soundID = SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959
            PlaySound(soundID)
        end
    end
end

-- Legacy tooltip callback (pre-10.0 fallback)
function addon:OnTooltipUnitLegacy(tooltip)
    if not self.db or not self.db.settings.enableTooltip then return end

    local name, unit
    local ok, n, u = pcall(tooltip.GetUnit, tooltip)
    if ok then
        name = n
        unit = u
    end
    if not name or not unit then return end

    local fullName = GetUnitName(unit, true) or name

    local result = self:CheckPlayer(name)
    if not result and fullName then
        result = self:CheckPlayer(fullName)
    end

    if result then
        tooltip:AddLine(" ")
        tooltip:AddLine("|cffff4444━━━ 飞鸟黑名单警告 ━━━|r", 1, 0, 0)
        tooltip:AddDoubleLine("职业:", result.class or "未知", 0.7, 0.7, 0.7, 1, 1, 1)
        tooltip:AddDoubleLine("区服:", result.server ~= "" and result.server or "未知", 0.7, 0.7, 0.7, 1, 1, 1)
        tooltip:AddLine("|cffffff00原因:|r " .. (result.reason or "无"), 1, 0.8, 0, true)
        tooltip:AddLine("|cff888888日期: " .. (result.date or "未知") .. "|r", 0.5, 0.5, 0.5)
        tooltip:AddLine("|cffff4444━━━━━━━━━━━━━━|r")
        tooltip:Show()
    end
end

----------------------------------------------------------------------
-- Hook modern LFG ScrollBox (10.0+)
----------------------------------------------------------------------
function addon:HookLFGScrollBox()
    -- Wait for LFGListFrame to be available
    local function TryHookScrollBox()
        if not LFGListFrame then return false end

        -- Hook the SearchPanel ScrollBox
        local searchPanel = LFGListFrame.SearchPanel
        if searchPanel and searchPanel.ScrollBox then
            local scrollBox = searchPanel.ScrollBox
            -- Hook the update function that fires when frames are acquired/updated
            if scrollBox.RegisterCallback then
                scrollBox:RegisterCallback("OnAcquiredFrame", function(_, frame, elementData)
                    safecall(addon.ProcessSearchEntry, addon, frame, elementData)
                end, addon)
            end
            -- Also hook update directly
            if scrollBox.Update then
                hooksecurefunc(scrollBox, "Update", function()
                    safecall(addon.RefreshGroupFinderHighlights, addon)
                end)
            end
        end

        -- Hook the ApplicationViewer if it exists
        local appViewer = LFGListFrame.ApplicationViewer
        if appViewer then
            if appViewer.ScrollBox then
                if appViewer.ScrollBox.RegisterCallback then
                    appViewer.ScrollBox:RegisterCallback("OnAcquiredFrame", function(_, frame, elementData)
                        safecall(addon.ProcessApplicantEntry, addon, frame, elementData)
                    end, addon)
                end
            end
            -- Hook UpdateResults if it exists
            if appViewer.UpdateResults then
                hooksecurefunc(appViewer, "UpdateResults", function()
                    safecall(addon.RefreshApplicantHighlights, addon)
                end)
            end
        end

        return true
    end

    -- Try immediately, and also after a delay in case frames aren't loaded yet
    if not TryHookScrollBox() then
        C_Timer.After(2, function()
            safecall(TryHookScrollBox)
        end)
        C_Timer.After(5, function()
            safecall(TryHookScrollBox)
        end)
    end
end

----------------------------------------------------------------------
-- Hook legacy LFG functions (if they still exist)
----------------------------------------------------------------------
function addon:HookLegacyLFGFunctions()
    if type(LFGListSearchEntry_Update) == "function" then
        hooksecurefunc("LFGListSearchEntry_Update", function(entry)
            safecall(addon.HighlightSearchEntry, addon, entry)
        end)
    end

    if type(LFGListApplicationViewer_UpdateResults) == "function" then
        hooksecurefunc("LFGListApplicationViewer_UpdateResults", function(viewer)
            safecall(addon.HighlightApplicants, addon, viewer)
        end)
    end

    if type(LFGListApplicationViewer_UpdateApplicantMember) == "function" then
        hooksecurefunc("LFGListApplicationViewer_UpdateApplicantMember", function(member)
            safecall(addon.HighlightApplicantMember, addon, member)
        end)
    end
end

----------------------------------------------------------------------
-- Process a search entry (modern ScrollBox callback)
----------------------------------------------------------------------
function addon:ProcessSearchEntry(frame, elementData)
    if not self.db or not self.db.settings.enableHighlight then return end
    if not frame then return end

    -- Get resultID from element data or frame
    local resultID = nil
    if elementData then
        if type(elementData) == "table" then
            resultID = elementData.resultID or elementData[1]
        elseif type(elementData) == "number" then
            resultID = elementData
        end
    end
    if not resultID and frame.resultID then
        resultID = frame.resultID
    end
    if not resultID then return end

    local searchResultInfo = C_LFGList and C_LFGList.GetSearchResultInfo and C_LFGList.GetSearchResultInfo(resultID)
    if not searchResultInfo then return end

    local leaderName = searchResultInfo.leaderName
    if not leaderName then return end

    local result = self:CheckPlayer(leaderName)
    self:ApplyHighlight(frame, result, leaderName)
end

----------------------------------------------------------------------
-- Process applicant entry
----------------------------------------------------------------------
function addon:ProcessApplicantEntry(frame, elementData)
    if not self.db or not self.db.settings.enableHighlight then return end
    if not frame then return end

    -- Try to get member info from the frame
    if frame.Members then
        for _, member in pairs(frame.Members) do
            safecall(self.HighlightApplicantMember, self, member)
        end
    elseif frame.Name then
        safecall(self.HighlightApplicantMember, self, frame)
    end
end

----------------------------------------------------------------------
-- Apply/Remove highlight on a frame
----------------------------------------------------------------------
function addon:ApplyHighlight(frame, result, name)
    if result then
        -- Add red overlay
        if not frame.mpblHighlight then
            local hl = frame:CreateTexture(nil, "OVERLAY", nil, -1)
            hl:SetAllPoints()
            hl:SetColorTexture(1, 0, 0, 0.25)
            frame.mpblHighlight = hl
        end
        frame.mpblHighlight:Show()

        -- Add warning icon
        if not frame.mpblWarning then
            local icon = frame:CreateTexture(nil, "OVERLAY")
            icon:SetSize(20, 20)
            icon:SetPoint("RIGHT", frame, "RIGHT", -4, 0)
            icon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
            frame.mpblWarning = icon
        end
        frame.mpblWarning:Show()

        -- Add tooltip on hover
        if not frame.mpblTooltipHooked then
            frame:HookScript("OnEnter", function(self)
                if not addon.db or not addon.db.settings.enableTooltip then return end
                -- Re-check in case data changed
                local currentResult = addon:CheckPlayer(name)
                if currentResult and GameTooltip:IsShown() then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("|cffff4444⚠ 飞鸟黑名单警告 ⚠|r", 1, 0, 0)
                    GameTooltip:AddLine("原因: " .. (currentResult.reason or "未知"), 1, 0.8, 0, true)
                    GameTooltip:AddLine("日期: " .. (currentResult.date or "未知"), 0.5, 0.5, 0.5)
                    GameTooltip:Show()
                end
            end)
            frame.mpblTooltipHooked = true
        end
    else
        if frame.mpblHighlight then frame.mpblHighlight:Hide() end
        if frame.mpblWarning then frame.mpblWarning:Hide() end
    end
end

----------------------------------------------------------------------
-- Highlight search entries (legacy style)
----------------------------------------------------------------------
function addon:HighlightSearchEntry(entry)
    if not self.db or not self.db.settings.enableHighlight then return end
    if not entry then return end

    local resultID = entry.resultID
    if not resultID then return end

    local searchResultInfo = C_LFGList and C_LFGList.GetSearchResultInfo and C_LFGList.GetSearchResultInfo(resultID)
    if not searchResultInfo then return end

    local leaderName = searchResultInfo.leaderName
    if not leaderName then return end

    local result = self:CheckPlayer(leaderName)
    self:ApplyHighlight(entry, result, leaderName)
end

----------------------------------------------------------------------
-- Highlight applicants when viewing as leader
----------------------------------------------------------------------
function addon:HighlightApplicants(viewer)
    if not self.db or not self.db.settings.enableHighlight then return end
    if not viewer then return end

    local scrollBox = viewer.ScrollBox or viewer.scrollFrame
    if not scrollBox then return end

    -- Modern ScrollBox: use GetFrames or iterate children
    local frames
    if scrollBox.GetFrames then
        frames = { scrollBox:GetFrames() }
    else
        frames = { scrollBox:GetChildren() }
    end

    for _, child in ipairs(frames) do
        if child.Members then
            for _, member in pairs(child.Members) do
                safecall(self.HighlightApplicantMember, self, member)
            end
        end
    end
end

function addon:HighlightApplicantMember(member)
    if not member then return end
    if not self.db or not self.db.settings.enableHighlight then return end

    -- Try to get name from Name fontstring
    local nameText
    if member.Name and member.Name.GetText then
        nameText = member.Name:GetText()
    elseif member.name and member.name.GetText then
        nameText = member.name:GetText()
    end
    if not nameText then return end

    -- Strip color codes
    nameText = nameText:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")

    local result = self:CheckPlayer(nameText)
    if result then
        if not member.mpblHighlight then
            local hl = member:CreateTexture(nil, "BACKGROUND")
            hl:SetAllPoints()
            hl:SetColorTexture(1, 0, 0, 0.3)
            member.mpblHighlight = hl
        end
        member.mpblHighlight:Show()

        -- Change name color
        local nameObj = member.Name or member.name
        if nameObj and nameObj.SetText then
            nameObj:SetText("|cffff0000⚠ " .. nameText .. "|r")
        end
    else
        if member.mpblHighlight then
            member.mpblHighlight:Hide()
        end
    end
end

----------------------------------------------------------------------
-- Refresh all group finder highlights
----------------------------------------------------------------------
function addon:RefreshGroupFinderHighlights()
    if not LFGListFrame then return end

    local searchPanel = LFGListFrame.SearchPanel
    if not searchPanel then return end

    local scrollBox = searchPanel.ScrollBox
    if not scrollBox then return end

    -- Modern ScrollBox: use GetFrames or GetChildren
    local frames
    if scrollBox.GetFrames then
        frames = { scrollBox:GetFrames() }
    else
        frames = { scrollBox:GetChildren() }
    end

    for _, child in ipairs(frames) do
        -- Try to get resultID from the frame or its data
        local resultID = child.resultID
        if not resultID and child.GetElementData then
            local data = child:GetElementData()
            if data then
                if type(data) == "table" then
                    resultID = data.resultID or data[1]
                elseif type(data) == "number" then
                    resultID = data
                end
            end
        end

        if resultID then
            local searchResultInfo = C_LFGList.GetSearchResultInfo(resultID)
            if searchResultInfo and searchResultInfo.leaderName then
                local result = self:CheckPlayer(searchResultInfo.leaderName)
                self:ApplyHighlight(child, result, searchResultInfo.leaderName)
            end
        end
    end
end

----------------------------------------------------------------------
-- Refresh applicant highlights
----------------------------------------------------------------------
function addon:RefreshApplicantHighlights()
    if not LFGListFrame or not LFGListFrame.ApplicationViewer then return end
    safecall(self.HighlightApplicants, self, LFGListFrame.ApplicationViewer)
end

----------------------------------------------------------------------
-- Check current party/raid members
----------------------------------------------------------------------

-- Session tracking for announce logic
addon.announcedPlayers = addon.announcedPlayers or {}
addon.previousMembers = addon.previousMembers or {}

-- Helper: get full name for a unit (name-realm)
local function GetFullUnitName(unit)
    if not UnitExists(unit) then return nil end
    local name, realm = UnitName(unit)
    if not name or name == UNKNOWNOBJECT or name == UNKNOWN then return nil end
    if realm and realm ~= "" then
        return name .. "-" .. realm
    end
    return name
end

-- Helper: determine the correct chat channel for current group type
-- Sanitize message for SendChatMessage: strip all WoW escape codes and pipe characters
-- WoW's SendChatMessage() does NOT allow any | escape codes (color, texture, hyperlink, etc.)
local function SanitizeChatMessage(msg)
    if not msg then return "" end
    -- Remove color codes: |cffXXXXXX ... |r
    msg = msg:gsub("|c%x%x%x%x%x%x%x%x", "")
    msg = msg:gsub("|r", "")
    -- Remove texture escapes: |T...|t
    msg = msg:gsub("|T.-|t", "")
    -- Remove hyperlinks: |H...|h...|h  (keep the visible text)
    msg = msg:gsub("|H.-|h(.-)|h", "%1")
    -- Remove atlas: |A...|a
    msg = msg:gsub("|A.-|a", "")
    -- Remove any remaining pipe characters (they cause "Invalid escape code" errors)
    msg = msg:gsub("|", "")
    -- Clean up extra whitespace
    msg = msg:gsub("%s+", " ")
    msg = strtrim(msg)
    return msg
end

local function GetGroupChatChannel()
    -- Instance group (LFG/LFR/scenarios) uses INSTANCE_CHAT
    if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
        return "INSTANCE_CHAT"
    end
    -- Regular raid
    if IsInRaid() then
        return "RAID"
    end
    -- Regular party
    return "PARTY"
end

function addon:CheckPartyMembers()
    if not self.db then return end
    if self.db.settings.autoCheckParty == false then
        return
    end

    if not IsInGroup() then
        self.announcedPlayers = self.announcedPlayers or {}
        self.previousMembers = self.previousMembers or {}
        wipe(self.announcedPlayers)
        wipe(self.previousMembers)
        return
    end

    -- Detect group type
    local inRaid = IsInRaid()
    local inInstance = IsInGroup(LE_PARTY_CATEGORY_INSTANCE)

    -- Build unit list
    local units = {}
    if inRaid then
        for i = 1, GetNumGroupMembers() do
            table.insert(units, "raid" .. i)
        end
    else
        for i = 1, 4 do
            if UnitExists("party" .. i) then
                table.insert(units, "party" .. i)
            end
        end
    end

    -- Build current member set
    local currentMembers = {}
    for _, unit in ipairs(units) do
        local name = GetFullUnitName(unit)
        if name then
            currentMembers[name:lower()] = true
        end
    end

    local selfName = GetFullUnitName("player")
    if selfName then currentMembers[selfName:lower()] = true end

    -- Detect new joiners
    self.announcedPlayers = self.announcedPlayers or {}
    self.previousMembers = self.previousMembers or {}
    local hasNewJoiner = false
    for nameKey in pairs(currentMembers) do
        if not self.previousMembers[nameKey] then
            hasNewJoiner = true
            break
        end
    end

    if hasNewJoiner then
        wipe(self.announcedPlayers)
    end

    wipe(self.previousMembers)
    for nameKey in pairs(currentMembers) do
        self.previousMembers[nameKey] = true
    end

    -- Check each unit against blacklist
    local blacklistCount = 0
    if self.db.blacklist and type(self.db.blacklist) == "table" then
        for _ in pairs(self.db.blacklist) do blacklistCount = blacklistCount + 1 end
    end

    local found = {}
    for _, unit in ipairs(units) do
        local fullName = GetFullUnitName(unit)
        if fullName then
            if not (inRaid and UnitIsUnit(unit, "player")) then
                local result = self:CheckPlayer(fullName)
                if not result then
                    local shortName = fullName:match("^([^%-]+)")
                    if shortName and shortName ~= fullName then
                        result = self:CheckPlayer(shortName)
                    end
                end
                if result then
                    table.insert(found, { name = fullName, data = result })
                end
            end
        end
    end

    if #found > 0 then
        self:Print(self.colors.warning .. "⚠⚠⚠ 队伍中发现 " .. #found .. " 名避雷玩家！⚠⚠⚠")
        for _, f in ipairs(found) do
            self:Print(self.colors.warning .. "  ⚠ " .. f.name .. " |r- " .. (f.data.reason or "无原因"))
        end

        if self.db.settings.alertSound then
            local soundID = SOUNDKIT and SOUNDKIT.RAID_WARNING or 8959
            PlaySound(soundID)
            C_Timer.After(1, function() PlaySound(soundID) end)
        end

        if RaidNotice_AddMessage then
            RaidNotice_AddMessage(RaidWarningFrame, "⚠ 避雷警告: 队伍中有黑名单玩家！", ChatTypeInfo["RAID_WARNING"])
        end

        -- Party Announce
        self:AnnounceBlacklistedToParty(found)
    else
        -- No blacklisted players found
    end
end

----------------------------------------------------------------------
-- Party Announce: send blacklist info to group chat
-- Supports: PARTY, RAID, INSTANCE_CHAT (for LFG/LFR groups)
----------------------------------------------------------------------
function addon:AnnounceBlacklistedToParty(foundList)
    if not self.db then return end

    -- Check partyAnnounce toggle
    if not self.db.settings.partyAnnounce then
        return
    end

    if not IsInGroup() then
        return
    end

    -- Use correct channel for group type (INSTANCE_CHAT for LFG/LFR)
    local channel = GetGroupChatChannel()

    -- Use safe format template (no pipe characters)
    local formatTemplate = self.db.settings.announceFormat or "【飞鸟黑名单】避雷警告: {name} ({class}) - {reason} / 备注: {notes}"
    -- Sanitize the template itself in case it contains pipe characters from old config
    formatTemplate = SanitizeChatMessage(formatTemplate)

    self.announcedPlayers = self.announcedPlayers or {}

    for _, f in ipairs(foundList) do
        local data = f.data or {}
        local displayName = f.name:match("^([^%-]+)") or f.name
        local nameKey = displayName:lower()

        if not self.announcedPlayers[nameKey] then
            local msg = formatTemplate
            msg = msg:gsub("{name}", displayName or "")
            msg = msg:gsub("{class}", (data.class and data.class ~= "未知") and data.class or "")
            msg = msg:gsub("{reason}", (data.reason and data.reason ~= "") and data.reason or "无")
            msg = msg:gsub("{notes}", (data.notes and data.notes ~= "") and data.notes or "无")
            msg = msg:gsub("{server}", (data.server and data.server ~= "") and data.server or "")
            msg = msg:gsub("{dungeon}", (data.dungeon and data.dungeon ~= "") and data.dungeon or "")
            msg = msg:gsub("{date}", data.date or "")

            -- Clean up empty parentheses and trailing "备注: 无" etc.
            msg = msg:gsub("%(%s*%)", ""):gsub("/%s*备注:%s*无", ""):gsub("%s+", " ")
            -- CRITICAL: sanitize all pipe/escape codes before sending to chat
            msg = SanitizeChatMessage(msg)

            if #msg > 240 then
                msg = msg:sub(1, 237) .. "..."
            end

            -- Send the message
            local ok, err = pcall(SendChatMessage, msg, channel)
            if ok then
                self.announcedPlayers[nameKey] = true
                self:Print(self.colors.info .. "小队通告: 已向" .. channel .. "发送 " .. displayName .. " 的避雷警告")
            else
                self:Print("|cffff0000小队通告发送失败: " .. tostring(err) .. "|r")
            end
        end
    end
end
