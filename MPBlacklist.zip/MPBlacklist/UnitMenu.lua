----------------------------------------------------------------------
-- MPBlacklist - UnitMenu.lua
-- Right-click menu integration for unit frames (party/raid/target)
-- AND chat frame player names
-- Adds "加入飞鸟的黑名单" to right-click context menus
-- Compatible with WoW 12.0.1 (Midnight)
----------------------------------------------------------------------

local addonName, addon = ...

local function safecall(func, ...)
    local ok, err = pcall(func, ...)
    if not ok then end
end

-- Pending blacklist info (set before showing popup)
addon._pendingBlacklistInfo = nil

----------------------------------------------------------------------
-- Helper: safely get editbox text from a StaticPopup dialog
----------------------------------------------------------------------
local function GetPopupEditBoxText(dialog)
    if dialog.editBox and dialog.editBox.GetText then
        return dialog.editBox:GetText() or ""
    end
    local name = dialog:GetName()
    if name then
        local eb = _G[name .. "EditBox"]
        if eb and eb.GetText then
            return eb:GetText() or ""
        end
    end
    for _, child in pairs({dialog:GetChildren()}) do
        if child.GetText and child:IsObjectType("EditBox") then
            return child:GetText() or ""
        end
    end
    return ""
end

----------------------------------------------------------------------
-- Core function: actually add the player from menu
----------------------------------------------------------------------
local function DoAddPlayerFromMenu(info, reason)
    if not info or not info.name or info.name == "" then
        addon:Print(addon.colors.warning .. "拉黑失败：玩家信息无效")
        return
    end
    if not reason or strtrim(reason) == "" then
        reason = "右键菜单添加"
    end
    local success = addon:AddPlayer({
        name = info.name,
        server = info.server or "",
        class = info.class or "未知",
        reason = reason,
        notes = "通过右键菜单添加",
        date = addon:GetCurrentDate(),
    })
    if success then
        if RaidNotice_AddMessage then
            pcall(RaidNotice_AddMessage, RaidWarningFrame,
                "飞鸟黑名单: " .. info.name .. " 已拉黑！",
                ChatTypeInfo["RAID_WARNING"])
        end
    else
        addon:Print(addon.colors.warning .. "拉黑操作未成功，请重试")
    end
end

----------------------------------------------------------------------
-- Static popup for entering reason when blacklisting from menu
----------------------------------------------------------------------
StaticPopupDialogs["MPBL_MENU_BLACKLIST"] = {
    text = "|cffff8800飞鸟的黑名单|r\n\n将 |cffffffff%s|r 加入黑名单\n\n请输入原因（可留空）:",
    button1 = "加入黑名单",
    button2 = "取消",
    hasEditBox = true,
    editBoxWidth = 260,
    maxLetters = 200,
    OnShow = function(self)
        local eb = self.editBox
        if not eb then
            local name = self:GetName()
            if name then eb = _G[name .. "EditBox"] end
        end
        if eb then
            eb:SetText("")
            eb:SetFocus()
        end
    end,
    OnAccept = function(self, data)
        local reason = GetPopupEditBoxText(self)
        local info = data or addon._pendingBlacklistInfo
        if not info then
            addon:Print(addon.colors.warning .. "拉黑失败：未找到玩家数据，请重试")
            return
        end
        local capturedInfo = {
            name = info.name,
            server = info.server,
            class = info.class,
        }
        local capturedReason = reason
        addon._pendingBlacklistInfo = nil
        C_Timer.After(0, function()
            DoAddPlayerFromMenu(capturedInfo, capturedReason)
        end)
    end,
    OnCancel = function()
        addon._pendingBlacklistInfo = nil
    end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
    enterClicksFirstButton = true,
}

----------------------------------------------------------------------
-- Get player info from a unit token
----------------------------------------------------------------------
local function GetPlayerInfoFromUnit(unit)
    if not unit or not UnitExists(unit) then return nil end
    if not UnitIsPlayer(unit) then return nil end
    if UnitIsUnit(unit, "player") then return nil end

    local name = GetUnitName(unit, false) or "未知"
    local fullName = GetUnitName(unit, true) or name
    local server = ""

    if fullName:find("-") then
        local n, s = fullName:match("^(.+)-(.+)$")
        if n then
            name = n
            server = s
        end
    else
        server = GetRealmName() or ""
    end

    local classLocalized = UnitClass(unit) or "未知"

    return {
        name = name,
        server = server,
        class = classLocalized,
        fullName = fullName,
        unit = unit,
    }
end

----------------------------------------------------------------------
-- Get player info from a name string (for chat frame, no unit token)
----------------------------------------------------------------------
local function GetPlayerInfoFromName(playerName, playerServer)
    if not playerName or playerName == "" then return nil end

    local name = playerName
    local server = playerServer or ""

    -- Strip color codes if any
    name = name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    name = strtrim(name)

    -- If name contains "-", split it
    if name:find("-") then
        local n, s = name:match("^(.+)-(.+)$")
        if n then
            name = n
            server = s
        end
    end

    -- Don't allow blacklisting self
    local selfName = UnitName("player")
    if selfName and name == selfName then return nil end

    if server == "" then
        server = GetRealmName() or ""
    end

    return {
        name = name,
        server = server,
        class = "未知",
        fullName = (server ~= "") and (name .. "-" .. server) or name,
    }
end

----------------------------------------------------------------------
-- Show the blacklist popup (works for both unit and name-based)
----------------------------------------------------------------------
local function ShowBlacklistPopupForInfo(info)
    if not info then
        addon:Print(addon.colors.warning .. "无法获取目标信息！")
        return
    end

    -- Check if already in blacklist
    local existing = addon:CheckPlayer(info.name)
    if not existing and info.fullName then
        existing = addon:CheckPlayer(info.fullName)
    end

    if existing then
        addon:Print(addon.colors.info .. info.name .. " 已在黑名单中（原因: " .. (existing.reason or "无") .. "），将新增一条记录")
    end

    addon._pendingBlacklistInfo = info
    StaticPopup_Show("MPBL_MENU_BLACKLIST", info.name .. " - " .. info.server, nil, info)
end

local function ShowBlacklistPopup(unit)
    local info = GetPlayerInfoFromUnit(unit)
    ShowBlacklistPopupForInfo(info)
end

local function ShowBlacklistPopupByName(playerName, playerServer)
    local info = GetPlayerInfoFromName(playerName, playerServer)
    ShowBlacklistPopupForInfo(info)
end

----------------------------------------------------------------------
-- Hook Unit Menus (main entry point, called from Core.lua)
----------------------------------------------------------------------
function addon:HookUnitMenus()
    -- Method 1: Modern Menu system (11.0+/12.0+)
    self:HookModernMenu()

    -- Method 2: Legacy UnitPopup hook (pre-11.0 fallback)
    self:HookLegacyUnitPopup()

    -- Method 3: Hook CompactUnitFrame for visual indicators
    self:HookCompactUnitFrames()

    -- Method 4: Hook chat frame player name right-click menu
    self:HookChatPlayerMenu()
end

----------------------------------------------------------------------
-- Method 1: Modern Menu.ModifyMenu (WoW 11.0+ / 12.0+)
-- Hooks unit frames AND chat frame player name menus
----------------------------------------------------------------------
function addon:HookModernMenu()
    if not Menu or not Menu.ModifyMenu then return end

    local function AddBlacklistOption(owner, rootDescription, contextData)
        if not contextData then return end

        local unit = contextData.unit
        local playerName, playerServer

        -- Case 1: Unit-based menu (party/raid/target frames)
        if unit and UnitExists(unit) then
            if not UnitIsPlayer(unit) then return end
            if UnitIsUnit(unit, "player") then return end
            playerName = GetUnitName(unit, false) or "未知"
            local fullName = GetUnitName(unit, true) or playerName
            if fullName:find("-") then
                local n, s = fullName:match("^(.+)-(.+)$")
                if n then playerName = n; playerServer = s end
            else
                playerServer = GetRealmName() or ""
            end
        -- Case 2: Name-based menu (chat frame player names)
        elseif contextData.name then
            playerName = contextData.name
            playerServer = contextData.server or ""
            if playerName:find("-") then
                local n, s = playerName:match("^(.+)-(.+)$")
                if n then playerName = n; playerServer = s end
            end
            -- Don't allow blacklisting self
            local selfName = UnitName("player")
            if selfName and playerName == selfName then return end
        else
            return
        end

        -- Add separator before our options
        rootDescription:CreateDivider()

        local shortName = playerName or "未知"

        -- Check if already blacklisted
        local result = addon:CheckPlayer(shortName)
        if not result and playerServer and playerServer ~= "" then
            result = addon:CheckPlayer(shortName .. "-" .. playerServer)
        end

        if result then
            rootDescription:CreateButton(
                "|cffff4444⚠ 飞鸟黑名单: " .. (result.reason or "已标记") .. "|r",
                function()
                    addon:Print(addon.colors.warning .. shortName .. " 已在黑名单中")
                    addon:Print("  原因: " .. (result.reason or "无"))
                    addon:Print("  日期: " .. (result.date or "未知"))
                end
            )
        end

        -- Always show the "Add to blacklist" button
        local btnText = result
            and "|cffff8800飞鸟黑名单: 新增记录|r"
            or "|cffff8800加入飞鸟的黑名单|r"

        local capturedUnit = unit
        local capturedName = playerName
        local capturedServer = playerServer
        rootDescription:CreateButton(btnText, function()
            if capturedUnit and UnitExists(capturedUnit) then
                ShowBlacklistPopup(capturedUnit)
            else
                ShowBlacklistPopupByName(capturedName, capturedServer)
            end
        end)
    end

    -- Hook multiple menu tags for maximum compatibility
    local menuTags = {
        "MENU_UNIT_SELF_AND_OTHER",            -- Generic unit menu
        "MENU_UNIT_PARTY",                     -- Party member frames
        "MENU_UNIT_PLAYER",                    -- Player target frame
        "MENU_UNIT_RAID_PLAYER",               -- Raid member frames
        "MENU_UNIT_ENEMY_PLAYER",              -- Enemy player
        "MENU_UNIT_FRIEND",                    -- Friend list / chat player names
        "MENU_UNIT_COMMUNITIES_GUILD_MEMBER",  -- Guild member
        "MENU_UNIT_COMMUNITIES_MEMBER",        -- Community member
    }

    for _, tag in ipairs(menuTags) do
        pcall(Menu.ModifyMenu, tag, function(owner, rootDescription, contextData)
            safecall(AddBlacklistOption, owner, rootDescription, contextData)
        end)
    end
end

----------------------------------------------------------------------
-- Method 2: Legacy UnitPopup hook (pre-11.0 fallback)
----------------------------------------------------------------------
function addon:HookLegacyUnitPopup()
    if type(UnitPopup_ShowMenu) ~= "function" then return end

    hooksecurefunc("UnitPopup_ShowMenu", function(dropdownMenu, which, unit, name, userData)
        safecall(function()
            if not unit or not UnitExists(unit) then return end
            if not UnitIsPlayer(unit) then return end
            if UnitIsUnit(unit, "player") then return end

            if type(UIDropDownMenu_AddButton) == "function" then
                local sep = {}
                sep.text = ""
                sep.isTitle = true
                sep.notCheckable = true
                sep.iconOnly = true
                UIDropDownMenu_AddButton(sep)

                local shortName = GetUnitName(unit, false) or ""
                local result = addon:CheckPlayer(shortName)
                if result then
                    local warnInfo = {}
                    warnInfo.text = "|cffff4444⚠ 飞鸟黑名单: " .. (result.reason or "已标记") .. "|r"
                    warnInfo.notCheckable = true
                    warnInfo.isTitle = true
                    UIDropDownMenu_AddButton(warnInfo)
                end

                local info = {}
                info.text = result
                    and "|cffff8800飞鸟黑名单: 新增记录|r"
                    or "|cffff8800加入飞鸟的黑名单|r"
                info.notCheckable = true
                info.func = function()
                    ShowBlacklistPopup(unit)
                end
                UIDropDownMenu_AddButton(info)
            end
        end)
    end)
end

----------------------------------------------------------------------
-- Method 3: Hook CompactUnitFrame for visual indicators
----------------------------------------------------------------------
function addon:HookCompactUnitFrames()
    if type(CompactUnitFrame_UpdateAll) == "function" then
        hooksecurefunc("CompactUnitFrame_UpdateAll", function(frame)
            safecall(addon.UpdateCompactFrameBlacklist, addon, frame)
        end)
        return
    end
    if type(CompactUnitFrame_UpdateName) == "function" then
        hooksecurefunc("CompactUnitFrame_UpdateName", function(frame)
            safecall(addon.UpdateCompactFrameBlacklist, addon, frame)
        end)
    end
end

----------------------------------------------------------------------
-- Method 4: Hook chat frame player name right-click (fallback)
-- Uses SetItemRef hook for when the modern Menu system doesn't
-- cover chat hyperlinks (e.g., legacy dropdown menus)
----------------------------------------------------------------------
function addon:HookChatPlayerMenu()
    -- Hook SetItemRef: fires when clicking any hyperlink in chat
    -- We use this to inject our option into legacy dropdown menus
    if type(SetItemRef) == "function" then
        hooksecurefunc("SetItemRef", function(link, text, button, chatFrame)
            safecall(function()
                if not link then return end
                -- Only care about player links
                local linkType, playerName = link:match("^(player):(.+)")
                if not linkType then return end
                if not playerName or playerName == "" then return end

                -- Strip realm tag from player link if present
                local name, server = playerName, ""
                if name:find(":") then
                    name = name:match("^([^:]+)")
                end
                if name:find("-") then
                    local n, s = name:match("^(.+)-(.+)$")
                    if n then name = n; server = s end
                end

                -- For legacy dropdown: try to add button to existing dropdown
                if type(UIDropDownMenu_AddButton) == "function" then
                    -- Check if DropDownList1 is shown (legacy dropdown)
                    local dd = _G["DropDownList1"]
                    if dd and dd:IsShown() then
                        local sep = {}
                        sep.text = ""
                        sep.isTitle = true
                        sep.notCheckable = true
                        sep.iconOnly = true
                        UIDropDownMenu_AddButton(sep)

                        local result = addon:CheckPlayer(name)
                        if result then
                            local warnInfo = {}
                            warnInfo.text = "|cffff4444⚠ 飞鸟黑名单: " .. (result.reason or "已标记") .. "|r"
                            warnInfo.notCheckable = true
                            warnInfo.isTitle = true
                            UIDropDownMenu_AddButton(warnInfo)
                        end

                        local info = {}
                        info.text = result
                            and "|cffff8800飞鸟黑名单: 新增记录|r"
                            or "|cffff8800加入飞鸟的黑名单|r"
                        info.notCheckable = true
                        info.func = function()
                            ShowBlacklistPopupByName(name, server)
                        end
                        UIDropDownMenu_AddButton(info)
                    end
                end
            end)
        end)
    end
end

----------------------------------------------------------------------
-- Update a single CompactUnitFrame with blacklist indicators
----------------------------------------------------------------------
function addon:UpdateCompactFrameBlacklist(frame)
    if not frame or not frame.unit then return end
    if not self.db or not self.db.settings.enableHighlight then return end
    if not UnitExists(frame.unit) then return end
    if not UnitIsPlayer(frame.unit) then return end
    if UnitIsUnit(frame.unit, "player") then return end

    local name = GetUnitName(frame.unit, false)
    if not name then return end

    local result = self:CheckPlayer(name)

    if result then
        if not frame.mpblBorder then
            local border = CreateFrame("Frame", nil, frame, BackdropTemplateMixin and "BackdropTemplate" or nil)
            border:SetAllPoints()
            border:SetFrameLevel(frame:GetFrameLevel() + 5)
            if border.SetBackdrop then
                border:SetBackdrop({
                    edgeFile = "Interface\\ChatFrame\\ChatFrameBackground",
                    edgeSize = 2,
                })
                border:SetBackdropBorderColor(1, 0, 0, 0.8)
            end
            frame.mpblBorder = border
        end
        frame.mpblBorder:Show()

        if not frame.mpblIcon then
            local icon = frame.mpblBorder:CreateTexture(nil, "OVERLAY")
            icon:SetSize(14, 14)
            icon:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -1, -1)
            icon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
            frame.mpblIcon = icon
        end
        frame.mpblIcon:Show()

        if not frame.mpblTooltipHooked then
            frame:HookScript("OnEnter", function(self)
                if not addon.db or not addon.db.settings.enableTooltip then return end
                local unitName = GetUnitName(self.unit, false)
                if not unitName then return end
                local r = addon:CheckPlayer(unitName)
                if r and GameTooltip:IsShown() then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine("|cffff4444━━━ 飞鸟黑名单警告 ━━━|r", 1, 0, 0)
                    GameTooltip:AddLine("|cffffff00原因:|r " .. (r.reason or "无"), 1, 0.8, 0, true)
                    if r.records and #r.records > 1 then
                        GameTooltip:AddLine("|cffff8800记录次数: " .. #r.records .. " 次|r")
                    end
                    GameTooltip:AddLine("|cff888888日期: " .. (r.date or "未知") .. "|r", 0.5, 0.5, 0.5)
                    GameTooltip:Show()
                end
            end)
            frame.mpblTooltipHooked = true
        end
    else
        if frame.mpblBorder then frame.mpblBorder:Hide() end
        if frame.mpblIcon then frame.mpblIcon:Hide() end
    end
end
