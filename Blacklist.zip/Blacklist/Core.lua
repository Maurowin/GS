local ADDON_NAME, BL = ...

BL.callbacks = {}

--------------------------------------------------------------
-- Settings defaults
--------------------------------------------------------------
local SETTINGS_DEFAULTS = {
    chat = true,
    tooltip = true,
    nameplate = true,
    gutter = true,
    targetframe = false,
    focusframe = false,
    raidframe = false,
    targetframepos = {x = 4, y = 0},
    focusframepos = {x = 4, y = 0},
    linkframepos = true,
    editorlevel = false,
    editorrace = false,
    editorguild = false,
    editoradded = false,
    editorlastseen = true,
    tooltipnote = true,
    tooltipadded = true,
    tooltiplastseen = true,
}

function BL:GetSetting(key)
    if not BlacklistSettings then return SETTINGS_DEFAULTS[key] end
    if BlacklistSettings[key] == nil then return SETTINGS_DEFAULTS[key] end
    return BlacklistSettings[key]
end

-- Settings that only affect the editor overlay / tooltip display, not the
-- underlying DB or frame visibility.  A lightweight refresh (just the overlay)
-- avoids the full Refresh() → editBox:SetText() cascade that breaks menus.
local OVERLAY_ONLY_SETTINGS = {
    editorlevel = true,
    editorrace = true,
    editorguild = true,
    editoradded = true,
    editorlastseen = true,
    tooltipnote = true,
    tooltipadded = true,
    tooltiplastseen = true,
}

function BL:SetSetting(key, value)
    if not BlacklistSettings then BlacklistSettings = {} end
    BlacklistSettings[key] = value
    if OVERLAY_ONLY_SETTINGS[key] then
        if self.UpdateEditorOverlay then self:UpdateEditorOverlay() end
    else
        self:RefreshAllOverlays()
    end
end

-- Keybind localization (must be set before Bindings.xml is processed)
_G.BINDING_HEADER_BLACKLIST = "Blacklist"
_G.BINDING_NAME_BLACKLIST_TOGGLE = "Toggle Blacklist"
_G.BINDING_NAME_BLACKLIST_ADD_TARGET = "Add Target to Blacklist"
_G.BINDING_NAME_BLACKLIST_ADD_TARGET_NOTE = "Add Target + Note"
_G.BINDING_NAME_BLACKLIST_ADD_MOUSEOVER = "Add Mouseover/Target"
_G.BINDING_NAME_BLACKLIST_ADD_MOUSEOVER_NOTE = "Add Mouseover/Target + Note"

--------------------------------------------------------------
-- Simple callback system
--------------------------------------------------------------
function BL:RegisterCallback(event, func)
    if not self.callbacks[event] then
        self.callbacks[event] = {}
    end
    self.callbacks[event][#self.callbacks[event] + 1] = func
end

function BL:Fire(event, ...)
    if not self.callbacks[event] then return end
    for _, func in ipairs(self.callbacks[event]) do
        func(...)
    end
end

--------------------------------------------------------------
-- Realm & name helpers
--------------------------------------------------------------
local cachedHomeRealm

function BL:GetHomeRealm()
    if not cachedHomeRealm then
        local realm = GetRealmName()
        if realm then
            cachedHomeRealm = realm:gsub("%s+", "")
        end
    end
    return cachedHomeRealm
end

function BL:NormalizeName(name)
    if not name then return nil end
    name = name:match("^%s*(.-)%s*$")  -- trim
    if #name == 0 then return nil end
    -- Capitalize first letter of each space-separated word, lowercase the rest.
    -- Uses space as word boundary so accented characters (é, ö, ñ) don't cause
    -- false word breaks (Lua's %a only matches ASCII).
    local words = {}
    for word in name:gmatch("%S+") do
        words[#words + 1] = word:sub(1, 1):upper() .. word:sub(2):lower()
    end
    return table.concat(words, " ")
end

function BL:GetFullName(name, realm)
    name = self:NormalizeName(name)
    if not name then return nil end
    -- Names with spaces are NPCs — no realm suffix
    if name:find(" ") then return name end
    if not realm or realm == "" then
        realm = self:GetHomeRealm()
    else
        realm = realm:gsub("%s+", "")
    end
    if not realm then return name end
    return name .. "-" .. realm
end

function BL:FormatDisplayName(fullName)
    if not fullName then return nil end
    -- NPCs (names with spaces) get quoted
    if fullName:find(" ") then
        return '"' .. fullName .. '"'
    end
    -- Strip home realm for cleaner display
    local name, realm = self:SplitFullName(fullName)
    if realm and realm == self:GetHomeRealm() then
        return name
    end
    return fullName
end

function BL:SplitFullName(fullName)
    if not fullName then return nil, nil end
    local name, realm = fullName:match("^([^%-]+)%-(.+)$")
    if name then
        return name, realm
    end
    return fullName, nil
end

function BL:GetUnitFullName(unit)
    if not unit or not UnitExists(unit) then return nil end
    local name, realm = UnitName(unit)
    if not name then return nil end
    return self:GetFullName(name, realm)
end

--------------------------------------------------------------
-- Legacy Normalize (compat — strips realm, uppercases first)
--------------------------------------------------------------
function BL:Normalize(name)
    if not name then return nil end
    name = name:match("^([^%-]+)") or name  -- strip realm
    return self:NormalizeName(name)
end

--------------------------------------------------------------
-- CRUD API (composite key)
--------------------------------------------------------------
function BL:AddPlayer(name, realm, note, classFile, source, unit)
    local fullName = self:GetFullName(name, realm)
    if not fullName then return end
    if BlacklistDB[fullName] then
        print("|cffff6060Blacklist:|r " .. fullName .. " is already blacklisted.")
        return
    end
    BlacklistDB[fullName] = {
        createdAt = time(),
        note = note or "",
        class = classFile,
        source = source or "slash",
    }
    -- Capture full metadata (level, race, guild, lastSeen) if unit is available
    if unit then
        self:UpdateUnitCache(unit)
    end
    print("|cffff6060Blacklist:|r Added " .. fullName .. ".")
    self:Fire("PLAYER_ADDED", fullName)
    self:RefreshAllOverlays()
end

function BL:RemovePlayer(name, realm)
    local fullName = self:GetFullName(name, realm)
    if not fullName then return end
    if not BlacklistDB[fullName] then
        print("|cffff6060Blacklist:|r " .. fullName .. " is not blacklisted.")
        return
    end
    BlacklistDB[fullName] = nil
    print("|cffff6060Blacklist:|r Removed " .. fullName .. ".")
    self:Fire("PLAYER_REMOVED", fullName)
    self:RefreshAllOverlays()
end

function BL:GetPlayerInfo(name, realm)
    local fullName = self:GetFullName(name, realm)
    if not fullName then return nil end
    return BlacklistDB[fullName]
end

--------------------------------------------------------------
-- Unit-based lookups
--------------------------------------------------------------
function BL:IsUnitBlacklisted(unit)
    local fullName = self:GetUnitFullName(unit)
    return fullName and BlacklistDB[fullName] ~= nil
end

function BL:GetUnitNote(unit)
    local fullName = self:GetUnitFullName(unit)
    if not fullName or not BlacklistDB[fullName] then return nil end
    return BlacklistDB[fullName].note
end

function BL:GetUnitClass(unit)
    local fullName = self:GetUnitFullName(unit)
    if not fullName or not BlacklistDB[fullName] then return nil end
    return BlacklistDB[fullName].class
end

--------------------------------------------------------------
-- Compat wrappers (accept "Name" or "Name-Realm")
--------------------------------------------------------------
function BL:Add(name, note, classFile)
    if not name then return end
    local n, r = self:SplitFullName(name)
    -- If no realm in input, try to normalize as plain name
    if not r then
        n = self:NormalizeName(n)
    end
    self:AddPlayer(n, r, note, classFile, "slash")
end

function BL:Remove(name)
    if not name then return end
    local n, r = self:SplitFullName(name)
    if not r then
        n = self:NormalizeName(n)
    end
    self:RemovePlayer(n, r)
end

function BL:IsBlacklisted(name, realm)
    if not name then return false end
    if realm then
        local fullName = self:GetFullName(name, realm)
        return fullName and BlacklistDB[fullName] ~= nil
    end
    -- Try as-is first (might be "Name-Realm" already)
    local n, r = self:SplitFullName(name)
    local fullName = self:GetFullName(n, r)
    return fullName and BlacklistDB[fullName] ~= nil
end

function BL:GetNote(name, realm)
    if not name then return nil end
    if realm then
        local fullName = self:GetFullName(name, realm)
        if not fullName or not BlacklistDB[fullName] then return nil end
        return BlacklistDB[fullName].note
    end
    local n, r = self:SplitFullName(name)
    local fullName = self:GetFullName(n, r)
    if not fullName or not BlacklistDB[fullName] then return nil end
    return BlacklistDB[fullName].note
end

--------------------------------------------------------------
-- Class storage / lookup
--------------------------------------------------------------
function BL:SetClass(fullName, classFile)
    if not fullName or not BlacklistDB[fullName] or not classFile then return end
    if BlacklistDB[fullName].class == classFile then return end
    BlacklistDB[fullName].class = classFile
    if self.UpdateEditorOverlay then self:UpdateEditorOverlay() end
end

function BL:GetClass(fullName)
    if not fullName or not BlacklistDB[fullName] then return nil end
    return BlacklistDB[fullName].class
end

--------------------------------------------------------------
-- Time formatting
--------------------------------------------------------------
function BL:FormatTimeAgo(epoch)
    if not epoch then return nil end
    local diff = time() - epoch
    if diff < 60 then return "just now" end
    if diff < 3600 then return math.floor(diff / 60) .. "m ago" end
    if diff < 86400 then return math.floor(diff / 3600) .. "h ago" end
    return math.floor(diff / 86400) .. "d ago"
end

--------------------------------------------------------------
-- Passive unit metadata scanner
--------------------------------------------------------------
local lastSeenThrottle = {} -- fullName → last write epoch
local alertCooldowns = {}   -- fullName → last alert epoch

function BL:UpdateUnitCache(unit)
    if not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then return end
    local fullName = self:GetUnitFullName(unit)
    if not fullName then return end
    local entry = BlacklistDB[fullName]
    if not entry then return end

    -- Alert sound (throttled to once per 30s per player)
    if entry.alert then
        local now = time()
        if not alertCooldowns[fullName] or (now - alertCooldowns[fullName]) > 30 then
            PlaySound(8959, "Master")  -- SOUNDKIT.RAID_WARNING
            alertCooldowns[fullName] = now
        end
    end

    -- Class
    local classFile = select(2, UnitClass(unit))
    if classFile and entry.class ~= classFile then
        entry.class = classFile
    end

    -- Level (skip -1 / skull)
    local level = UnitLevel(unit)
    if level and level > 0 and entry.level ~= level then
        entry.level = level
    end

    -- Race
    local _, raceFile = UnitRace(unit)
    if raceFile and entry.race ~= raceFile then
        entry.race = raceFile
    end

    -- Guild (nil clears stale guild)
    local guild = GetGuildInfo(unit)
    if entry.guild ~= guild then
        entry.guild = guild
    end

    -- lastSeen (throttled to once per 60s per player)
    local now = time()
    if not lastSeenThrottle[fullName] or (now - lastSeenThrottle[fullName]) >= 60 then
        entry.lastSeen = now
        lastSeenThrottle[fullName] = now
    end

    if self.UpdateEditorOverlay then self:UpdateEditorOverlay() end
end

--------------------------------------------------------------
-- Scan visible units for metadata (editor open, etc.)
--------------------------------------------------------------
function BL:ScanUnitsForMetadata()
    for _, nameplate in ipairs(C_NamePlate.GetNamePlates()) do
        local unit = nameplate.namePlateUnitToken
        if unit then self:UpdateUnitCache(unit) end
    end
    local n = GetNumGroupMembers()
    local inRaid = IsInRaid()
    for i = 1, n do
        self:UpdateUnitCache(inRaid and ("raid" .. i) or ("party" .. i))
    end
    for _, unit in ipairs({"target", "focus"}) do
        self:UpdateUnitCache(unit)
    end
end

-- Compat alias
BL.ScanUnitsForClass = BL.ScanUnitsForMetadata

--------------------------------------------------------------
-- Parse an editor line: "Name-Realm note" → nameToken, note
-- Returns the raw name token (no normalization), plus note.
--------------------------------------------------------------
function BL:ParseLine(line)
    if not line then return nil, "", false end
    local trimmed = line:match("^%s*(.-)%s*$")
    if not trimmed or #trimmed == 0 then return nil, "", false end
    -- Try quoted: "Some Name"! optional note
    local quoted, bang, qnote = trimmed:match('^"([^"]+)"(!?)%s*(.*)')
    if quoted then return quoted, qnote or "", bang == "!" end
    -- Fallback: first token is name, rest is note
    local nameToken, note = trimmed:match("^(%S+)%s+(.*)")
    if not nameToken then
        nameToken = trimmed
        note = ""
    end
    local isAlert = nameToken:sub(-1) == "!"
    if isAlert then nameToken = nameToken:sub(1, -2) end
    return nameToken, note or "", isAlert
end

--------------------------------------------------------------
-- Resolve a raw name token from ParseLine to a composite key
--------------------------------------------------------------
function BL:ResolveNameToken(token)
    if not token then return nil end
    local n, r = self:SplitFullName(token)
    return self:GetFullName(n, r)
end

--------------------------------------------------------------
-- Sync editor text → BlacklistDB
--------------------------------------------------------------
local editorGraveyard = {}  -- preserves metadata of removed entries for undo

function BL:SyncFromEditor(text)
    if not text then return end
    local new = {}
    for line in text:gmatch("[^\n]+") do
        local nameToken, note, isAlert = self:ParseLine(line)
        if nameToken then
            local fullName = self:ResolveNameToken(nameToken)
            if fullName and not new[fullName] then
                local old = BlacklistDB[fullName]
                if not old and editorGraveyard[fullName] then
                    old = editorGraveyard[fullName]
                    editorGraveyard[fullName] = nil
                end
                new[fullName] = old or { createdAt = time(), note = "", class = nil, source = "editor" }
                new[fullName].note = note
                new[fullName].alert = isAlert or nil
            end
        end
    end
    -- Save removed entries to graveyard so undo can restore metadata
    for fullName, entry in pairs(BlacklistDB) do
        if not new[fullName] then
            editorGraveyard[fullName] = entry
        end
    end
    BlacklistDB = new
    if self.RefreshNameplates then self:RefreshNameplates() end
    if self.RefreshTargetFocus then self:RefreshTargetFocus() end
end

--------------------------------------------------------------
-- Refresh hooks (populated by other files)
--------------------------------------------------------------
function BL:RefreshAllOverlays()
    if self.RefreshNameplates then self:RefreshNameplates() end
    if self.RefreshTargetFocus then self:RefreshTargetFocus() end
    if self.RefreshRaidFrames then self:RefreshRaidFrames() end
    if self.RefreshUI then self:RefreshUI() end
    if self.RefreshGutter then self:RefreshGutter() end
end

--------------------------------------------------------------
-- Migration: flat keys → composite keys
--------------------------------------------------------------
local function MigrateDB()
    local homeRealm = BL:GetHomeRealm()
    if not homeRealm then return end

    local toMigrate = {}
    for key, entry in pairs(BlacklistDB) do
        -- Flat key = no hyphen
        if not key:find("%-") then
            toMigrate[key] = entry
        end
    end

    local count = 0
    for oldKey, entry in pairs(toMigrate) do
        local newKey = BL:GetFullName(oldKey, homeRealm)
        if newKey and not BlacklistDB[newKey] then
            -- Rename added → timestamp
            if entry.added and not entry.timestamp then
                entry.timestamp = entry.added
                entry.added = nil
            end
            if not entry.timestamp then
                entry.timestamp = date("%Y-%m-%d %H:%M")
            end
            entry.source = entry.source or "migrated"
            BlacklistDB[newKey] = entry
            count = count + 1
        end
        BlacklistDB[oldKey] = nil
    end

    if count > 0 then
        print("|cffff6060Blacklist:|r Migrated " .. count .. " entries to Name-Realm format.")
    end

    -- Migrate timestamp strings → createdAt epoch integers
    for key, entry in pairs(BlacklistDB) do
        if entry.timestamp and not entry.createdAt then
            local y, mo, d, h, mi = entry.timestamp:match("^(%d+)-(%d+)-(%d+)%s+(%d+):(%d+)")
            if y then
                entry.createdAt = time({year = tonumber(y), month = tonumber(mo), day = tonumber(d), hour = tonumber(h), min = tonumber(mi), sec = 0})
            else
                entry.createdAt = time()
            end
            entry.timestamp = nil
        end
        -- Also handle legacy "added" field
        if entry.added and not entry.createdAt then
            entry.createdAt = time()
            entry.added = nil
        end
    end
end

--------------------------------------------------------------
-- Init
--------------------------------------------------------------
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGOUT")
f:SetScript("OnEvent", function(_, event, addon)
    if event == "ADDON_LOADED" then
        if addon ~= ADDON_NAME then return end
        BlacklistDB = BlacklistDB or {}
        BlacklistSettings = BlacklistSettings or {}
        MigrateDB()
        f:UnregisterEvent("ADDON_LOADED")
    elseif event == "PLAYER_LOGOUT" then
        if not BL.GetEditorText then return end
        local text, dirty = BL:GetEditorText()
        if text and dirty then BL:SyncFromEditor(text) end
    end
end)

--------------------------------------------------------------
-- Slash commands
--------------------------------------------------------------
SLASH_BLACKLIST1 = "/bl"
SLASH_BLACKLIST2 = "/blacklist"
SlashCmdList["BLACKLIST"] = function(msg)
    local cmd, rest = msg:match("^(%S+)%s*(.*)")
    if not cmd then
        if BL.ToggleUI then BL:ToggleUI() end
        return
    end
    cmd = cmd:lower()
    if cmd == "add" and rest and #rest > 0 then
        -- Support "Name-Realm note" or "Name note"
        local nameToken, note = rest:match("^(%S+)%s+(.*)")
        if not nameToken then
            nameToken = rest
            note = nil
        end
        local n, r = BL:SplitFullName(nameToken)
        BL:AddPlayer(n, r, note, nil, "slash")
    elseif cmd == "remove" or cmd == "rm" or cmd == "del" then
        if rest and #rest > 0 then
            local n, r = BL:SplitFullName(rest:match("^%S+"))
            BL:RemovePlayer(n, r)
        end
    elseif cmd == "list" or cmd == "ls" then
        local count = 0
        for fullName, info in pairs(BlacklistDB) do
            local ts = info.createdAt and date("%Y-%m-%d %H:%M", info.createdAt) or ""
            print("  " .. fullName .. "  (" .. ts .. ")")
            count = count + 1
        end
        if count == 0 then print("|cffff6060Blacklist:|r List is empty.") end
    elseif cmd == "target" then
        if UnitExists("target") then
            local uName, uRealm = UnitName("target")
            local classFile = UnitIsPlayer("target") and select(2, UnitClass("target")) or nil
            BL:AddPlayer(uName, uRealm, nil, classFile, "slash", "target")
        else
            print("|cffff6060Blacklist:|r No target.")
        end
    elseif cmd == "toggle" and rest and #rest > 0 then
        local setting = rest:lower()
        if setting == "chat" or setting == "tooltip" or setting == "nameplate" or setting == "gutter"
           or setting == "targetframe" or setting == "focusframe" or setting == "raidframe"
           or setting == "editorlevel" or setting == "editorrace" or setting == "editorguild"
           or setting == "editoradded" or setting == "editorlastseen"
           or setting == "tooltipnote" or setting == "tooltipadded" or setting == "tooltiplastseen" then
            local current = BL:GetSetting(setting)
            BL:SetSetting(setting, not current)
            local state = BL:GetSetting(setting) and "enabled" or "disabled"
            print("|cffff6060Blacklist:|r " .. setting .. " " .. state .. ".")
        else
            print("|cffff6060Blacklist:|r Unknown setting. Use: chat, tooltip, nameplate, gutter, targetframe, focusframe, raidframe, editorlevel, editorrace, editorguild, editoradded, editorlastseen, tooltipnote, tooltipadded, tooltiplastseen")
        end
    else
        print("|cffff6060Blacklist:|r Usage: /bl [add|remove|list|target|toggle] [name]")
    end
end

--------------------------------------------------------------
-- Context menu: "Add to Blacklist" on player unit frames
--------------------------------------------------------------
if UnitPopup_ShowMenu then
    hooksecurefunc("UnitPopup_ShowMenu", function(dropdownMenu, which, unit, name, userData)
        if not unit or not UnitIsPlayer(unit) then return end
        if which ~= "PLAYER" and which ~= "PARTY" and which ~= "RAID_PLAYER" then return end
        local isListed = BL:IsUnitBlacklisted(unit)
        local info = UIDropDownMenu_CreateInfo()
        info.text = isListed and "Remove from Blacklist" or "Add to Blacklist"
        info.notCheckable = true
        info.func = function()
            local uName, uRealm = UnitName(unit)
            if isListed then
                BL:RemovePlayer(uName, uRealm)
            else
                BL:AddPlayer(uName, uRealm, nil, select(2, UnitClass(unit)), "context", unit)
            end
        end
        UIDropDownMenu_AddButton(info)
    end)
end
