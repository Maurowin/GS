local _, BL = ...

--------------------------------------------------------------
-- Constants
--------------------------------------------------------------
local NOTE_FONT = "Fonts\\FRIZQT__.TTF"
local NOTE_FONT_SIZE = 11
local RAID_FONT_SIZE = 9
local MAX_NOTE_LENGTH = 40        -- Target/focus frames
local RAID_MAX_NOTE_LENGTH = 15   -- Raid frames (truncate + tooltip)
local NOTE_COLOR = {1, 0.82, 0, 1}  -- Gold color
local needsRaidRefresh = false

--------------------------------------------------------------
-- Helper: Truncate note with ellipsis
--------------------------------------------------------------
local function TruncateNote(note, maxLen)
    if not note or #note <= maxLen then return note end
    return note:sub(1, maxLen - 3) .. "..."
end

--------------------------------------------------------------
-- Helper: Create note FontString for target/focus frames
--------------------------------------------------------------
local function CreateNoteText(parent, posKey)
    -- Use a higher strata frame to ensure visibility above other UI
    local container = CreateFrame("Frame", nil, parent)
    container:SetFrameStrata("HIGH")
    container:SetAllPoints(parent)

    local noteText = container:CreateFontString(nil, "OVERLAY")
    noteText:SetFont(NOTE_FONT, NOTE_FONT_SIZE, "OUTLINE")
    noteText:SetJustifyH("LEFT")
    noteText:SetTextColor(unpack(NOTE_COLOR))
    noteText:Hide()
    noteText.container = container
    noteText.posKey = posKey

    -- Apply initial position (anchored to center of name)
    local pos = BL:GetSetting(posKey) or {x = 4, y = 0}
    local nameRegion = parent.Name or parent.name
    if nameRegion then
        noteText:SetPoint("LEFT", nameRegion, "CENTER", pos.x, pos.y)
    else
        noteText:SetPoint("TOPLEFT", parent, "TOPRIGHT", pos.x, pos.y - 4)
    end

    return noteText
end

--------------------------------------------------------------
-- Helper: Create note FontString for raid/party frames
--------------------------------------------------------------
local function CreateRaidNoteText(parent)
    local noteText = parent:CreateFontString(nil, "OVERLAY")
    noteText:SetFont(NOTE_FONT, RAID_FONT_SIZE, "OUTLINE")
    noteText:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT", 2, 2)
    noteText:SetJustifyH("LEFT")
    noteText:SetTextColor(unpack(NOTE_COLOR))
    noteText:Hide()
    return noteText
end

--------------------------------------------------------------
-- Helper: Setup tooltip for truncated raid notes
--------------------------------------------------------------
local function SetupRaidNoteTooltip(noteFrame, fullNote)
    noteFrame.fullNote = fullNote
    noteFrame:EnableMouse(true)
    noteFrame:SetScript("OnEnter", function(self)
        if self.fullNote and #self.fullNote > RAID_MAX_NOTE_LENGTH then
            GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
            GameTooltip:SetText("Blacklist Note", 1, 0.82, 0)
            GameTooltip:AddLine(self.fullNote, 1, 1, 1, true)
            GameTooltip:Show()
        end
    end)
    noteFrame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
end

--------------------------------------------------------------
-- Target/Focus Frame Support
--------------------------------------------------------------
local targetNoteText, focusNoteText

local function UpdateFrameNote(frame, unit, noteKey, settingKey)
    if not frame then return end

    -- Determine position key based on setting key
    local posKey = (settingKey == "targetframe") and "targetframepos" or "focusframepos"

    -- Create note text if needed
    if not frame.blacklistNote then
        frame.blacklistNote = CreateNoteText(frame, posKey)
    end
    local noteText = frame.blacklistNote

    -- Check if feature is enabled
    if not BL:GetSetting(settingKey) then
        noteText:Hide()
        return
    end

    -- Check unit exists and is a player
    if not UnitExists(unit) or not UnitIsPlayer(unit) then
        noteText:Hide()
        return
    end

    -- Check blacklist using unit-based lookup
    if not BL:IsUnitBlacklisted(unit) then
        noteText:Hide()
        return
    end

    -- Get and display the note
    local note = BL:GetUnitNote(unit) or ""
    if #note > 0 then
        noteText:SetText(TruncateNote(note, MAX_NOTE_LENGTH))
    else
        noteText:SetText("(blacklisted)")
    end
    noteText:Show()

end

local function UpdateTargetFrame()
    UpdateFrameNote(TargetFrame, "target", "targetNote", "targetframe")
end

local function UpdateFocusFrame()
    -- FocusFrame may not exist in all WoW versions
    if FocusFrame then
        UpdateFrameNote(FocusFrame, "focus", "focusNote", "focusframe")
    end
end

--------------------------------------------------------------
-- Raid/Party Frame Support
--------------------------------------------------------------
local function UpdateCompactUnitFrame(frame)
    if InCombatLockdown() then needsRaidRefresh = true return end
    if not frame or frame:IsForbidden() then return end

    -- Create note text if needed
    if not frame.blacklistNote then
        local noteText = CreateRaidNoteText(frame)
        frame.blacklistNote = noteText
        -- Create a clickable frame overlay for tooltip
        local noteFrame = CreateFrame("Frame", nil, frame)
        noteFrame:SetAllPoints(noteText)
        noteFrame:SetFrameLevel(frame:GetFrameLevel() + 10)
        frame.blacklistNoteFrame = noteFrame
        SetupRaidNoteTooltip(noteFrame, nil)
    end

    local noteText = frame.blacklistNote
    local noteFrame = frame.blacklistNoteFrame

    -- Check if feature is enabled
    if not BL:GetSetting("raidframe") then
        noteText:Hide()
        if noteFrame then noteFrame:Hide() end
        return
    end

    -- Get unit from frame
    local unit = frame.unit or frame.displayedUnit
    if not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then
        noteText:Hide()
        if noteFrame then noteFrame:Hide() end
        return
    end

    -- Check blacklist using unit-based lookup
    if not BL:IsUnitBlacklisted(unit) then
        noteText:Hide()
        if noteFrame then noteFrame:Hide() end
        return
    end

    -- Get and display the note (truncated)
    local fullNote = BL:GetUnitNote(unit) or ""
    local displayText
    if #fullNote > 0 then
        displayText = TruncateNote(fullNote, RAID_MAX_NOTE_LENGTH)
    else
        displayText = "BL"  -- Short indicator for raid frames
    end

    noteText:SetText(displayText)
    noteText:Show()

    -- Update tooltip frame
    if noteFrame then
        noteFrame.fullNote = fullNote
        noteFrame:SetAllPoints(noteText)
        noteFrame:Show()
    end
end

local function UpdatePartyFrames()
    for i = 1, 4 do
        local frame = _G["PartyMemberFrame" .. i]
        if frame and frame:IsShown() then
            -- Create note if needed (party frames use target position since they're similar)
            if not frame.blacklistNote then
                frame.blacklistNote = CreateNoteText(frame, "targetframepos")
            end
            local noteText = frame.blacklistNote

            -- Check if feature is enabled
            if not BL:GetSetting("raidframe") then
                noteText:Hide()
            else
                local unit = "party" .. i
                if UnitExists(unit) and UnitIsPlayer(unit) and BL:IsUnitBlacklisted(unit) then
                    local note = BL:GetUnitNote(unit) or ""
                    if #note > 0 then
                        noteText:SetText(TruncateNote(note, MAX_NOTE_LENGTH))
                    else
                        noteText:SetText("(blacklisted)")
                    end
                    noteText:Show()
                else
                    noteText:Hide()
                end
            end
        end
    end
end

local function UpdateAllRaidFrames()
    -- Update CompactRaidFrames (Blizzard raid UI)
    if CompactRaidFrameContainer then
        local function IterateFrames(container)
            if not container then return end
            for i = 1, 40 do
                local frame = _G["CompactRaidFrame" .. i]
                if frame then
                    UpdateCompactUnitFrame(frame)
                end
            end
            -- Also check group frames
            for i = 1, 8 do
                local group = _G["CompactRaidGroup" .. i]
                if group then
                    for j = 1, 5 do
                        local frame = _G["CompactRaidGroup" .. i .. "Member" .. j]
                        if frame then
                            UpdateCompactUnitFrame(frame)
                        end
                    end
                end
            end
        end
        IterateFrames(CompactRaidFrameContainer)
    end

    -- Update CompactPartyFrame members
    if CompactPartyFrame then
        for i = 1, 5 do
            local frame = _G["CompactPartyFrameMember" .. i]
            if frame then
                UpdateCompactUnitFrame(frame)
            end
        end
    end

    -- Update classic party frames
    UpdatePartyFrames()
end

--------------------------------------------------------------
-- Refresh callbacks for Core.lua
--------------------------------------------------------------
function BL:RefreshTargetFocus()
    UpdateTargetFrame()
    UpdateFocusFrame()
end

function BL:RefreshRaidFrames()
    UpdateAllRaidFrames()
end

--------------------------------------------------------------
-- Position refresh for the position picker
--------------------------------------------------------------
local function UpdateNotePosition(frame, posKey)
    if not frame or not frame.blacklistNote then return end
    local noteText = frame.blacklistNote
    local pos = BL:GetSetting(posKey) or {x = 4, y = 0}
    local nameRegion = frame.Name or frame.name

    noteText:ClearAllPoints()
    if nameRegion then
        noteText:SetPoint("LEFT", nameRegion, "CENTER", pos.x, pos.y)
    else
        noteText:SetPoint("TOPLEFT", frame, "TOPRIGHT", pos.x, pos.y - 4)
    end
end

function BL:RefreshNotePositions()
    UpdateNotePosition(TargetFrame, "targetframepos")
    if FocusFrame then
        UpdateNotePosition(FocusFrame, "focusframepos")
    end
end

--------------------------------------------------------------
-- Event handling
--------------------------------------------------------------
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
eventFrame:RegisterEvent("PLAYER_FOCUS_CHANGED")
eventFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
eventFrame:RegisterEvent("UNIT_NAME_UPDATE")
eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")
eventFrame:RegisterEvent("PARTY_MEMBER_ENABLE")
eventFrame:RegisterEvent("PARTY_MEMBER_DISABLE")
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "PLAYER_TARGET_CHANGED" then
        BL:UpdateUnitCache("target")
        UpdateTargetFrame()
    elseif event == "PLAYER_FOCUS_CHANGED" then
        BL:UpdateUnitCache("focus")
        UpdateFocusFrame()
    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        BL:UpdateUnitCache("mouseover")
    elseif event == "UNIT_NAME_UPDATE" then
        local unit = ...
        BL:UpdateUnitCache(unit)
        if unit == "target" then
            UpdateTargetFrame()
        elseif unit == "focus" then
            UpdateFocusFrame()
        elseif unit:match("^party") or unit:match("^raid") then
            UpdateAllRaidFrames()
        end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if needsRaidRefresh then
            needsRaidRefresh = false
            UpdateAllRaidFrames()
        end
    elseif event == "GROUP_ROSTER_UPDATE" or event == "PARTY_MEMBER_ENABLE" or event == "PARTY_MEMBER_DISABLE" then
        local n = GetNumGroupMembers()
        local inRaid = IsInRaid()
        for i = 1, n do
            BL:UpdateUnitCache(inRaid and ("raid" .. i) or ("party" .. i))
        end
        UpdateAllRaidFrames()
    end
end)

--------------------------------------------------------------
-- Hook CompactUnitFrame_UpdateName if available
--------------------------------------------------------------
if CompactUnitFrame_UpdateName then
    hooksecurefunc("CompactUnitFrame_UpdateName", function(frame)
        if frame and not frame:IsForbidden() then
            UpdateCompactUnitFrame(frame)
        end
    end)
end

--------------------------------------------------------------
-- Initial update after login
--------------------------------------------------------------
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:HookScript("OnEvent", function(self, event)
    if event == "PLAYER_ENTERING_WORLD" then
        C_Timer.After(1, function()
            BL:RefreshTargetFocus()
            BL:RefreshRaidFrames()
        end)
    end
end)
