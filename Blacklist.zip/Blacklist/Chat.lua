local ADDON_NAME, BL = ...

-- Hook AddMessage on chat frames (ChatFrame_AddMessageEventFilter doesn't work in Anniversary)
local function HookChatFrame(frame)
    if not frame or frame.BL_Hooked then return end

    local orig = frame.AddMessage
    frame.AddMessage = function(self, text, ...)
        if text and type(text) == "string" and BL:GetSetting("chat") then
            -- Find player links: |Hplayer:Name-Server:...|h[DisplayName]|h
            text = text:gsub("(|Hplayer:([^:]+)[^|]*|h%[[^%]]+%]|h)", function(link, nameWithRealm)
                local name, realm = nameWithRealm:match("^([^%-]+)%-(.+)$")
                if not name then
                    name = nameWithRealm
                    realm = nil
                end
                local note = BL:GetNote(name, realm)
                if note and #note > 0 then
                    -- Gold color matches nameplate notes: RGB(255, 209, 0)
                    return link .. " |cffFFD100[" .. note .. "]|r"
                end
                return link
            end)
        end
        return orig(self, text, ...)
    end

    frame.BL_Hooked = true
end

-- Hook all existing chat frames
for i = 1, NUM_CHAT_WINDOWS do
    HookChatFrame(_G["ChatFrame" .. i])
end

-- Hook temporary chat frames (whispers, etc.) when they're created
hooksecurefunc("FCF_OpenTemporaryWindow", function()
    for i = 1, NUM_CHAT_WINDOWS do
        HookChatFrame(_G["ChatFrame" .. i])
    end
end)
