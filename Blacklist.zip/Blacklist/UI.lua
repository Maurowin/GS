local _, BL = ...

-- Forward declaration (assigned at bottom, referenced by OnTextChanged and Refresh)
local statusText

--------------------------------------------------------------
-- Font configuration
-- Drop any .ttf as "Font.ttf" in the addon folder to use it.
--------------------------------------------------------------
local FONT_SIZE = 11
local FONT = "Fonts\\FRIZQT__.TTF"

-- Every element that calls ApplyFont is tracked so the deferred
-- font upgrade can re-apply without losing per-element colors.
local fontElements = {}

local function ApplyFont(element, size)
    size = size or FONT_SIZE
    if not element:SetFont(FONT, size, "") then
        local standardFont = GameFontNormal:GetFont()
        element:SetFont(standardFont, size, "")
    end
    fontElements[#fontElements + 1] = {el = element, sz = size}
end

-- After one frame the addon's VFS entries are available; try the
-- custom font and re-apply to all tracked elements if it loads.
C_Timer.After(0, function()
    local probe = CreateFrame("Frame"):CreateFontString(nil, "ARTWORK")
    for _, path in ipairs({
        "Interface\\AddOns\\Blacklist\\Font.ttf",
        "Interface\\AddOns\\Blacklist\\font.ttf",
    }) do
        probe:SetFont(path, FONT_SIZE, "")
        if probe:GetFont() then
            FONT = path
            for _, entry in ipairs(fontElements) do
                entry.el:SetFont(FONT, entry.sz, "")
            end
            return
        end
    end
end)
local SCROLLBAR_WIDTH = 8
local GUTTER_PAD_LEFT = 4
local GUTTER_PAD_RIGHT = 6  -- space before separator
local GUTTER_SEP = 1        -- separator line width
local CHAR_WIDTH = FONT_SIZE * 0.6  -- monospace character width estimate

local function ComputeGutterWidth(lineCount)
    local digits = math.max(1, math.floor(math.log10(math.max(1, lineCount))) + 1)
    return math.floor(GUTTER_PAD_LEFT + digits * CHAR_WIDTH + GUTTER_PAD_RIGHT + GUTTER_SEP)
end

local GUTTER_WIDTH = ComputeGutterWidth(1)

--------------------------------------------------------------
-- Colors matching CommanderEdit's default theme
--------------------------------------------------------------
local C = {
    bg          = {0.082, 0.090, 0.098, 0.95},
    text        = {0.75, 0.88, 0.92, 1},  -- Light cyan, distinct from Priest white
    menubarBg   = {0.553, 0.467, 0.639, 1},
    menubarText = {0.08, 0.06, 0.02, 1},
    menubarHi   = {0.35, 0.45, 0.55, 0.7},
    statusBg    = {0.553, 0.467, 0.639, 1},
    statusText  = {0.08, 0.06, 0.02, 1},
    border      = {0.18, 0.20, 0.22, 1},
    scrollBg    = {0.05, 0.06, 0.07, 1},
    scrollThumb = {0.35, 0.38, 0.45, 1},
    scrollHover = {0.45, 0.48, 0.55, 1},
    -- Search colors
    searchBg      = {0.10, 0.11, 0.12, 1},
    matchHighlight = {0.6, 0.5, 0.2, 0.4},   -- Amber for all matches
    currentMatch   = {0.8, 0.6, 0.1, 0.6},   -- Brighter for current match
}

local LINE_HEIGHT = FONT_SIZE
local MENUBAR_HEIGHT = LINE_HEIGHT
local STATUSBAR_HEIGHT = LINE_HEIGHT
local WIN_W, WIN_H = 400, 340

--------------------------------------------------------------
-- Search state
--------------------------------------------------------------
local searchState = {
    active = false,
    query = "",
    matches = {},        -- {line, startCol, endCol, startPos, endPos}
    currentIndex = 0,
    caseSensitive = false,
}
local matchHighlights = {}  -- Texture pool for highlight rectangles

-- Forward declarations for search functions (defined later)
local ShowSearchBar, HideSearchBar, RunSearch

--------------------------------------------------------------
-- Helper: create 1px border textures on a frame
--------------------------------------------------------------
local function CreateBorderTextures(frame, layer)
    local t = frame:CreateTexture(nil, layer)
    t:SetPoint("TOPLEFT"); t:SetPoint("TOPRIGHT"); t:SetHeight(1)
    t:SetColorTexture(unpack(C.border))
    local b = frame:CreateTexture(nil, layer)
    b:SetPoint("BOTTOMLEFT"); b:SetPoint("BOTTOMRIGHT"); b:SetHeight(1)
    b:SetColorTexture(unpack(C.border))
    local l = frame:CreateTexture(nil, layer)
    l:SetPoint("TOPLEFT"); l:SetPoint("BOTTOMLEFT"); l:SetWidth(1)
    l:SetColorTexture(unpack(C.border))
    local r = frame:CreateTexture(nil, layer)
    r:SetPoint("TOPRIGHT"); r:SetPoint("BOTTOMRIGHT"); r:SetWidth(1)
    r:SetColorTexture(unpack(C.border))
end

--------------------------------------------------------------
-- Main frame
--------------------------------------------------------------
local frame = CreateFrame("Frame", "BlacklistMainFrame", UIParent, "BackdropTemplate")
frame:SetSize(WIN_W, WIN_H)
frame:SetPoint("CENTER")
frame:SetFrameStrata("DIALOG")
frame:SetFrameLevel(100)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:SetClampedToScreen(true)
frame:Hide()

-- Background
local mainBg = frame:CreateTexture(nil, "BACKGROUND")
mainBg:SetAllPoints()
mainBg:SetColorTexture(unpack(C.bg))

-- Window border
CreateBorderTextures(frame, "BORDER")

tinsert(UISpecialFrames, "BlacklistMainFrame")

--------------------------------------------------------------
-- Menubar (title bar)
--------------------------------------------------------------
local menubar = CreateFrame("Frame", nil, frame)
menubar:SetPoint("TOPLEFT", 0, 0)
menubar:SetPoint("TOPRIGHT", 0, 0)
menubar:SetHeight(MENUBAR_HEIGHT)
menubar:EnableMouse(true)
menubar:RegisterForDrag("LeftButton")
menubar:SetScript("OnDragStart", function() frame:StartMoving() end)
menubar:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)

local menubarBg = menubar:CreateTexture(nil, "BACKGROUND")
menubarBg:SetAllPoints()
menubarBg:SetColorTexture(unpack(C.menubarBg))
-- Title button (left) - clickable to open settings dropdown
local titleBtn = CreateFrame("Button", nil, menubar)
titleBtn:SetPoint("LEFT", 0, 0)
titleBtn:SetHeight(MENUBAR_HEIGHT)

local titleText = titleBtn:CreateFontString(nil, "OVERLAY")
ApplyFont(titleText)
titleText:SetTextColor(unpack(C.menubarText))
titleText:SetPoint("LEFT", 6, 0)
titleText:SetText("Blacklist")

-- Size button to fit text (one-shot; delayed so custom font has applied)
C_Timer.After(0.05, function() titleBtn:SetWidth(titleText:GetStringWidth() + 12) end)

-- Highlight on hover
local titleBtnBg = titleBtn:CreateTexture(nil, "BACKGROUND")
titleBtnBg:SetAllPoints()
titleBtnBg:SetColorTexture(0, 0, 0, 0)

titleBtn:SetScript("OnEnter", function()
    titleBtnBg:SetColorTexture(unpack(C.menubarHi))
end)
titleBtn:SetScript("OnLeave", function()
    titleBtnBg:SetColorTexture(0, 0, 0, 0)
end)

--------------------------------------------------------------
-- Settings dropdown menu
--------------------------------------------------------------
local settingsDropdown = CreateFrame("Frame", "BlacklistSettingsDropdown", UIParent, "BackdropTemplate")
settingsDropdown:SetFrameStrata("TOOLTIP")
settingsDropdown:SetSize(140, 84)  -- 4 + (4 * 19) + 4 = 84
settingsDropdown:Hide()

local dropdownBg = settingsDropdown:CreateTexture(nil, "BACKGROUND")
dropdownBg:SetAllPoints()
dropdownBg:SetColorTexture(0.082, 0.090, 0.098, 0.98)
CreateBorderTextures(settingsDropdown, "BORDER")

-- Forward declarations for submenus
local positionPickerPanel
local showMenuPanel
local tooltipMenuPanel
local editorMenuPanel

-- Main dropdown items (just submenus now)
local DROPDOWN_ITEMS = {
    {key = "show", label = "Show", submenuType = "show"},
    {key = "tooltip", label = "Tooltip", submenuType = "tooltip"},
    {key = "editor", label = "Editor", submenuType = "editor"},
    {key = "noteposition", label = "Note position", submenuType = "position"},
}

-- Show menu checkbox items (master toggles only)
local SHOW_MENU_ITEMS = {
    {key = "chat", label = "Chat notes"},
    {key = "tooltip", label = "Tooltip notes"},
    {key = "nameplate", label = "Nameplate notes"},
    {key = "targetframe", label = "Target frame"},
    {key = "focusframe", label = "Focus frame"},
    {key = "raidframe", label = "Raid/Party frames"},
    {key = "gutter", label = "Line numbers"},
}

-- Tooltip submenu items (per-field)
local TOOLTIP_MENU_ITEMS = {
    {key = "tooltipnote", label = "Note"},
    {key = "tooltipadded", label = "Added date"},
    {key = "tooltiplastseen", label = "Last seen"},
}

-- Editor submenu items (per-field)
local EDITOR_MENU_ITEMS = {
    {key = "editorlevel", label = "Level"},
    {key = "editorrace", label = "Race"},
    {key = "editorguild", label = "Guild"},
    {key = "editoradded", label = "Added date"},
    {key = "editorlastseen", label = "Last seen"},
}

local dropdownCheckboxes = {}

local function CheckboxText(enabled)
    if enabled then
        return "|cff8D77A3[x]|r"
    else
        return "|cff666666[ ]|r"
    end
end

local function HideAllSubmenus()
    if showMenuPanel then showMenuPanel:Hide() end
    if tooltipMenuPanel then tooltipMenuPanel:Hide() end
    if editorMenuPanel then editorMenuPanel:Hide() end
    if positionPickerPanel then positionPickerPanel:Hide() end
end

-- Create main dropdown submenu items
for i, item in ipairs(DROPDOWN_ITEMS) do
    local row = CreateFrame("Button", nil, settingsDropdown)
    row:SetSize(130, 18)  -- Width = dropdown width (140) - 2*padding (5)
    row:SetPoint("TOPLEFT", 5, -4 - (i - 1) * 19)  -- Tighter vertical spacing

    local label = row:CreateFontString(nil, "OVERLAY")
    ApplyFont(label)
    label:SetTextColor(unpack(C.text))
    label:SetPoint("LEFT", 6, 0)
    label:SetText(item.label)
    row.label = label

    local arrow = row:CreateFontString(nil, "OVERLAY")
    ApplyFont(arrow)
    arrow:SetTextColor(0.6, 0.6, 0.6, 1)
    arrow:SetPoint("RIGHT", 0, 0)  -- Moved from -4 to 0 (row is already narrower)
    arrow:SetText(">")
    row.arrow = arrow

    row.submenuType = item.submenuType

    row:SetScript("OnEnter", function(self)
        label:SetTextColor(1, 1, 1, 1)
        arrow:SetTextColor(1, 1, 1, 1)
        -- Show appropriate submenu on hover
        HideAllSubmenus()
        if self.submenuType == "show" and showMenuPanel then
            showMenuPanel:ClearAllPoints()
            showMenuPanel:SetPoint("TOPLEFT", settingsDropdown, "TOPRIGHT", 2, 0)
            showMenuPanel:Show()
        elseif self.submenuType == "tooltip" and tooltipMenuPanel then
            tooltipMenuPanel:ClearAllPoints()
            tooltipMenuPanel:SetPoint("TOPLEFT", settingsDropdown, "TOPRIGHT", 2, -19)
            tooltipMenuPanel:Show()
        elseif self.submenuType == "editor" and editorMenuPanel then
            editorMenuPanel:ClearAllPoints()
            editorMenuPanel:SetPoint("TOPLEFT", settingsDropdown, "TOPRIGHT", 2, -38)
            editorMenuPanel:Show()
        elseif self.submenuType == "position" and positionPickerPanel then
            positionPickerPanel:ClearAllPoints()
            positionPickerPanel:SetPoint("TOPLEFT", settingsDropdown, "TOPRIGHT", 2, -57)
            positionPickerPanel:Show()
        end
    end)
    row:SetScript("OnLeave", function()
        label:SetTextColor(unpack(C.text))
        arrow:SetTextColor(0.6, 0.6, 0.6, 1)
    end)
end

local function UpdateDropdownCheckboxes()
    for key, row in pairs(dropdownCheckboxes) do
        if row.checkbox then
            row.checkbox:SetText(CheckboxText(BL:GetSetting(key)))
        end
    end
end

local function ShowSettingsDropdown()
    UpdateDropdownCheckboxes()
    settingsDropdown:ClearAllPoints()
    settingsDropdown:SetPoint("TOPLEFT", titleBtn, "BOTTOMLEFT", 0, 0)
    settingsDropdown:Show()
end

local function HideSettingsDropdown()
    settingsDropdown:Hide()
end

titleBtn:SetScript("OnClick", function()
    if settingsDropdown:IsShown() then
        HideSettingsDropdown()
    else
        ShowSettingsDropdown()
    end
end)

-- Hide dropdown when clicking elsewhere
settingsDropdown:SetScript("OnShow", function()
    settingsDropdown:SetPropagateKeyboardInput(true)
end)

local dropdownHideChecker = CreateFrame("Frame")
dropdownHideChecker.checkSliderDrag = function()
    -- Check if any sliders are being dragged (set after panel is created)
    if positionPickerPanel and positionPickerPanel.sliderX and positionPickerPanel.sliderX.dragging then return true end
    if positionPickerPanel and positionPickerPanel.sliderY and positionPickerPanel.sliderY.dragging then return true end
    if positionPickerPanel and positionPickerPanel.focusSliderX and positionPickerPanel.focusSliderX.dragging then return true end
    if positionPickerPanel and positionPickerPanel.focusSliderY and positionPickerPanel.focusSliderY.dragging then return true end
    return false
end
dropdownHideChecker:SetScript("OnUpdate", function(self)
    if not settingsDropdown:IsShown() then return end
    if not IsMouseButtonDown("LeftButton") then return end
    -- Don't hide if a slider is being dragged
    if self.checkSliderDrag() then return end
    -- Don't hide if mouse is over dropdown, title button, or any submenu panel
    if settingsDropdown:IsMouseOver() or titleBtn:IsMouseOver() then return end
    if showMenuPanel and showMenuPanel:IsShown() and showMenuPanel:IsMouseOver() then return end
    if tooltipMenuPanel and tooltipMenuPanel:IsShown() and tooltipMenuPanel:IsMouseOver() then return end
    if editorMenuPanel and editorMenuPanel:IsShown() and editorMenuPanel:IsMouseOver() then return end
    if positionPickerPanel and positionPickerPanel:IsShown() and positionPickerPanel:IsMouseOver() then return end
    HideSettingsDropdown()
end)

-- Also hide when main frame hides
frame:HookScript("OnHide", function()
    HideSettingsDropdown()
end)

--------------------------------------------------------------
-- Checkbox panel helper (shared by Show, Tooltip, Editor menus)
--------------------------------------------------------------
local function CreateCheckboxPanel(name, items)
    local width = 150
    local height = 5 + #items * 20 + 5
    local panel = CreateFrame("Frame", name, UIParent, "BackdropTemplate")
    panel:SetFrameStrata("TOOLTIP")
    panel:SetFrameLevel(settingsDropdown:GetFrameLevel() + 1)
    panel:SetSize(width, height)
    panel:Hide()

    local bg = panel:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.082, 0.090, 0.098, 0.98)
    CreateBorderTextures(panel, "BORDER")

    for i, item in ipairs(items) do
        local row = CreateFrame("Button", nil, panel)
        row:SetSize(width - 10, 18)
        row:SetPoint("TOPLEFT", 5, -5 - (i - 1) * 20)

        local checkbox = row:CreateFontString(nil, "OVERLAY")
        ApplyFont(checkbox)
        checkbox:SetPoint("LEFT", 2, 0)
        row.checkbox = checkbox

        local label = row:CreateFontString(nil, "OVERLAY")
        ApplyFont(label)
        label:SetTextColor(unpack(C.text))
        label:SetPoint("LEFT", checkbox, "RIGHT", 4, 0)
        label:SetText(item.label)
        row.label = label

        row:SetScript("OnEnter", function()
            label:SetTextColor(1, 1, 1, 1)
        end)
        row:SetScript("OnLeave", function()
            label:SetTextColor(unpack(C.text))
        end)
        row:SetScript("OnClick", function()
            local current = BL:GetSetting(item.key)
            BL:SetSetting(item.key, not current)
            row.checkbox:SetText(CheckboxText(BL:GetSetting(item.key)))
        end)

        dropdownCheckboxes[item.key] = row
    end

    panel:SetScript("OnShow", function()
        UpdateDropdownCheckboxes()
    end)

    return panel
end

showMenuPanel = CreateCheckboxPanel("BlacklistShowMenu", SHOW_MENU_ITEMS)
tooltipMenuPanel = CreateCheckboxPanel("BlacklistTooltipMenu", TOOLTIP_MENU_ITEMS)
editorMenuPanel = CreateCheckboxPanel("BlacklistEditorMenu", EDITOR_MENU_ITEMS)

--------------------------------------------------------------
-- Position Picker Panel (submenu for note positioning)
--------------------------------------------------------------
local PICKER_WIDTH = 200
local PICKER_HEIGHT_LINKED = 105
local PICKER_HEIGHT_UNLINKED = 175  -- Extra space for focus sliders + label

-- Slider range
local OFFSET_MIN = -200
local OFFSET_MAX = 200

positionPickerPanel = CreateFrame("Frame", "BlacklistPositionPicker", UIParent, "BackdropTemplate")
positionPickerPanel:SetFrameStrata("TOOLTIP")
positionPickerPanel:SetFrameLevel(settingsDropdown:GetFrameLevel() + 1)
positionPickerPanel:SetSize(PICKER_WIDTH, PICKER_HEIGHT_LINKED)
positionPickerPanel:Hide()

local pickerBg = positionPickerPanel:CreateTexture(nil, "BACKGROUND")
pickerBg:SetAllPoints()
pickerBg:SetColorTexture(0.082, 0.090, 0.098, 0.98)
CreateBorderTextures(positionPickerPanel, "BORDER")

-- Link toggle checkbox at top
local linkToggle = CreateFrame("Button", nil, positionPickerPanel)
linkToggle:SetSize(PICKER_WIDTH - 10, 18)
linkToggle:SetPoint("TOPLEFT", 5, -5)

local linkCheckbox = linkToggle:CreateFontString(nil, "OVERLAY")
ApplyFont(linkCheckbox)
linkCheckbox:SetPoint("LEFT", 2, 0)

local linkLabel = linkToggle:CreateFontString(nil, "OVERLAY")
ApplyFont(linkLabel)
linkLabel:SetTextColor(unpack(C.text))
linkLabel:SetPoint("LEFT", linkCheckbox, "RIGHT", 4, 0)
linkLabel:SetText("Link Target/Focus")

local function UpdateLinkCheckbox()
    local linked = BL:GetSetting("linkframepos")
    linkCheckbox:SetText(linked and "|cff8D77A3[x]|r" or "|cff666666[ ]|r")
end

linkToggle:SetScript("OnEnter", function()
    linkLabel:SetTextColor(1, 1, 1, 1)
end)
linkToggle:SetScript("OnLeave", function()
    linkLabel:SetTextColor(unpack(C.text))
end)

-- Forward declarations
local UpdateSliders, UpdatePanelLayout
local sliderX, sliderY, xValueBox, yValueBox
local focusSliderX, focusSliderY, focusXValueBox, focusYValueBox
local targetLabel, focusLabel

-- Helper to create a slider row with editable value
local function CreateSliderRow(parent, labelText, yOffset)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(PICKER_WIDTH - 20, 20)
    row:SetPoint("TOP", parent, "TOP", 0, yOffset)

    -- Label
    local label = row:CreateFontString(nil, "OVERLAY")
    ApplyFont(label)
    label:SetTextColor(0.6, 0.6, 0.6, 1)
    label:SetPoint("LEFT", 0, 0)
    label:SetText(labelText)

    -- Editable value box (right side)
    local valueBox = CreateFrame("EditBox", nil, row)
    valueBox:SetSize(40, 16)
    valueBox:SetPoint("RIGHT", 0, 0)
    ApplyFont(valueBox)
    valueBox:SetTextColor(unpack(C.text))
    valueBox:SetJustifyH("RIGHT")
    valueBox:SetAutoFocus(false)
    valueBox:SetNumeric(false)  -- Allow negative sign
    valueBox:SetText("0")

    local valueBoxBg = valueBox:CreateTexture(nil, "BACKGROUND")
    valueBoxBg:SetAllPoints()
    valueBoxBg:SetColorTexture(0.1, 0.1, 0.12, 1)

    -- Slider track
    local track = CreateFrame("Frame", nil, row)
    track:SetSize(90, 8)
    track:SetPoint("LEFT", label, "RIGHT", 8, 0)

    local trackBg = track:CreateTexture(nil, "BACKGROUND")
    trackBg:SetAllPoints()
    trackBg:SetColorTexture(0.1, 0.1, 0.12, 1)

    -- Slider thumb
    local thumb = CreateFrame("Button", nil, track)
    thumb:SetSize(8, 14)
    thumb:SetPoint("CENTER", 0, 0)

    local thumbTex = thumb:CreateTexture(nil, "ARTWORK")
    thumbTex:SetAllPoints()
    thumbTex:SetColorTexture(0.553, 0.467, 0.639, 1)
    thumb.texture = thumbTex

    thumb:SetScript("OnEnter", function(self)
        self.texture:SetColorTexture(0.7, 0.6, 0.8, 1)
    end)
    thumb:SetScript("OnLeave", function(self)
        if not self.dragging then
            self.texture:SetColorTexture(0.553, 0.467, 0.639, 1)
        end
    end)

    -- Drag handling
    thumb:EnableMouse(true)
    thumb:RegisterForDrag("LeftButton")
    thumb.track = track
    thumb.valueBox = valueBox
    thumb.row = row  -- Store reference to the row for repositioning

    thumb:SetScript("OnDragStart", function(self)
        self.dragging = true
    end)

    thumb:SetScript("OnDragStop", function(self)
        self.dragging = false
        if not self:IsMouseOver() then
            self.texture:SetColorTexture(0.553, 0.467, 0.639, 1)
        end
    end)

    thumb:SetScript("OnUpdate", function(self)
        if not self.dragging then return end

        local trackLeft = self.track:GetLeft()
        local trackRight = self.track:GetRight()
        local trackWidth = trackRight - trackLeft
        if trackWidth <= 0 then return end

        local cursorX = GetCursorPosition() / UIParent:GetEffectiveScale()
        local relX = cursorX - trackLeft
        local fraction = math.max(0, math.min(1, relX / trackWidth))
        local value = math.floor(OFFSET_MIN + fraction * (OFFSET_MAX - OFFSET_MIN) + 0.5)

        if self.onValueChanged then
            self.onValueChanged(value)
        end
    end)

    -- Click on track to jump
    track:EnableMouse(true)
    track:SetScript("OnMouseDown", function(self, button)
        if button ~= "LeftButton" then return end
        local trackLeft = self:GetLeft()
        local trackWidth = self:GetWidth()
        if trackWidth <= 0 then return end

        local cursorX = GetCursorPosition() / UIParent:GetEffectiveScale()
        local relX = cursorX - trackLeft
        local fraction = math.max(0, math.min(1, relX / trackWidth))
        local value = math.floor(OFFSET_MIN + fraction * (OFFSET_MAX - OFFSET_MIN) + 0.5)

        if thumb.onValueChanged then
            thumb.onValueChanged(value)
        end
    end)

    -- Value box handlers
    valueBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    valueBox:SetScript("OnEnterPressed", function(self)
        local text = self:GetText()
        local value = tonumber(text)
        if value and thumb.onValueChanged then
            thumb.onValueChanged(math.floor(value))
        end
        self:ClearFocus()
    end)

    return thumb, valueBox, track
end

-- "Target:" label (only shown when unlinked, positioned by UpdatePanelLayout)
targetLabel = positionPickerPanel:CreateFontString(nil, "OVERLAY")
ApplyFont(targetLabel)
targetLabel:SetTextColor(0.553, 0.467, 0.639, 1)  -- Purple like menubar
targetLabel:SetText("Target")
targetLabel:Hide()

-- Create Target X/Y sliders (positioned by UpdatePanelLayout)
sliderX, xValueBox = CreateSliderRow(positionPickerPanel, "X:", -28)
sliderY, yValueBox = CreateSliderRow(positionPickerPanel, "Y:", -53)

-- "Focus:" label (only shown when unlinked, positioned by UpdatePanelLayout)
focusLabel = positionPickerPanel:CreateFontString(nil, "OVERLAY")
ApplyFont(focusLabel)
focusLabel:SetTextColor(0.4, 0.8, 1, 1)  -- Cyan
focusLabel:SetText("Focus")
focusLabel:Hide()

-- Create Focus X/Y sliders (initially hidden, positioned by UpdatePanelLayout)
focusSliderX, focusXValueBox = CreateSliderRow(positionPickerPanel, "X:", -108)
focusSliderY, focusYValueBox = CreateSliderRow(positionPickerPanel, "Y:", -131)
-- Hide focus rows initially (will be shown by UpdatePanelLayout if unlinked)
focusSliderX.row:Hide()
focusSliderY.row:Hide()

-- Store references for the hide checker
positionPickerPanel.sliderX = sliderX
positionPickerPanel.sliderY = sliderY
positionPickerPanel.focusSliderX = focusSliderX
positionPickerPanel.focusSliderY = focusSliderY

-- Position thumb based on value (clamped to slider range for display)
local function SetThumbPosition(thumb, track, value)
    local fraction = (value - OFFSET_MIN) / (OFFSET_MAX - OFFSET_MIN)
    local trackWidth = track:GetWidth()
    local offset = fraction * trackWidth - trackWidth / 2
    thumb:ClearAllPoints()
    thumb:SetPoint("CENTER", track, "CENTER", offset, 0)
end

-- Update slider positions and value boxes
UpdateSliders = function()
    local targetPos = BL:GetSetting("targetframepos") or {x = 4, y = 0}
    local focusPos = BL:GetSetting("focusframepos") or {x = 4, y = 0}

    -- Clamp for thumb position display (values outside range still work)
    local clampedX = math.max(OFFSET_MIN, math.min(OFFSET_MAX, targetPos.x))
    local clampedY = math.max(OFFSET_MIN, math.min(OFFSET_MAX, targetPos.y))

    SetThumbPosition(sliderX, sliderX.track, clampedX)
    SetThumbPosition(sliderY, sliderY.track, clampedY)
    xValueBox:SetText(tostring(math.floor(targetPos.x)))
    yValueBox:SetText(tostring(math.floor(targetPos.y)))

    -- Update focus sliders
    local clampedFocusX = math.max(OFFSET_MIN, math.min(OFFSET_MAX, focusPos.x))
    local clampedFocusY = math.max(OFFSET_MIN, math.min(OFFSET_MAX, focusPos.y))

    SetThumbPosition(focusSliderX, focusSliderX.track, clampedFocusX)
    SetThumbPosition(focusSliderY, focusSliderY.track, clampedFocusY)
    focusXValueBox:SetText(tostring(math.floor(focusPos.x)))
    focusYValueBox:SetText(tostring(math.floor(focusPos.y)))
end

-- Show/hide focus sliders and resize panel based on link setting
UpdatePanelLayout = function()
    local linked = BL:GetSetting("linkframepos")
    if linked then
        -- Linked: simple layout, no labels
        targetLabel:Hide()
        focusLabel:Hide()
        focusSliderX.row:Hide()
        focusSliderY.row:Hide()
        positionPickerPanel:SetHeight(PICKER_HEIGHT_LINKED)

        -- Position target sliders (no labels)
        sliderX.row:ClearAllPoints()
        sliderX.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -28)
        sliderY.row:ClearAllPoints()
        sliderY.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -53)
    else
        -- Unlinked: show labels and focus sliders
        targetLabel:Show()
        focusLabel:Show()
        focusSliderX.row:Show()
        focusSliderY.row:Show()
        positionPickerPanel:SetHeight(PICKER_HEIGHT_UNLINKED)

        -- Position target label and sliders
        targetLabel:ClearAllPoints()
        targetLabel:SetPoint("TOPLEFT", positionPickerPanel, "TOPLEFT", 10, -28)
        sliderX.row:ClearAllPoints()
        sliderX.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -44)
        sliderY.row:ClearAllPoints()
        sliderY.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -67)

        -- Position focus label and sliders
        focusLabel:ClearAllPoints()
        focusLabel:SetPoint("TOPLEFT", positionPickerPanel, "TOPLEFT", 10, -92)
        focusSliderX.row:ClearAllPoints()
        focusSliderX.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -108)
        focusSliderY.row:ClearAllPoints()
        focusSliderY.row:SetPoint("TOP", positionPickerPanel, "TOP", 0, -131)
    end
end

-- Slider value change handlers
sliderX.onValueChanged = function(value)
    local linked = BL:GetSetting("linkframepos")
    local pos = BL:GetSetting("targetframepos") or {x = 4, y = 0}
    pos.x = value
    BL:SetSetting("targetframepos", pos)
    if linked then
        BL:SetSetting("focusframepos", {x = pos.x, y = pos.y})
    end
    UpdateSliders()
    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end

sliderY.onValueChanged = function(value)
    local linked = BL:GetSetting("linkframepos")
    local pos = BL:GetSetting("targetframepos") or {x = 4, y = 0}
    pos.y = value
    BL:SetSetting("targetframepos", pos)
    if linked then
        BL:SetSetting("focusframepos", {x = pos.x, y = pos.y})
    end
    UpdateSliders()
    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end

-- Focus slider value change handlers
focusSliderX.onValueChanged = function(value)
    local pos = BL:GetSetting("focusframepos") or {x = 4, y = 0}
    pos.x = value
    BL:SetSetting("focusframepos", pos)
    UpdateSliders()
    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end

focusSliderY.onValueChanged = function(value)
    local pos = BL:GetSetting("focusframepos") or {x = 4, y = 0}
    pos.y = value
    BL:SetSetting("focusframepos", pos)
    UpdateSliders()
    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end

-- Reset button
local resetBtn = CreateFrame("Button", nil, positionPickerPanel)
resetBtn:SetSize(50, 16)
resetBtn:SetPoint("BOTTOM", 0, 8)

local resetBtnBg = resetBtn:CreateTexture(nil, "BACKGROUND")
resetBtnBg:SetAllPoints()
resetBtnBg:SetColorTexture(0.2, 0.2, 0.22, 1)

local resetBtnText = resetBtn:CreateFontString(nil, "OVERLAY")
ApplyFont(resetBtnText, FONT_SIZE - 1)
resetBtnText:SetTextColor(0.7, 0.7, 0.7, 1)
resetBtnText:SetPoint("CENTER", 0, 0)
resetBtnText:SetText("Reset")

resetBtn:SetScript("OnEnter", function()
    resetBtnBg:SetColorTexture(0.3, 0.3, 0.35, 1)
    resetBtnText:SetTextColor(1, 1, 1, 1)
end)
resetBtn:SetScript("OnLeave", function()
    resetBtnBg:SetColorTexture(0.2, 0.2, 0.22, 1)
    resetBtnText:SetTextColor(0.7, 0.7, 0.7, 1)
end)
resetBtn:SetScript("OnClick", function()
    BL:SetSetting("targetframepos", {x = 4, y = 0})
    BL:SetSetting("focusframepos", {x = 4, y = 0})
    UpdateSliders()
    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end)

-- Link toggle click handler
linkToggle:SetScript("OnClick", function()
    local wasLinked = BL:GetSetting("linkframepos")
    BL:SetSetting("linkframepos", not wasLinked)
    UpdateLinkCheckbox()
    UpdatePanelLayout()

    if not wasLinked then
        -- Relinking: copy target position to focus
        local targetPos = BL:GetSetting("targetframepos") or {x = 4, y = 0}
        BL:SetSetting("focusframepos", {x = targetPos.x, y = targetPos.y})
        UpdateSliders()
    end

    if BL.RefreshNotePositions then
        BL:RefreshNotePositions()
    end
end)

-- Update panel when shown
positionPickerPanel:SetScript("OnShow", function()
    UpdateLinkCheckbox()
    UpdatePanelLayout()
    UpdateSliders()
end)

-- Hide panel when clicking outside
local pickerHideChecker = CreateFrame("Frame")
pickerHideChecker:SetScript("OnUpdate", function()
    if not positionPickerPanel:IsShown() then return end
    if not IsMouseButtonDown("LeftButton") then return end

    -- Check if any slider is being dragged
    if sliderX.dragging or sliderY.dragging then return end
    if focusSliderX.dragging or focusSliderY.dragging then return end

    -- Check if mouse is over the panel, dropdown, or title button
    if not positionPickerPanel:IsMouseOver()
       and not settingsDropdown:IsMouseOver()
       and not titleBtn:IsMouseOver() then
        positionPickerPanel:Hide()
    end
end)

-- Also hide submenus when dropdown hides
local origHideSettingsDropdown = HideSettingsDropdown
HideSettingsDropdown = function()
    HideAllSubmenus()
    origHideSettingsDropdown()
end

-- Close button (x) top-right
local closeBtn = CreateFrame("Button", nil, menubar)
closeBtn:SetSize(MENUBAR_HEIGHT, MENUBAR_HEIGHT)
closeBtn:SetPoint("TOPRIGHT", 0, 0)

local closeBg = closeBtn:CreateTexture(nil, "BACKGROUND")
closeBg:SetAllPoints()
closeBg:SetColorTexture(0, 0, 0, 0)

local closeText = closeBtn:CreateFontString(nil, "OVERLAY")
closeText:SetPoint("CENTER", 0, 0)
ApplyFont(closeText)
closeText:SetText("|cff666666x|r")

closeBtn:SetScript("OnEnter", function()
    closeBg:SetColorTexture(0.5, 0.2, 0.2, 0.8)
    closeText:SetText("|cffff6666x|r")
end)
closeBtn:SetScript("OnLeave", function()
    closeBg:SetColorTexture(0, 0, 0, 0)
    closeText:SetText("|cff666666x|r")
end)
closeBtn:SetScript("OnClick", function() frame:Hide() end)

--------------------------------------------------------------
-- Search bar (initially hidden, below menubar)
--------------------------------------------------------------
local SEARCHBAR_HEIGHT = MENUBAR_HEIGHT

local searchBar = CreateFrame("Frame", nil, frame)
searchBar:SetPoint("TOPLEFT", 0, -MENUBAR_HEIGHT)
searchBar:SetPoint("TOPRIGHT", 0, -MENUBAR_HEIGHT)
searchBar:SetHeight(SEARCHBAR_HEIGHT)
searchBar:Hide()

local searchBarBg = searchBar:CreateTexture(nil, "BACKGROUND")
searchBarBg:SetAllPoints()
searchBarBg:SetColorTexture(unpack(C.searchBg))

-- "Find:" label
local searchLabel = searchBar:CreateFontString(nil, "OVERLAY")
ApplyFont(searchLabel)
searchLabel:SetTextColor(0.6, 0.6, 0.6, 1)
searchLabel:SetPoint("LEFT", 8, 0)
searchLabel:SetText("Find:")

-- Search input box
local searchBox = CreateFrame("EditBox", nil, searchBar)
searchBox:SetAutoFocus(false)
ApplyFont(searchBox)
searchBox:SetTextColor(unpack(C.text))
searchBox:SetPoint("LEFT", searchLabel, "RIGHT", 4, 0)
searchBox:SetSize(150, SEARCHBAR_HEIGHT)
searchBox:SetTextInsets(4, 4, 0, 0)

local searchBoxBg = searchBox:CreateTexture(nil, "BACKGROUND")
searchBoxBg:SetAllPoints()
searchBoxBg:SetColorTexture(0.15, 0.16, 0.18, 1)

-- Match count text
local matchCountText = searchBar:CreateFontString(nil, "OVERLAY")
ApplyFont(matchCountText)
matchCountText:SetTextColor(0.6, 0.6, 0.6, 1)
matchCountText:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
matchCountText:SetText("")

-- Previous match button
local prevBtn = CreateFrame("Button", nil, searchBar)
prevBtn:SetSize(16, SEARCHBAR_HEIGHT)
prevBtn:SetPoint("LEFT", matchCountText, "RIGHT", 6, 0)

local prevBtnText = prevBtn:CreateFontString(nil, "OVERLAY")
ApplyFont(prevBtnText)
prevBtnText:SetPoint("CENTER", 0, 0)
prevBtnText:SetText("|cff888888<|r")

prevBtn:SetScript("OnEnter", function() prevBtnText:SetText("|cffcccccc<|r") end)
prevBtn:SetScript("OnLeave", function() prevBtnText:SetText("|cff888888<|r") end)

-- Next match button
local nextBtn = CreateFrame("Button", nil, searchBar)
nextBtn:SetSize(16, SEARCHBAR_HEIGHT)
nextBtn:SetPoint("LEFT", prevBtn, "RIGHT", 2, 0)

local nextBtnText = nextBtn:CreateFontString(nil, "OVERLAY")
ApplyFont(nextBtnText)
nextBtnText:SetPoint("CENTER", 0, 0)
nextBtnText:SetText("|cff888888>|r")

nextBtn:SetScript("OnEnter", function() nextBtnText:SetText("|cffcccccc>|r") end)
nextBtn:SetScript("OnLeave", function() nextBtnText:SetText("|cff888888>|r") end)

-- Close search button (X)
local closeSearchBtn = CreateFrame("Button", nil, searchBar)
closeSearchBtn:SetSize(SEARCHBAR_HEIGHT, SEARCHBAR_HEIGHT)
closeSearchBtn:SetPoint("TOPRIGHT", 0, 0)

local closeSearchBg = closeSearchBtn:CreateTexture(nil, "BACKGROUND")
closeSearchBg:SetAllPoints()
closeSearchBg:SetColorTexture(0, 0, 0, 0)

local closeSearchText = closeSearchBtn:CreateFontString(nil, "OVERLAY")
closeSearchText:SetPoint("CENTER", 0, 0)
ApplyFont(closeSearchText)
closeSearchText:SetText("|cff666666x|r")

closeSearchBtn:SetScript("OnEnter", function()
    closeSearchBg:SetColorTexture(0.3, 0.2, 0.2, 0.8)
    closeSearchText:SetText("|cffff6666x|r")
end)
closeSearchBtn:SetScript("OnLeave", function()
    closeSearchBg:SetColorTexture(0, 0, 0, 0)
    closeSearchText:SetText("|cff666666x|r")
end)

-- Search bar border (bottom)
local searchBarBorder = searchBar:CreateTexture(nil, "OVERLAY")
searchBarBorder:SetPoint("BOTTOMLEFT", 0, 0)
searchBarBorder:SetPoint("BOTTOMRIGHT", 0, 0)
searchBarBorder:SetHeight(1)
searchBarBorder:SetColorTexture(unpack(C.border))

--------------------------------------------------------------
-- Editor area
--------------------------------------------------------------
local editorArea = CreateFrame("Frame", nil, frame)
editorArea:SetPoint("TOPLEFT", 0, -MENUBAR_HEIGHT)
editorArea:SetPoint("BOTTOMRIGHT", 0, STATUSBAR_HEIGHT)
editorArea:EnableMouse(true)
editorArea:RegisterForDrag("MiddleButton")
editorArea:SetScript("OnDragStart", function() frame:StartMoving() end)
editorArea:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)

-- Gutter (line numbers)
local gutter = CreateFrame("Frame", nil, editorArea)
gutter:SetPoint("TOPLEFT", 0, 0)
gutter:SetPoint("BOTTOMLEFT", 0, 0)
gutter:SetWidth(GUTTER_WIDTH)
gutter:EnableMouse(true)
gutter:RegisterForDrag("MiddleButton")
gutter:SetScript("OnDragStart", function() frame:StartMoving() end)
gutter:SetScript("OnDragStop", function() frame:StopMovingOrSizing() end)

local gutterBg = gutter:CreateTexture(nil, "BACKGROUND")
gutterBg:SetAllPoints()
gutterBg:SetColorTexture(0.06, 0.07, 0.08, 1)

local gutterBorder = gutter:CreateTexture(nil, "OVERLAY")
gutterBorder:SetPoint("TOPRIGHT", 0, 0)
gutterBorder:SetPoint("BOTTOMRIGHT", 0, 0)
gutterBorder:SetWidth(1)
gutterBorder:SetColorTexture(unpack(C.border))

gutter:SetClipsChildren(true)
local gutterContent = CreateFrame("Frame", nil, gutter)
gutterContent:SetPoint("TOPLEFT", 0, 0)
gutterContent:SetWidth(GUTTER_WIDTH)
gutterContent:SetHeight(1) -- resized dynamically

local gutterLines = {}
local function GetGutterLine(index)
    if not gutterLines[index] then
        local fs = gutterContent:CreateFontString(nil, "OVERLAY")
        ApplyFont(fs)
        fs:SetJustifyH("RIGHT")
        fs:SetTextColor(0.45, 0.45, 0.45, 1)
        gutterLines[index] = fs
    end
    return gutterLines[index]
end

-- Scroll frame (right of gutter)
local scrollFrame = CreateFrame("ScrollFrame", nil, editorArea)
scrollFrame:SetPoint("TOPLEFT", GUTTER_WIDTH, 0)
scrollFrame:SetPoint("BOTTOMRIGHT", -SCROLLBAR_WIDTH, 0)

-- Multiline EditBox as scroll child
local editBox = CreateFrame("EditBox", "BlacklistEditBox", scrollFrame)
editBox:SetMultiLine(true)
editBox:SetAutoFocus(false)
ApplyFont(editBox)
editBox:SetTextColor(0, 0, 0, 0)
editBox:SetTextInsets(6, 4, 0, 0)
editBox:SetWidth(WIN_W - SCROLLBAR_WIDTH - GUTTER_WIDTH)

local function ResizeGutter(lineCount)
    local newWidth = ComputeGutterWidth(lineCount)
    if newWidth == GUTTER_WIDTH then return end
    GUTTER_WIDTH = newWidth
    gutter:SetWidth(GUTTER_WIDTH)
    gutterContent:SetWidth(GUTTER_WIDTH)
    if BL:GetSetting("gutter") then
        scrollFrame:SetPoint("TOPLEFT", GUTTER_WIDTH, 0)
    end
    editBox:SetWidth(scrollFrame:GetWidth())
end

local function UpdateGutterVisibility()
    local showGutter = BL:GetSetting("gutter")
    if showGutter then
        gutter:Show()
        scrollFrame:SetPoint("TOPLEFT", GUTTER_WIDTH, 0)
    else
        gutter:Hide()
        scrollFrame:SetPoint("TOPLEFT", 0, 0)
    end
    editBox:SetWidth(scrollFrame:GetWidth())
end

function BL:RefreshGutter()
    UpdateGutterVisibility()
end

editBox:SetScript("OnEscapePressed", function(self)
    -- Close search bar first if active, otherwise close window
    if searchState.active then
        HideSearchBar()
    else
        self:ClearFocus()
        frame:Hide()
    end
end)
scrollFrame:SetScrollChild(editBox)

editorArea:SetScript("OnMouseDown", function(self, button)
    -- Middle-click drag is handled by OnDragStart
    if button ~= "LeftButton" then return end

    editBox:SetFocus()
    local lineHeight = measuredLineHeight or FONT_SIZE
    local cursorY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
    local editTop = editBox:GetTop() - scrollFrame:GetVerticalScroll()
    local clickOffset = editTop - cursorY
    local lineIndex = math.floor(clickOffset / lineHeight) + 1

    local text = editBox:GetText() or ""
    local pos = 0
    local i = 0
    for line in (text .. "\n"):gmatch("(.-)\n") do
        i = i + 1
        if i == lineIndex then
            editBox:SetCursorPosition(pos + #line)
            return
        end
        pos = pos + #line + 1
    end
    editBox:SetCursorPosition(#text)
end)

--------------------------------------------------------------
-- Colored overlay (FontStrings drawn over invisible editBox text)
--------------------------------------------------------------
local overlayClip = CreateFrame("Frame", nil, editorArea)
overlayClip:SetClipsChildren(true)
overlayClip:SetAllPoints(scrollFrame)
overlayClip:SetFrameLevel(editBox:GetFrameLevel() + 1)
overlayClip:EnableMouse(false)

local overlayFrame = CreateFrame("Frame", nil, overlayClip)
overlayFrame:SetAllPoints(editBox)
overlayFrame:SetFrameLevel(editBox:GetFrameLevel() + 1)
overlayFrame:EnableMouse(false)

-- Current line highlight (clipped to editor area, spans full width including gutter)
local lineHlClip = CreateFrame("Frame", nil, editorArea)
lineHlClip:SetClipsChildren(true)
lineHlClip:SetAllPoints(editorArea)
lineHlClip:SetFrameLevel(editBox:GetFrameLevel())
lineHlClip:EnableMouse(false)
local lineHighlight = lineHlClip:CreateTexture(nil, "BACKGROUND", nil, 1)
lineHighlight:SetColorTexture(1, 1, 1, 0.12)
lineHighlight:Hide()
local lastCursorY = 0
local measuredLineHeight = nil  -- refined from OnCursorChanged

-- Custom blinking cursor (native one is invisible due to transparent text)
local cursorFrame = CreateFrame("Frame", nil, editBox)
cursorFrame:SetFrameLevel(editBox:GetFrameLevel() + 2)
local cursorTex = cursorFrame:CreateTexture(nil, "OVERLAY")
cursorTex:SetColorTexture(unpack(C.text))
cursorTex:SetWidth(1)
cursorTex:SetAllPoints(cursorFrame)
cursorFrame:SetWidth(1)
cursorFrame:Hide()

local cursorBlink = 0
local cursorVisible = false
local BLINK_RATE = 0.5
cursorFrame:SetScript("OnUpdate", function(self, elapsed)
    if not editBox:HasFocus() then
        if cursorVisible then
            cursorVisible = false
            cursorFrame:Hide()
            cursorTex:Hide()
        end
        return
    end
    cursorBlink = cursorBlink + elapsed
    if cursorBlink >= BLINK_RATE then
        cursorBlink = cursorBlink - BLINK_RATE
        cursorTex:SetShown(not cursorTex:IsShown())
    end
end)

local function UpdateCursorPosition(self, x, y, w, h)
    if not editBox:HasFocus() then return end
    -- Refine line height from actual cursor height (most accurate source)
    local minH = FONT_SIZE * 0.5
    local maxH = FONT_SIZE * 2
    if h and h >= minH and h <= maxH then
        measuredLineHeight = h
    end
    local lineH = measuredLineHeight or FONT_SIZE

    cursorFrame:SetHeight(lineH)
    cursorFrame:ClearAllPoints()
    cursorFrame:SetPoint("TOPLEFT", editBox, "TOPLEFT", x + 6, y)
    cursorBlink = 0
    cursorVisible = true
    cursorFrame:Show()
    cursorTex:Show()

    lastCursorY = y
    local visibleY = y + scrollFrame:GetVerticalScroll()
    lineHighlight:SetHeight(lineH)
    lineHighlight:ClearAllPoints()
    lineHighlight:SetPoint("TOPLEFT", editorArea, "TOPLEFT", 0, visibleY)
    lineHighlight:SetPoint("RIGHT", editorArea)
    lineHighlight:Show()
end

editBox:HookScript("OnEditFocusGained", function()
    cursorVisible = true
    cursorFrame:Show()
    cursorTex:Show()
    cursorBlink = 0
end)
editBox:HookScript("OnEditFocusLost", function()
    cursorVisible = false
    cursorFrame:Hide()
    cursorTex:Hide()
    lineHighlight:Hide()
end)

local overlayLines = {} -- pool of FontStrings
local overlayMetaLines = {} -- pool of right-aligned metadata FontStrings
local cachedLines = {} -- split lines cache, rebuilt in OnTextChanged

local function GetOverlayLine(index)
    if not overlayLines[index] then
        local fs = overlayFrame:CreateFontString(nil, "OVERLAY")
        ApplyFont(fs)
        fs:SetJustifyH("LEFT")
        fs:SetWordWrap(false)
        overlayLines[index] = fs
    end
    return overlayLines[index]
end

local function GetOverlayMetaLine(index)
    if not overlayMetaLines[index] then
        local fs = overlayFrame:CreateFontString(nil, "OVERLAY")
        ApplyFont(fs)
        fs:SetJustifyH("RIGHT")
        fs:SetWordWrap(false)
        fs:SetTextColor(0.5, 0.5, 0.5, 0.8)
        overlayMetaLines[index] = fs
    end
    return overlayMetaLines[index]
end

local function UpdateOverlay()
    local lines = cachedLines

    local lineHeight = measuredLineHeight or FONT_SIZE

    ResizeGutter(#lines)
    local insetL = 6 -- matches SetTextInsets left

    -- Calculate visible range (viewport culling) with buffer for smooth scrolling
    local scrollOffset = scrollFrame:GetVerticalScroll()
    local viewHeight = scrollFrame:GetHeight()
    local VIEWPORT_BUFFER = 5
    local firstLine = math.max(1, math.floor(scrollOffset / lineHeight) - VIEWPORT_BUFFER)
    local lastLine = math.min(#lines, math.ceil((scrollOffset + viewHeight) / lineHeight) + VIEWPORT_BUFFER)

    -- Hoist settings reads out of the per-line loop
    local showLevel = BL:GetSetting("editorlevel")
    local showRace = BL:GetSetting("editorrace")
    local showGuild = BL:GetSetting("editorguild")
    local showAdded = BL:GetSetting("editoradded")
    local showLastSeen = BL:GetSetting("editorlastseen")

    for i = firstLine, lastLine do
        local line = lines[i]
        local fs = GetOverlayLine(i)
        local yOff = -((i - 1) * lineHeight)

        -- Determine color — only the name portion gets class color
        local nameToken = BL:ParseLine(line)
        local fullName = nameToken and BL:ResolveNameToken(nameToken)
        local classFile = fullName and BL:GetClass(fullName)
        local color = classFile and RAID_CLASS_COLORS[classFile]
        if color then
            local nameEnd
            local quoted = line:match('^%s*"[^"]+"')
            if quoted then
                nameEnd = #quoted
            else
                local token = line:match("^%s*(%S+)")
                nameEnd = token and #(line:match("^%s*%S+")) or #line
            end
            local namePart = line:sub(1, nameEnd)
            local notePart = line:sub(nameEnd + 1)
            local hex = string.format("|cff%02x%02x%02x", color.r * 255, color.g * 255, color.b * 255)
            fs:SetText(hex .. namePart .. "|r" .. notePart)
            fs:SetTextColor(unpack(C.text))
        else
            fs:SetText(line)
            if fullName then
                fs:SetTextColor(unpack(C.text))
            else
                fs:SetTextColor(C.text[1] * 0.5, C.text[2] * 0.5, C.text[3] * 0.5, 1)
            end
        end

        fs:ClearAllPoints()
        fs:SetPoint("TOPLEFT", editBox, "TOPLEFT", insetL, yOff)
        fs:SetWidth(editBox:GetWidth() - insetL - 4)
        fs:Show()

        -- Right-aligned metadata: [level] Race <Guild> date timeago
        local mfs = GetOverlayMetaLine(i)
        local entry = fullName and BlacklistDB[fullName]
        if entry and ((entry.level and showLevel) or (entry.race and showRace)
            or (entry.guild and showGuild) or (entry.createdAt and showAdded)
            or (entry.lastSeen and showLastSeen)) then
            local parts = {}
            if entry.level and showLevel then
                parts[#parts + 1] = "[" .. entry.level .. "]"
            end
            if entry.race and showRace then
                parts[#parts + 1] = entry.race
            end
            if entry.guild and showGuild then
                parts[#parts + 1] = "<" .. entry.guild .. ">"
            end
            if entry.createdAt and showAdded then
                parts[#parts + 1] = date("%Y-%m-%d", entry.createdAt)
            end
            if entry.lastSeen and showLastSeen then
                parts[#parts + 1] = BL:FormatTimeAgo(entry.lastSeen)
            end
            mfs:SetText(table.concat(parts, " "))
            mfs:ClearAllPoints()
            mfs:SetPoint("TOPRIGHT", editBox, "TOPRIGHT", -4, yOff)
            mfs:Show()
        else
            mfs:Hide()
        end

        -- Line number
        local gfs = GetGutterLine(i)
        gfs:SetText(i)
        gfs:ClearAllPoints()
        gfs:SetPoint("TOPRIGHT", gutterContent, "TOPRIGHT", -6, yOff)
        gfs:Show()
    end

    -- Hide lines outside the visible range
    for i, fs in pairs(overlayLines) do
        if i < firstLine or i > lastLine then fs:Hide() end
    end
    for i, fs in pairs(overlayMetaLines) do
        if i < firstLine or i > lastLine then fs:Hide() end
    end
    for i, fs in pairs(gutterLines) do
        if i < firstLine or i > lastLine then fs:Hide() end
    end

    -- Size gutter content to match editBox
    gutterContent:SetHeight(editBox:GetHeight())
end

function BL:UpdateEditorOverlay()
    UpdateOverlay()
end

-- Custom scrollbar
local scrollbar = CreateFrame("Frame", nil, editorArea)
scrollbar:SetPoint("TOPRIGHT", 0, 0)
scrollbar:SetPoint("BOTTOMRIGHT", 0, 0)
scrollbar:SetWidth(SCROLLBAR_WIDTH)

local scrollbarBg = scrollbar:CreateTexture(nil, "BACKGROUND")
scrollbarBg:SetAllPoints()
scrollbarBg:SetColorTexture(unpack(C.scrollBg))
scrollbarBg:Hide()

local scrollThumb = CreateFrame("Button", nil, scrollbar)
scrollThumb:SetWidth(SCROLLBAR_WIDTH)
scrollThumb:SetHeight(20)
scrollThumb:SetPoint("TOP", scrollbar, "TOP", 0, 0)
scrollThumb:Hide()

local thumbTex = scrollThumb:CreateTexture(nil, "ARTWORK")
thumbTex:SetAllPoints()
thumbTex:SetColorTexture(unpack(C.scrollThumb))
scrollThumb.texture = thumbTex

scrollThumb:SetScript("OnEnter", function(self)
    self.texture:SetColorTexture(unpack(C.scrollHover))
end)
scrollThumb:SetScript("OnLeave", function(self)
    if not self.dragging then
        self.texture:SetColorTexture(unpack(C.scrollThumb))
    end
end)

-- Scroll thumb dragging
scrollThumb:EnableMouse(true)
scrollThumb:RegisterForDrag("LeftButton")
scrollThumb:SetScript("OnDragStart", function(self)
    self.dragging = true
    self.dragStartY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
    self.dragStartScroll = scrollFrame:GetVerticalScroll()
end)
scrollThumb:SetScript("OnDragStop", function(self)
    self.dragging = false
    if not self:IsMouseOver() then
        self.texture:SetColorTexture(unpack(C.scrollThumb))
    end
end)
scrollThumb:SetScript("OnUpdate", function(self)
    if not self.dragging then return end
    local curY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
    local delta = self.dragStartY - curY
    local trackHeight = scrollbar:GetHeight() - self:GetHeight()
    if trackHeight <= 0 then return end
    local maxScroll = editBox:GetHeight() - scrollFrame:GetHeight()
    if maxScroll <= 0 then return end
    local newScroll = self.dragStartScroll + (delta / trackHeight) * maxScroll
    newScroll = math.max(0, math.min(maxScroll, newScroll))
    scrollFrame:SetVerticalScroll(newScroll)
end)

-- Mouse wheel scrolling
scrollFrame:EnableMouseWheel(true)
editorArea:EnableMouseWheel(true)

local function OnMouseWheel(_, delta)
    local maxScroll = math.max(0, editBox:GetHeight() - scrollFrame:GetHeight())
    local current = scrollFrame:GetVerticalScroll()
    local step = FONT_SIZE * 3
    local newScroll = math.max(0, math.min(maxScroll, current - delta * step))
    scrollFrame:SetVerticalScroll(newScroll)
end
scrollFrame:SetScript("OnMouseWheel", OnMouseWheel)
editorArea:SetScript("OnMouseWheel", OnMouseWheel)

-- Update scrollbar thumb position/visibility
local function UpdateScrollbar()
    local contentH = editBox:GetHeight()
    local viewH = scrollFrame:GetHeight()
    if contentH <= viewH or viewH <= 0 then
        scrollbarBg:Hide()
        scrollThumb:Hide()
        return
    end
    scrollbarBg:Show()
    scrollThumb:Show()

    local trackH = scrollbar:GetHeight()
    local ratio = viewH / contentH
    local thumbH = math.max(20, trackH * ratio)
    scrollThumb:SetHeight(thumbH)

    local maxScroll = contentH - viewH
    local scroll = scrollFrame:GetVerticalScroll()
    local frac = (maxScroll > 0) and (scroll / maxScroll) or 0
    local thumbOffset = frac * (trackH - thumbH)
    scrollThumb:ClearAllPoints()
    scrollThumb:SetPoint("TOP", scrollbar, "TOP", 0, -thumbOffset)
end

local function SyncGutterScroll()
    local scroll = scrollFrame:GetVerticalScroll()
    gutterContent:ClearAllPoints()
    gutterContent:SetPoint("TOPLEFT", 0, scroll)
    -- Keep line highlight in sync during scroll
    if lineHighlight:IsShown() then
        local visibleY = lastCursorY + scroll
        lineHighlight:ClearAllPoints()
        lineHighlight:SetPoint("TOPLEFT", editorArea, "TOPLEFT", 0, visibleY)
        lineHighlight:SetPoint("RIGHT", editorArea)
    end
end

scrollFrame:SetScript("OnScrollRangeChanged", function()
    UpdateScrollbar()
    SyncGutterScroll()
    UpdateOverlay()
end)
scrollFrame:SetScript("OnVerticalScroll", function()
    UpdateScrollbar()
    SyncGutterScroll()
    UpdateOverlay()
end)

--------------------------------------------------------------
-- Search functionality
--------------------------------------------------------------

-- Map accented characters to ASCII base (for accent-insensitive search)
-- Covers common WoW name characters (UTF-8 encoded)
local DIACRITIC_MAP = {
    -- Lowercase
    ["à"]="a", ["á"]="a", ["â"]="a", ["ã"]="a", ["ä"]="a", ["å"]="a", ["æ"]="ae",
    ["è"]="e", ["é"]="e", ["ê"]="e", ["ë"]="e",
    ["ì"]="i", ["í"]="i", ["î"]="i", ["ï"]="i",
    ["ò"]="o", ["ó"]="o", ["ô"]="o", ["õ"]="o", ["ö"]="o", ["ø"]="o",
    ["ù"]="u", ["ú"]="u", ["û"]="u", ["ü"]="u",
    ["ñ"]="n", ["ç"]="c", ["ý"]="y", ["ÿ"]="y", ["ß"]="ss",
    -- Uppercase
    ["À"]="a", ["Á"]="a", ["Â"]="a", ["Ã"]="a", ["Ä"]="a", ["Å"]="a", ["Æ"]="ae",
    ["È"]="e", ["É"]="e", ["Ê"]="e", ["Ë"]="e",
    ["Ì"]="i", ["Í"]="i", ["Î"]="i", ["Ï"]="i",
    ["Ò"]="o", ["Ó"]="o", ["Ô"]="o", ["Õ"]="o", ["Ö"]="o", ["Ø"]="o",
    ["Ù"]="u", ["Ú"]="u", ["Û"]="u", ["Ü"]="u",
    ["Ñ"]="n", ["Ç"]="c", ["Ý"]="y", ["Ÿ"]="y",
}

-- Normalize string for searching, returns normalized string and position map
-- posMap[i] = original byte position for normalized character i
local function NormalizeForSearch(str)
    local result = {}
    local posMap = {}
    local i = 1
    local len = #str

    while i <= len do
        local b = str:byte(i)
        local char, charLen

        -- Determine UTF-8 character length
        if b < 128 then
            charLen = 1
            char = str:sub(i, i)
        elseif b < 224 then
            charLen = 2
            char = str:sub(i, i + 1)
        elseif b < 240 then
            charLen = 3
            char = str:sub(i, i + 2)
        else
            charLen = 4
            char = str:sub(i, i + 3)
        end

        -- Normalize the character
        local normalized = DIACRITIC_MAP[char] or char:lower()

        -- Add each byte of normalized result with original position
        for j = 1, #normalized do
            result[#result + 1] = normalized:sub(j, j)
            posMap[#posMap + 1] = i
        end

        i = i + charLen
    end

    return table.concat(result), posMap
end

local function ClearMatchHighlights()
    for _, tex in ipairs(matchHighlights) do
        tex:Hide()
    end
end

local function GetMatchHighlight(index)
    if not matchHighlights[index] then
        local tex = overlayFrame:CreateTexture(nil, "BACKGROUND", nil, 2)
        matchHighlights[index] = tex
    end
    return matchHighlights[index]
end

local function FindAllMatches(text, query)
    searchState.matches = {}
    if not query or #query == 0 then return end

    -- Normalize both text and query for accent-insensitive search
    local normText, posMap = NormalizeForSearch(text)
    local normQuery = NormalizeForSearch(query)

    -- Build line positions in original text (byte positions)
    local linePositions = {{start = 1, lineNum = 1}}
    local lineNum = 1
    for i = 1, #text do
        if text:sub(i, i) == "\n" then
            lineNum = lineNum + 1
            linePositions[#linePositions + 1] = {start = i + 1, lineNum = lineNum}
        end
    end

    -- Also build a map of original byte position to visual column
    -- (accounts for multi-byte UTF-8 characters)
    local byteToCol = {}
    local col = 1
    local i = 1
    while i <= #text do
        byteToCol[i] = col
        local b = text:byte(i)
        local charLen = 1
        if b >= 128 then
            if b < 224 then charLen = 2
            elseif b < 240 then charLen = 3
            else charLen = 4 end
        end
        -- Mark all bytes of this character with same column
        for j = i + 1, i + charLen - 1 do
            byteToCol[j] = col
        end
        if text:sub(i, i) ~= "\n" then
            col = col + 1
        else
            col = 1
        end
        i = i + charLen
    end
    byteToCol[#text + 1] = col  -- for end position

    -- Find all matches in normalized text
    local searchPos = 1
    while true do
        local matchStart, matchEnd = normText:find(normQuery, searchPos, true)
        if not matchStart then break end

        -- Map normalized positions back to original byte positions
        local origStart = posMap[matchStart]
        local origEnd = posMap[matchEnd]
        -- Find the end of the last matched character in original
        local b = text:byte(origEnd) or 0
        local charLen = 1
        if b >= 128 then
            if b < 224 then charLen = 2
            elseif b < 240 then charLen = 3
            else charLen = 4 end
        end
        origEnd = origEnd + charLen - 1

        -- Find which line this match is on (using original positions)
        local matchLine = 1
        local matchLineStart = 1
        for _, lp in ipairs(linePositions) do
            if lp.start <= origStart then
                matchLine = lp.lineNum
                matchLineStart = lp.start
            else
                break
            end
        end

        -- Calculate visual columns (character-based, not byte-based)
        local startCol = byteToCol[origStart] or 1
        local endCol = byteToCol[origEnd] or startCol

        searchState.matches[#searchState.matches + 1] = {
            line = matchLine,
            startCol = startCol,
            endCol = endCol,
            startPos = origStart,
            endPos = origEnd,
        }

        searchPos = matchStart + 1
    end
end

local function UpdateMatchCountDisplay()
    if not searchState.active then
        matchCountText:SetText("")
        return
    end

    local total = #searchState.matches
    if total == 0 then
        if searchState.query and #searchState.query > 0 then
            matchCountText:SetText("No matches")
        else
            matchCountText:SetText("")
        end
    else
        matchCountText:SetText(searchState.currentIndex .. " of " .. total)
    end
end

local function UpdateMatchHighlights()
    ClearMatchHighlights()
    if not searchState.active or #searchState.matches == 0 then return end

    local lineHeight = measuredLineHeight or FONT_SIZE
    local insetL = 6

    -- Calculate visible line range for viewport culling with buffer
    local scrollOffset = scrollFrame:GetVerticalScroll()
    local viewHeight = scrollFrame:GetHeight()
    local VIEWPORT_BUFFER = 5
    local firstVisLine = math.max(1, math.floor(scrollOffset / lineHeight) - VIEWPORT_BUFFER)
    local lastVisLine = math.ceil((scrollOffset + viewHeight) / lineHeight) + VIEWPORT_BUFFER

    for i, match in ipairs(searchState.matches) do
        local tex = GetMatchHighlight(i)

        if match.line >= firstVisLine and match.line <= lastVisLine then
            -- Calculate position
            local yOff = -((match.line - 1) * lineHeight)
            local xOff = insetL + (match.startCol - 1) * CHAR_WIDTH
            local width = (match.endCol - match.startCol + 1) * CHAR_WIDTH

            tex:ClearAllPoints()
            tex:SetPoint("TOPLEFT", editBox, "TOPLEFT", xOff, yOff)
            tex:SetSize(width, lineHeight)

            -- Highlight current match brighter
            if i == searchState.currentIndex then
                tex:SetColorTexture(unpack(C.currentMatch))
            else
                tex:SetColorTexture(unpack(C.matchHighlight))
            end
            tex:Show()
        else
            tex:Hide()
        end
    end
end

local function JumpToMatch(index)
    if #searchState.matches == 0 then return end

    -- Clamp and wrap
    if index < 1 then
        index = #searchState.matches
    elseif index > #searchState.matches then
        index = 1
    end

    searchState.currentIndex = index
    local match = searchState.matches[index]

    -- Move cursor to match position
    editBox:SetCursorPosition(match.startPos - 1)
    editBox:SetFocus()

    -- Scroll to make match visible
    local lineHeight = measuredLineHeight or FONT_SIZE
    local matchTop = (match.line - 1) * lineHeight
    local matchBot = matchTop + lineHeight
    local viewH = scrollFrame:GetHeight()
    local scroll = scrollFrame:GetVerticalScroll()
    local maxScroll = math.max(0, editBox:GetHeight() - viewH)

    -- Center the match in view if possible
    local targetScroll = matchTop - (viewH / 2) + (lineHeight / 2)
    targetScroll = math.max(0, math.min(maxScroll, targetScroll))
    scrollFrame:SetVerticalScroll(targetScroll)

    UpdateMatchHighlights()
    UpdateMatchCountDisplay()
end

local function NextMatch()
    JumpToMatch(searchState.currentIndex + 1)
end

local function PrevMatch()
    JumpToMatch(searchState.currentIndex - 1)
end

RunSearch = function()
    local query = searchBox:GetText() or ""
    searchState.query = query
    FindAllMatches(editBox:GetText() or "", query)

    -- Reset to first match if we have matches
    if #searchState.matches > 0 then
        searchState.currentIndex = 1
    else
        searchState.currentIndex = 0
    end

    UpdateMatchHighlights()
    UpdateMatchCountDisplay()
end

ShowSearchBar = function()
    if searchState.active then
        searchBox:SetFocus()
        searchBox:HighlightText()
        return
    end

    searchState.savedCursor = editBox:GetCursorPosition()
    searchState.active = true
    searchBar:Show()

    -- Adjust editor area to make room for search bar
    editorArea:SetPoint("TOPLEFT", 0, -(MENUBAR_HEIGHT + SEARCHBAR_HEIGHT))

    searchBox:SetText("")
    searchBox:SetFocus()

    ClearMatchHighlights()
    searchState.matches = {}
    searchState.currentIndex = 0
    UpdateMatchCountDisplay()
end

HideSearchBar = function()
    if not searchState.active then return end

    -- Determine where cursor should end up:
    -- 1. If user clicked into editor, keep their cursor position
    -- 2. If on a search match, go to match position
    -- 3. Otherwise restore to where cursor was before search opened
    local editorHasFocus = editBox:HasFocus()
    local restoreCursor
    if editorHasFocus then
        restoreCursor = nil  -- already where user wants
    elseif searchState.currentIndex > 0 and searchState.matches[searchState.currentIndex] then
        restoreCursor = searchState.matches[searchState.currentIndex].startPos - 1
    else
        restoreCursor = searchState.savedCursor
    end

    searchState.active = false
    searchBar:Hide()

    -- Restore editor area position
    editorArea:SetPoint("TOPLEFT", 0, -MENUBAR_HEIGHT)

    ClearMatchHighlights()
    searchState.matches = {}
    searchState.currentIndex = 0
    searchState.query = ""
    matchCountText:SetText("")

    C_Timer.After(0, function()
        editBox:SetFocus()
        if restoreCursor then
            editBox:SetCursorPosition(restoreCursor)
        end
    end)
end

-- Wire up search bar buttons
closeSearchBtn:SetScript("OnClick", HideSearchBar)
prevBtn:SetScript("OnClick", PrevMatch)
nextBtn:SetScript("OnClick", NextMatch)

-- Search box handlers
searchBox:SetScript("OnTextChanged", function(self, userInput)
    if userInput then
        RunSearch()
    end
end)

searchBox:SetScript("OnKeyDown", function(self, key)
    if not InCombatLockdown() then
        self:SetPropagateKeyboardInput(false)
    end

    if key == "ESCAPE" then
        HideSearchBar()
    elseif key == "ENTER" then
        if IsShiftKeyDown() then
            PrevMatch()
        else
            NextMatch()
        end
    elseif key == "F" and IsControlKeyDown() then
        HideSearchBar()
    end
end)

searchBox:SetScript("OnEscapePressed", function()
    HideSearchBar()
end)

-- Editor dirty flag (declared here so Undo/Redo can access it)
local editorDirty = false

-- Undo/redo stack
local undoStack = {}
local redoStack = {}
local undoInProgress = false
local MAX_UNDO = 50

local function PushUndo(text, cursorPos)
    if #undoStack > 0 and undoStack[#undoStack].text == text then return end
    undoStack[#undoStack + 1] = { text = text, cursor = cursorPos }
    if #undoStack > MAX_UNDO then table.remove(undoStack, 1) end
    redoStack = {}
end

local function Undo()
    if #undoStack < 2 then return end
    local current = table.remove(undoStack)
    redoStack[#redoStack + 1] = current
    local prev = undoStack[#undoStack]
    undoInProgress = true
    editBox:SetText(prev.text)
    editBox:SetCursorPosition(prev.cursor or #prev.text)
    undoInProgress = false
    editorDirty = true
    BL:SyncFromEditor(prev.text)
end

local function Redo()
    if #redoStack == 0 then return end
    local entry = table.remove(redoStack)
    undoStack[#undoStack + 1] = entry
    undoInProgress = true
    editBox:SetText(entry.text)
    editBox:SetCursorPosition(entry.cursor or #entry.text)
    undoInProgress = false
    editorDirty = true
    BL:SyncFromEditor(entry.text)
end

--------------------------------------------------------------
-- Keyboard isolation: block game bindings + pre-held key filter
--------------------------------------------------------------
local KEY_TO_CHAR = { SPACE = " " }
local MODIFIER_KEYS = {
    LSHIFT = true, RSHIFT = true,
    LCTRL = true, RCTRL = true,
    LALT = true, RALT = true,
}

local filteringPreHeld = false
local preHeldChars = nil
local suppressTextChanged = false

editBox:HookScript("OnEditFocusGained", function()
    filteringPreHeld = true
    preHeldChars = {}
end)

editBox:HookScript("OnEditFocusLost", function()
    filteringPreHeld = false
    preHeldChars = nil
end)

-- Flag to suppress next character insertion after handling a keybind
local suppressNextChar = false

-- Helper: build WoW-style key combo string from current modifiers + key
local function BuildKeyCombo(key)
    local combo = ""
    if IsAltKeyDown() then combo = combo .. "ALT-" end
    if IsControlKeyDown() then combo = combo .. "CTRL-" end
    if IsShiftKeyDown() then combo = combo .. "SHIFT-" end
    return combo .. key
end

-- Helper: check if key combo matches any binding for an action
local function MatchesBinding(keyCombo, action)
    local key1, key2 = GetBindingKey(action)
    return (key1 and keyCombo == key1) or (key2 and keyCombo == key2)
end

-- Helper: check if a key won't produce a typable character
local NON_TYPABLE_KEYS = {
    F1=1, F2=1, F3=1, F4=1, F5=1, F6=1, F7=1, F8=1, F9=1, F10=1, F11=1, F12=1,
    INSERT=1, DELETE=1, HOME=1, END=1, PAGEUP=1, PAGEDOWN=1,
    UP=1, DOWN=1, LEFT=1, RIGHT=1, NUMLOCK=1, SCROLLLOCK=1, PAUSE=1,
    NUMPAD0=1, NUMPAD1=1, NUMPAD2=1, NUMPAD3=1, NUMPAD4=1,
    NUMPAD5=1, NUMPAD6=1, NUMPAD7=1, NUMPAD8=1, NUMPAD9=1,
    NUMPADDECIMAL=1, NUMPADDIVIDE=1, NUMPADMULTIPLY=1, NUMPADMINUS=1, NUMPADPLUS=1,
}
local function IsNonTypable(key)
    -- Ctrl or Alt modifier means no character will be typed
    if IsControlKeyDown() or IsAltKeyDown() then return true end
    -- Function keys and special keys
    return NON_TYPABLE_KEYS[key] ~= nil
end

editBox:SetScript("OnKeyDown", function(self, key)
    -- Stop pre-held filtering on first fresh non-modifier key
    if filteringPreHeld and not MODIFIER_KEYS[key] then
        filteringPreHeld = false
        preHeldChars = nil
    end

    local keyCombo = BuildKeyCombo(key)

    -- Escape always closes the frame
    if key == "ESCAPE" then
        frame:Hide()
        return
    end

    -- Toggle keybind always works
    if MatchesBinding(keyCombo, "BLACKLIST_TOGGLE") then
        frame:Hide()
        return
    end

    -- Check for mouseover keybinds before blocking propagation
    -- This allows adding mouseover targets even while typing
    if UnitExists("mouseover") then
        if MatchesBinding(keyCombo, "BLACKLIST_ADD_MOUSEOVER_NOTE") then
            suppressNextChar = true
            Blacklist_AddMouseoverAndNote()
            return
        elseif MatchesBinding(keyCombo, "BLACKLIST_ADD_MOUSEOVER") then
            -- Add without opening editor (matches binding behavior)
            suppressNextChar = true
            local uName, uRealm = UnitName("mouseover")
            local classFile = UnitIsPlayer("mouseover") and select(2, UnitClass("mouseover")) or nil
            if uName then BL:AddPlayer(uName, uRealm, nil, classFile, "keybind", "mouseover") end
            return
        end
    end

    -- For non-typable keys, also check keybinds without mouseover (falls back to target)
    -- Exception: text editing shortcuts and navigation
    local RESERVED_KEYS = { UP=1, DOWN=1, LEFT=1, RIGHT=1, HOME=1, END=1, PAGEUP=1, PAGEDOWN=1 }
    local RESERVED_SHORTCUTS = {
        ["CTRL-F"] = true,  -- search
        ["CTRL-Z"] = true,  -- undo
        ["CTRL-SHIFT-Z"] = true,  -- redo
        ["CTRL-A"] = true,  -- select all
        ["CTRL-C"] = true,  -- copy
        ["CTRL-V"] = true,  -- paste
        ["CTRL-X"] = true,  -- cut
        ["CTRL-U"] = true,  -- delete to start of line
        ["CTRL-K"] = true,  -- delete to end of line
    }
    if IsNonTypable(key) and not RESERVED_KEYS[key] and not RESERVED_SHORTCUTS[keyCombo] then
        if MatchesBinding(keyCombo, "BLACKLIST_ADD_MOUSEOVER_NOTE") then
            Blacklist_AddMouseoverAndNote()
            return
        elseif MatchesBinding(keyCombo, "BLACKLIST_ADD_MOUSEOVER") then
            local unit = "target"
            if UnitExists(unit) then
                local uName, uRealm = UnitName(unit)
                local classFile = UnitIsPlayer(unit) and select(2, UnitClass(unit)) or nil
                if uName then BL:AddPlayer(uName, uRealm, nil, classFile, "keybind", unit) end
            end
            return
        end
    end

    -- Block keys from reaching game bindings
    if not InCombatLockdown() then
        self:SetPropagateKeyboardInput(false)
    end

    if IsControlKeyDown() and key == "Z" then
        if IsShiftKeyDown() then
            Redo()
        else
            Undo()
        end
    elseif IsControlKeyDown() and key == "U" then
        -- Delete from cursor to beginning of current line
        local text = self:GetText()
        local cursorPos = self:GetCursorPosition()
        if cursorPos > 0 then
            local lineStart = cursorPos
            while lineStart > 0 and text:byte(lineStart) ~= 10 do
                lineStart = lineStart - 1
            end
            if lineStart < cursorPos then
                PushUndo(text, cursorPos)
                local before = text:sub(1, lineStart)
                local after = text:sub(cursorPos + 1)
                self:SetText(before .. after)
                self:SetCursorPosition(lineStart)
            end
        end
    elseif IsControlKeyDown() and key == "K" then
        -- Delete from cursor to end of current line
        local text = self:GetText()
        local cursorPos = self:GetCursorPosition()
        local lineEnd = cursorPos + 1
        while lineEnd <= #text and text:byte(lineEnd) ~= 10 do
            lineEnd = lineEnd + 1
        end
        -- lineEnd is now at the \n or past the end of text
        if lineEnd > cursorPos + 1 then
            PushUndo(text, cursorPos)
            local before = text:sub(1, cursorPos)
            local after = text:sub(lineEnd)
            self:SetText(before .. after)
            self:SetCursorPosition(cursorPos)
        end
    elseif IsControlKeyDown() and key == "F" then
        if searchState.active then
            HideSearchBar()
        else
            ShowSearchBar()
        end
    end
end)

editBox:SetScript("OnChar", function(self, char)
    -- Remove character if it was a keybind we handled
    if suppressNextChar then
        suppressNextChar = false
        local text = self:GetText()
        local cursorPos = self:GetCursorPosition()
        local charLen = #char
        if cursorPos > 0 then
            local before = text:sub(1, cursorPos - charLen)
            local after = text:sub(cursorPos + 1)
            suppressTextChanged = true
            self:SetText(before .. after)
            self:SetCursorPosition(cursorPos - charLen)
            suppressTextChanged = false
        end
        return
    end

    if not filteringPreHeld then return end

    local charLower = char:lower()
    preHeldChars[charLower] = true

    -- Remove the character that was just inserted (OnChar fires after insertion)
    local text = self:GetText()
    local cursorPos = self:GetCursorPosition()
    local charLen = #char
    if cursorPos > 0 then
        local before = text:sub(1, cursorPos - charLen)
        local after = text:sub(cursorPos + 1)
        suppressTextChanged = true
        self:SetText(before .. after)
        self:SetCursorPosition(cursorPos - charLen)
        suppressTextChanged = false
    end
end)

editBox:SetScript("OnKeyUp", function(self, key)
    if not filteringPreHeld then return end
    local char = KEY_TO_CHAR[key] or key:lower()
    if preHeldChars and preHeldChars[char] then
        preHeldChars[char] = nil
        if not next(preHeldChars) then
            filteringPreHeld = false
            preHeldChars = nil
        end
    end
end)

-- Keep editBox width in sync and update scrollbar when text changes
editBox:SetScript("OnTextChanged", function(self, userInput)
    -- Always rebuild line cache (even when suppressed)
    local text = self:GetText() or ""
    wipe(cachedLines)
    for line in (text .. "\n"):gmatch("(.-)\n") do
        cachedLines[#cachedLines + 1] = line
    end

    if suppressTextChanged then return end
    self:SetWidth(scrollFrame:GetWidth())
    UpdateScrollbar()
    if userInput and not undoInProgress then
        PushUndo(self:GetText(), self:GetCursorPosition())
        editorDirty = true
        -- Live-sync to DB so nameplate notes update immediately
        BL:SyncFromEditor(self:GetText())
    end
    -- Update line count in status bar
    local text = self:GetText()
    local count = 0
    for line in text:gmatch("[^\n]+") do
        local trimmed = line:match("^%s*(.-)%s*$")
        if trimmed and #trimmed > 0 then
            count = count + 1
        end
    end
    statusText:SetText(count .. " entries")
    UpdateOverlay()

    -- Update search highlights when text changes
    if searchState.active and searchState.query and #searchState.query > 0 then
        RunSearch()
    end
end)

editBox:SetScript("OnCursorChanged", function(self, x, y, w, h)
    UpdateCursorPosition(self, x, y, w, h)
    -- Auto-scroll to keep cursor visible
    local cursorTop = -y
    local lineH = measuredLineHeight or FONT_SIZE
    local cursorBot = cursorTop + lineH
    local viewH = scrollFrame:GetHeight()
    local scroll = scrollFrame:GetVerticalScroll()

    local maxScroll = math.max(0, self:GetHeight() - viewH)
    if cursorTop < scroll then
        scrollFrame:SetVerticalScroll(math.max(0, cursorTop))
    elseif cursorBot > scroll + viewH then
        scrollFrame:SetVerticalScroll(math.min(maxScroll, cursorBot - viewH))
    end
    C_Timer.After(0, UpdateScrollbar)
end)

--------------------------------------------------------------
-- Status bar (bottom)
--------------------------------------------------------------
local statusBar = CreateFrame("Frame", nil, frame)
statusBar:SetHeight(STATUSBAR_HEIGHT)
statusBar:SetPoint("BOTTOMLEFT", 0, 0)
statusBar:SetPoint("BOTTOMRIGHT", 0, 0)

local statusBarBg = statusBar:CreateTexture(nil, "BACKGROUND")
statusBarBg:SetAllPoints()
statusBarBg:SetColorTexture(unpack(C.statusBg))

-- Entry count (left)
statusText = statusBar:CreateFontString(nil, "OVERLAY")
ApplyFont(statusText)
statusText:SetTextColor(unpack(C.statusText))
statusText:SetPoint("LEFT", 6, 0)


--------------------------------------------------------------
-- Resize handle
--------------------------------------------------------------
frame:SetResizable(true)
if frame.SetResizeBounds then
    frame:SetResizeBounds(300, 200, UIParent:GetWidth(), UIParent:GetHeight())
end

local resizeBtn = CreateFrame("Button", nil, frame)
resizeBtn:SetSize(STATUSBAR_HEIGHT, STATUSBAR_HEIGHT)
resizeBtn:SetPoint("BOTTOMRIGHT", 0, 0)
resizeBtn:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
resizeBtn:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
resizeBtn:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
resizeBtn:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
resizeBtn:SetScript("OnMouseUp", function()
    frame:StopMovingOrSizing()
    editBox:SetWidth(scrollFrame:GetWidth())
    UpdateScrollbar()
end)

--------------------------------------------------------------
-- Refresh: populate editBox from BlacklistDB
--------------------------------------------------------------
local function Refresh()
    if not frame:IsShown() then return end
    editBox:SetWidth(scrollFrame:GetWidth())

    local sorted = {}
    for fullName in pairs(BlacklistDB or {}) do
        sorted[#sorted + 1] = fullName
    end
    table.sort(sorted)

    local lines = {}
    for _, fullName in ipairs(sorted) do
        local info = BlacklistDB[fullName]
        local displayName = BL:FormatDisplayName(fullName)
        if info and info.alert then
            displayName = displayName .. "!"
        end
        if info and info.note and #info.note > 0 then
            lines[#lines + 1] = displayName .. " " .. info.note
        else
            lines[#lines + 1] = displayName
        end
    end
    editBox:SetText(table.concat(lines, "\n"))
    editorDirty = false
    statusText:SetText(#sorted .. " entries")
    C_Timer.After(0, UpdateScrollbar)
end

function BL:RefreshUI()
    if not editorDirty then
        Refresh()
    end
end

function BL:ToggleUI()
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
    end
end

--------------------------------------------------------------
-- Sync editor → DB, then refresh overlays
--------------------------------------------------------------
local function SyncEditorToDB()
    if not editorDirty then return end
    BL:SyncFromEditor(editBox:GetText())
    editorDirty = false
end

--------------------------------------------------------------
-- Provide editor text getter for Core.lua logout sync
--------------------------------------------------------------
function BL:GetEditorText()
    if frame and editBox then
        return editBox:GetText(), editorDirty
    end
    return nil, false
end

--------------------------------------------------------------
-- Frame scripts
--------------------------------------------------------------
frame:SetScript("OnShow", function()
    BL:ScanUnitsForMetadata()
    UpdateGutterVisibility()

    -- Preserve order: restore last text, filter removed, append new
    if BlacklistEditorText then
        -- Filter out lines for entries removed from DB
        local keptLines = {}
        local inEditor = {}
        for line in (BlacklistEditorText .. "\n"):gmatch("(.-)\n") do
            local nameToken = BL:ParseLine(line)
            local fullName = nameToken and BL:ResolveNameToken(nameToken)
            if not nameToken then
                keptLines[#keptLines + 1] = line
            elseif fullName and BlacklistDB[fullName] then
                keptLines[#keptLines + 1] = line
                inEditor[fullName] = true
            end
        end

        -- Find DB entries not in editor (added via slash commands)
        local newLines = {}
        for fullName, info in pairs(BlacklistDB or {}) do
            if not inEditor[fullName] then
                local displayName = BL:FormatDisplayName(fullName)
                if info.alert then
                    displayName = displayName .. "!"
                end
                if info.note and #info.note > 0 then
                    newLines[#newLines + 1] = displayName .. " " .. info.note
                else
                    newLines[#newLines + 1] = displayName
                end
            end
        end

        -- Combine kept lines + new entries at bottom
        local text = table.concat(keptLines, "\n")
        if #newLines > 0 then
            if #text > 0 then
                text = text .. "\n" .. table.concat(newLines, "\n")
            else
                text = table.concat(newLines, "\n")
            end
        end
        editBox:SetText(text)
        editBox:SetWidth(scrollFrame:GetWidth())
        editorDirty = false
        local count = 0
        for _ in editBox:GetText():gmatch("[^\n]+") do count = count + 1 end
        statusText:SetText(count .. " entries")
        C_Timer.After(0, UpdateScrollbar)
    else
        -- First open: load from DB
        Refresh()
    end

    -- Restore cursor position (clamped to text length) and focus
    local textLen = #editBox:GetText()
    local pos = BL.lastCursorPos or textLen
    editBox:SetCursorPosition(math.min(pos, textLen))
    editBox:SetFocus()

    undoStack = {}
    redoStack = {}
    PushUndo(editBox:GetText(), 0)
end)

frame:SetScript("OnHide", function()
    SyncEditorToDB()
    BlacklistEditorText = editBox:GetText()
    BL.lastCursorPos = editBox:GetCursorPosition()
    -- Close search bar when window closes
    if searchState.active then
        searchState.active = false
        searchBar:Hide()
        editorArea:SetPoint("TOPLEFT", 0, -MENUBAR_HEIGHT)
        ClearMatchHighlights()
        searchState.matches = {}
        searchState.currentIndex = 0
        searchState.query = ""
    end
end)

frame:SetScript("OnSizeChanged", function()
    C_Timer.After(0, function()
        editBox:SetWidth(scrollFrame:GetWidth())
        UpdateScrollbar()
    end)
end)

--------------------------------------------------------------
-- Target button action
--------------------------------------------------------------
local function AddTargetToEditor()
    if not UnitExists("target") then return end
    local fullName = BL:GetUnitFullName("target")
    if not fullName then return end

    if UnitIsPlayer("target") then
        local classFile = select(2, UnitClass("target"))
        if classFile then
            C_Timer.After(0, function() BL:SetClass(fullName, classFile) end)
        end
    end

    local displayName = BL:FormatDisplayName(fullName)
    local text = editBox:GetText()
    if not text or #text == 0 or text:match("^%s*$") then
        editBox:SetText(displayName .. " ")
    elseif text:match("\n%s*$") then
        editBox:SetText(text:gsub("\n%s*$", "\n" .. displayName .. " "))
    else
        editBox:SetText(text .. "\n" .. displayName .. " ")
    end
    editorDirty = true
    editBox:SetCursorPosition(#editBox:GetText())
end

BL.AddTargetToEditor = AddTargetToEditor

--------------------------------------------------------------
-- Add target + open editor with cursor ready to type note
--------------------------------------------------------------
function Blacklist_AddTargetAndNote()
    if not UnitExists("target") then return end
    local fullName = BL:GetUnitFullName("target")
    if not fullName then return end

    -- Pre-create DB entry so SyncFromEditor preserves metadata
    if not BlacklistDB[fullName] then
        BlacklistDB[fullName] = { createdAt = time(), note = "", source = "editor" }
    end
    BL:UpdateUnitCache("target")

    -- Ensure window is open
    if not frame:IsShown() then
        frame:Show()
    end

    -- Check if already in editor text (no Refresh, avoids flicker)
    local text = editBox:GetText()
    local searchPos = 1
    for line in text:gmatch("[^\n]*") do
        local nameToken = BL:ParseLine(line)
        local lineFullName = nameToken and BL:ResolveNameToken(nameToken)
        if lineFullName == fullName then
            -- Existing entry - place cursor at end of their line
            editBox:SetCursorPosition(searchPos + #line - 1)
            editBox:SetFocus()
            return
        end
        searchPos = searchPos + #line + 1
    end

    -- New entry - use trailing empty line if present, otherwise append
    local displayName = BL:FormatDisplayName(fullName)
    if not text or #text == 0 or text:match("^%s*$") then
        editBox:SetText(displayName .. " ")
    elseif text:match("\n%s*$") then
        editBox:SetText(text:gsub("\n%s*$", "\n" .. displayName .. " "))
    else
        editBox:SetText(text .. "\n" .. displayName .. " ")
    end
    editorDirty = true
    editBox:SetCursorPosition(#editBox:GetText())
    editBox:SetFocus()
end

--------------------------------------------------------------
-- Add mouseover (or target) + open editor with cursor ready
--------------------------------------------------------------
function Blacklist_AddMouseoverAndNote()
    local unit = UnitExists("mouseover") and "mouseover" or "target"
    if not UnitExists(unit) then return end
    local fullName = BL:GetUnitFullName(unit)
    if not fullName then return end

    -- Pre-create DB entry so SyncFromEditor preserves metadata
    if not BlacklistDB[fullName] then
        BlacklistDB[fullName] = { createdAt = time(), note = "", source = "editor" }
    end
    BL:UpdateUnitCache(unit)

    -- Ensure window is open
    if not frame:IsShown() then
        frame:Show()
    end

    -- Check if already in editor text (no Refresh, avoids flicker)
    local text = editBox:GetText()
    local searchPos = 1
    for line in text:gmatch("[^\n]*") do
        local nameToken = BL:ParseLine(line)
        local lineFullName = nameToken and BL:ResolveNameToken(nameToken)
        if lineFullName == fullName then
            -- Existing entry - place cursor at end of their line
            editBox:SetCursorPosition(searchPos + #line - 1)
            editBox:SetFocus()
            return
        end
        searchPos = searchPos + #line + 1
    end

    -- New entry - use trailing empty line if present, otherwise append
    local displayName = BL:FormatDisplayName(fullName)
    if not text or #text == 0 or text:match("^%s*$") then
        editBox:SetText(displayName .. " ")
    elseif text:match("\n%s*$") then
        editBox:SetText(text:gsub("\n%s*$", "\n" .. displayName .. " "))
    else
        editBox:SetText(text .. "\n" .. displayName .. " ")
    end
    editorDirty = true
    editBox:SetCursorPosition(#editBox:GetText())
    editBox:SetFocus()
end

--------------------------------------------------------------
-- Click outside to clear focus
--------------------------------------------------------------
-- Clear editor focus when clicking anywhere outside the Blacklist frame
local focusChecker = CreateFrame("Frame")
local mouseWasDown = false
focusChecker:SetScript("OnUpdate", function()
    if not editBox:HasFocus() then
        mouseWasDown = false
        return
    end
    local down = IsMouseButtonDown("LeftButton")
    if not down then
        mouseWasDown = false
        return
    end
    -- Ignore if this is a continuing hold (drag) from a previous frame
    if mouseWasDown then return end
    mouseWasDown = true
    -- Fresh click: clear focus only if outside the frame
    if not frame:IsMouseOver() then
        editBox:ClearFocus()
    end
end)

--------------------------------------------------------------
-- Shift-click name insertion
--------------------------------------------------------------
local lastEditBoxFocusLost = 0

editBox:SetScript("OnEditFocusLost", function()
    lastEditBoxFocusLost = GetTime()
end)

local function EditorHasFocus()
    return editBox:HasFocus() or (GetTime() - lastEditBoxFocusLost < 0.6)
end

-- Hook SetItemRef for shift-click on player names in chat
local origSetItemRef = SetItemRef
SetItemRef = function(link, text, button, chatFrame)
    if not (IsShiftKeyDown() and frame:IsShown() and EditorHasFocus()) then
        return origSetItemRef(link, text, button, chatFrame)
    end
    local playerName = link:match("^player:([^:]+)")
    if not playerName then return origSetItemRef(link, text, button, chatFrame) end
    -- playerName may be "Name-Server" — split and resolve to composite key
    local n, r = BL:SplitFullName(playerName)
    local fullName = BL:GetFullName(n, r)
    if not fullName then return origSetItemRef(link, text, button, chatFrame) end

    local displayName = BL:FormatDisplayName(fullName)
    local current = editBox:GetText()
    editBox:SetText((current and #current > 0) and (current .. "\n" .. displayName) or displayName)
    editorDirty = true
    editBox:SetCursorPosition(#editBox:GetText())
    editBox:SetFocus()
end
