local ADDON_NAME, BL = ...

-- HookScript appends to existing handlers, won't interfere with other addons
GameTooltip:HookScript("OnTooltipSetUnit", function(self)
    if not BL:GetSetting("tooltip") then return end

    local _, unit = self:GetUnit()
    if not unit then return end

    local fullName = BL:GetUnitFullName(unit)
    if not fullName then return end
    local entry = BlacklistDB[fullName]
    if not entry then return end

    -- Spacer
    self:AddLine(" ")

    -- BLACKLISTED header (red)
    self:AddLine("BLACKLISTED", 1, 0.2, 0.2)

    -- Note (gold)
    if BL:GetSetting("tooltipnote") then
        local note = entry.note
        if note and #note > 0 then
            self:AddLine("[" .. note .. "]", 1, 0.82, 0)
        end
    end

    -- Added / Last seen line (grey)
    local parts = {}
    if entry.createdAt and BL:GetSetting("tooltipadded") then
        parts[#parts + 1] = "Added: " .. date("%Y-%m-%d", entry.createdAt)
    end
    if entry.lastSeen and BL:GetSetting("tooltiplastseen") then
        local ago = BL:FormatTimeAgo(entry.lastSeen)
        if ago then
            parts[#parts + 1] = "Last seen: " .. ago
        end
    end
    if #parts > 0 then
        self:AddLine(table.concat(parts, "  |  "), 0.6, 0.6, 0.6)
    end

    self:Show()
end)
