local _, BL = ...

local NOTE_FONT = "Fonts\\FRIZQT__.TTF"
local NOTE_FONT_SIZE = 11

local function UpdateNameplate(nameplate, unit)
    if not nameplate or not unit then return end

    if not nameplate.BlacklistNote then
        local noteText = nameplate:CreateFontString(nil, "OVERLAY")
        noteText:SetFont(NOTE_FONT, NOTE_FONT_SIZE, "")
        noteText:SetShadowOffset(1, -1)
        noteText:SetShadowColor(0, 0, 0, 1)
        noteText:SetPoint("BOTTOM", nameplate, "TOP", 0, 0)
        noteText:SetTextColor(1, 0.82, 0, 1)
        nameplate.BlacklistNote = noteText

        -- Blink animation group
        local ag = noteText:CreateAnimationGroup()
        local a1 = ag:CreateAnimation("Alpha")
        a1:SetFromAlpha(1); a1:SetToAlpha(0); a1:SetDuration(0.15); a1:SetOrder(1)
        local a2 = ag:CreateAnimation("Alpha")
        a2:SetFromAlpha(0); a2:SetToAlpha(1); a2:SetDuration(0.15); a2:SetOrder(2)
        ag:SetLooping("REPEAT")
        nameplate.BlacklistFlash = ag
    end

    if BL:IsUnitBlacklisted(unit) and BL:GetSetting("nameplate") then
        local fullName = BL:GetUnitFullName(unit)
        local entry = fullName and BlacklistDB[fullName]
        local note = BL:GetUnitNote(unit)
        if note and #note > 0 then
            nameplate.BlacklistNote:SetText(note)
            if entry and entry.alert then
                nameplate.BlacklistNote:SetFont(NOTE_FONT, NOTE_FONT_SIZE + 4, "OUTLINE")
                nameplate.BlacklistNote:SetTextColor(1, 0.2, 0.2, 1)
                if not nameplate.BlacklistFlash:IsPlaying() then
                    nameplate.BlacklistFlash:Play()
                    C_Timer.After(0.6, function()
                        if nameplate.BlacklistFlash then
                            nameplate.BlacklistFlash:Stop()
                            nameplate.BlacklistNote:SetAlpha(1)
                        end
                    end)
                end
            else
                nameplate.BlacklistNote:SetFont(NOTE_FONT, NOTE_FONT_SIZE, "")
                nameplate.BlacklistNote:SetTextColor(1, 0.82, 0, 1)
                if nameplate.BlacklistFlash:IsPlaying() then
                    nameplate.BlacklistFlash:Stop()
                    nameplate.BlacklistNote:SetAlpha(1)
                end
            end
            nameplate.BlacklistNote:Show()
        else
            nameplate.BlacklistNote:Hide()
        end
    else
        nameplate.BlacklistNote:Hide()
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("NAME_PLATE_UNIT_ADDED")
f:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
f:SetScript("OnEvent", function(_, event, unit)
    if event == "NAME_PLATE_UNIT_ADDED" then
        BL:UpdateUnitCache(unit)
        local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
        UpdateNameplate(nameplate, unit)
    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
        if nameplate and nameplate.BlacklistNote then
            nameplate.BlacklistNote:Hide()
        end
    end
end)

function BL:RefreshNameplates()
    local plates = C_NamePlate.GetNamePlates()
    for _, nameplate in ipairs(plates) do
        local unit = nameplate.namePlateUnitToken
        if unit then
            UpdateNameplate(nameplate, unit)
        end
    end
end
