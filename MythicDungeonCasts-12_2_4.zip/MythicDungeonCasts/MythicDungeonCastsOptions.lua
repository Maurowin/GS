
local ADDON_NAME   = "MythicDungeonCasts"
local DISPLAY_NAME = "Mythic Dungeon Casts"
local DC = _G[ADDON_NAME]
if not DC then return end

local AceGUI = LibStub("MDC-AceGUI-3.0")
local LSM    = LibStub("LibSharedMedia-3.0")
local L      = _G["MDC_Locale"] or setmetatable({}, { __index = function(_, k) return k end })

local WINDOW_SIZES = {
    small  = { w = 400, h = 540 },
    medium = { w = 600, h = 540 },
    large  = { w = 800, h = 540 },
}
local MIN_W, MIN_H         = 300, 400
local SIDEBAR_W            = 155
local TITLE_H              = 36
local NAV_ITEM_H           = 20
local NAV_PAD_TOP          = 6
local NAV_PAD_LEFT         = 8
local CONTENT_PAD          = 6

local C_BG        = { 0.07, 0.07, 0.07, 0.95 }
local C_SIDEBAR   = { 0.07, 0.07, 0.07, 0.95 }
local C_TITLE_BG  = { 0.07, 0.07, 0.07, 0.95 }
local C_SEL       = { 0.14, 0.40, 0.72, 0.90 }
local C_HOVER     = { 0.18, 0.18, 0.18, 1 }
local C_BORDER    = { 0.25, 0.25, 0.25, 1 }
local C_NAV       = { 0.85, 0.85, 0.85, 1 }
local C_NAV_SEL   = { 1, 1, 1, 1 }

-- ── Social links (bottom of the sidebar) ──────────────────────
local SOCIAL_MEDIA_PATH = [[Interface\AddOns\MythicDungeonCasts\Media\Social\]]
local SOCIAL_BAR_H   = 46
local SOCIAL_ICON_SZ = 22
local SOCIAL_ICON_GAP = 12
local SOCIAL_LINKS = {
    {
        key     = "twitch",
        name    = "Twitch",
        texture = SOCIAL_MEDIA_PATH .. "twitch.png",
        label   = L["Twitch channel"] or "Twitch channel",
        copy    = "https://twitch.tv/Abiecherry",
        color   = { 0.576, 0.274, 1.0 },   -- #9146FF
    },
    {
        key     = "youtube",
        name    = "YouTube",
        texture = SOCIAL_MEDIA_PATH .. "youtube.png",
        label   = L["YouTube channel"] or "YouTube channel",
        copy    = "https://www.youtube.com/@abiecherry",
        color   = { 1.0, 0.0, 0.0 },       -- #FF0000
    },
}

local pairs, ipairs, type, tostring = pairs, ipairs, type, tostring

local function safecall(func, ...)
    local ok, err = pcall(func, ...)
    if not ok then geterrorhandler()(err) end
end

local function getName(opt)
    local n = opt.name
    if type(n) == "function" then
        local ok, v = pcall(n); return ok and v or ""
    end
    return n or ""
end

local function isHidden(opt)
    local h = opt.hidden
    if type(h) == "function" then
        local ok, v = pcall(h); return ok and v
    end
    return h
end

local function isDisabled(opt)
    local d = opt.disabled
    if type(d) == "function" then
        local ok, v = pcall(d); return ok and v
    end
    return d
end

local function getval(opt, info)
    if opt.get and type(opt.get) == "function" then
        local ok, v = pcall(opt.get, info)
        if ok then return v end
    end
end

local function setval(opt, info, ...)
    if opt.set and type(opt.set) == "function" then
        safecall(opt.set, info, ...)
    end
end

local function sortedOptions(group)
    local list = {}
    for k, v in pairs(group.args or {}) do
        if type(v) == "table" then
            list[#list + 1] = { key = k, tbl = v, order = v.order or 100 }
        end
    end
    table.sort(list, function(a, b)
        if a.order ~= b.order then return a.order < b.order end
        return a.key < b.key
    end)
    return list
end

local function makeInfo(path, key, handler)
    local info = { handler = handler }
    for i, v in ipairs(path) do info[i] = v end
    info[#info + 1] = key
    return info
end

local function RenderOptions(container, optGroup, path, handler, appName)
    local sorted = sortedOptions(optGroup)

    for _, entry in ipairs(sorted) do
        local key   = entry.key
        local opt   = entry.tbl
        local oType = opt.type

        if not isHidden(opt) then
            local info = makeInfo(path, key, handler)

            if oType == "header" then
                local w = AceGUI:Create("Heading")
                w:SetText(getName(opt))
                w:SetFullWidth(true)
                container:AddChild(w)
                local f = w.frame or w
                local regions = { f:GetRegions() }
                for _, region in ipairs(regions) do
                    if region.GetObjectType and region:GetObjectType() == "Texture" then
                        region:SetColorTexture(1, 1, 1, 0.6)
                    end
                end

            elseif oType == "description" then
                local w = AceGUI:Create("Label")
                w:SetFullWidth(true)
                -- Map the option's fontSize to a fixed pixel size so every note
                -- is sized deterministically (AceGUI recycles Label widgets, and
                -- reading the size back later via GetFont() is unreliable for
                -- font-object-backed labels, which caused random oversized notes).
                local DESC_SIZE_MAP = { small = 10, large = 14 }
                local descSize = DESC_SIZE_MAP[opt.fontSize] or 11
                local prof = DC and DC.db and DC.db.profile
                local fName = (prof and prof.optionsPanel and prof.optionsPanel.textFont) or "Friz Quadrata TT"
                local fPath = LSM:Fetch("font", fName) or [[Fonts\FRIZQT__.TTF]]
                if w.SetFont then w:SetFont(fPath, descSize, "") end
                -- Apply directly to the underlying fontstring too (so height
                -- measurement is correct even if the AceGUI font object fails),
                -- and tag it with the intended size for the font-reapply pass.
                if w.label and w.label.SetFont then
                    w.label:SetFont(fPath, descSize, "")
                    w.label.mdcFontSize = descSize
                end
                w:SetText(getName(opt))
                container:AddChild(w)

            elseif oType == "group" and opt.inline then
                local w = AceGUI:Create("InlineGroup")
                w:SetTitle(getName(opt))
                w:SetFullWidth(true)
                container:AddChild(w)
                local newPath = {}
                for _, v in ipairs(path) do newPath[#newPath + 1] = v end
                newPath[#newPath + 1] = key
                RenderOptions(w, opt, newPath, handler, appName)

            elseif oType == "toggle" then
                local w = AceGUI:Create("CheckBox")
                w:SetLabel(getName(opt))
                w:SetDisabled(isDisabled(opt))
                w:SetValue(getval(opt, info) and true or false)
                w:SetFullWidth(true)
                w:SetCallback("OnValueChanged", function(widget, event, val)
                    setval(opt, info, val)
                    widget:SetValue(getval(opt, info) and true or false)
                end)
                container:AddChild(w)

            elseif oType == "input" then
                local w = AceGUI:Create("EditBox")
                w:SetLabel(getName(opt))
                w:SetDisabled(isDisabled(opt))
                w:SetText(tostring(getval(opt, info) or ""))
                w:SetFullWidth(true)
                w:SetCallback("OnEnterPressed", function(widget, event, val)
                    setval(opt, info, val)
                    widget:SetText(tostring(getval(opt, info) or ""))
                end)
                container:AddChild(w)

            elseif oType == "range" then
                local w = AceGUI:Create("Slider")
                w:SetLabel(getName(opt))
                w:SetDisabled(isDisabled(opt))
                local mn  = type(opt.min)  == "function" and opt.min()  or (opt.min  or 0)
                local mx  = type(opt.max)  == "function" and opt.max()  or (opt.max  or 100)
                local stp = type(opt.step) == "function" and opt.step() or (opt.step or 1)
                w:SetSliderValues(mn, mx, stp)
                if opt.isPercent then pcall(function() w:SetIsPercent(true) end) end
                w:SetValue(tonumber(getval(opt, info)) or mn)
                w:SetFullWidth(true)
                w:SetCallback("OnValueChanged", function(widget, event, val)
                    setval(opt, info, val)
                    widget:SetValue(tonumber(getval(opt, info)) or mn)
                end)
                container:AddChild(w)

            elseif oType == "select" then
                local w = AceGUI:Create("Dropdown")
                w:SetLabel(getName(opt))
                w:SetDisabled(isDisabled(opt))
                local vals = opt.values
                if type(vals) == "function" then
                    local ok, v2 = pcall(vals, info)
                    vals = ok and v2 or {}
                elseif type(vals) ~= "table" then
                    vals = {}
                end
                w:SetList(vals, opt.sorting)
                w:SetValue(getval(opt, info))
                w:SetFullWidth(true)
                w:SetCallback("OnValueChanged", function(widget, event, val)
                    setval(opt, info, val)
                    widget:SetValue(getval(opt, info))
                end)
                container:AddChild(w)

            elseif oType == "multiselect" then
                local vals = opt.values
                if type(vals) == "function" then
                    local ok, v2 = pcall(vals, info)
                    vals = ok and v2 or {}
                elseif type(vals) ~= "table" then
                    vals = {}
                end
                local lbl = AceGUI:Create("Label")
                lbl:SetText(getName(opt))
                lbl:SetFullWidth(true)
                if lbl.label then lbl.label.mdcFontSize = nil end
                container:AddChild(lbl)
                for k, label in pairs(vals) do
                    local w = AceGUI:Create("CheckBox")
                    w:SetLabel(tostring(label))
                    w:SetFullWidth(true)
                    local v
                    if opt.get then
                        local ok2, vv = pcall(opt.get, info, k)
                        v = ok2 and vv
                    end
                    w:SetValue(v and true or false)
                    w:SetCallback("OnValueChanged", function(widget, event, val)
                        if opt.set then safecall(opt.set, info, k, val) end
                    end)
                    container:AddChild(w)
                end

            elseif oType == "color" then
                local w = AceGUI:Create("ColorPicker")
                w:SetLabel(getName(opt))
                w:SetDisabled(isDisabled(opt))
                w:SetHasAlpha(opt.hasAlpha)
                local r, g, b, a = 1, 1, 1, 1
                if opt.get then
                    local ok2, r2, g2, b2, a2 = pcall(opt.get, info)
                    if ok2 then r, g, b, a = r2, g2, b2, (a2 or 1) end
                end
                w:SetColor(r, g, b, a)
                w:SetFullWidth(true)
                w:SetCallback("OnValueChanged", function(widget, event, r2, g2, b2, a2)
                    setval(opt, info, r2, g2, b2, a2)
                    local rn, gn, bn, an = r2, g2, b2, a2
                    if opt.get then
                        local ok2, r3, g3, b3, a3 = pcall(opt.get, info)
                        if ok2 then rn, gn, bn, an = r3, g3, b3, (a3 or 1) end
                    end
                    widget:SetColor(rn, gn, bn, an or 1)
                end)
                container:AddChild(w)

            elseif oType == "execute" then
                local w = AceGUI:Create("Button")
                w:SetText(getName(opt))
                w:SetDisabled(isDisabled(opt))
                w:SetFullWidth(true)
                w:SetCallback("OnClick", function()
                    if opt.func then safecall(opt.func, info) end
                end)
                container:AddChild(w)
            end
        end
    end
end

local mainFrame, currentScroll
local navButtons = {}
local selectedKey

local function ReleaseContent()
    if currentScroll then
        if currentScroll.ReleaseChildren then
            currentScroll:ReleaseChildren()
        end
        if currentScroll.frame then
            currentScroll.frame:SetParent(nil)
            currentScroll.frame:Hide()
        end
        if AceGUI.Release then
            AceGUI:Release(currentScroll)
        end
        currentScroll = nil
    end
end

local function MakeScrollContainer()
    ReleaseContent()
    local scroll = AceGUI:Create("ScrollFrame")
    if scroll.SetLayout then
        scroll:SetLayout("Flow")
    else
        scroll.layout = "Flow"
    end
    currentScroll = scroll
    local sf = scroll.frame
    sf:SetParent(mainFrame.contentArea)
    sf:ClearAllPoints()
    sf:SetAllPoints(mainFrame.contentArea)
    sf:Show()
    return scroll
end

local function ApplyFontToAllNavButtons()
    if not mainFrame then return end
    local db = DC.db and DC.db.profile
    if not db then return end
    local fontName = db.optionsPanel.textFont or "Friz Quadrata TT"
    local fontPath = LSM:Fetch("font", fontName) or [[Fonts\FRIZQT__.TTF]]
    for _, btn in pairs(navButtons) do
        if btn.label then
            btn.label:SetFont(fontPath, 12, "")
        end
    end
    local function ApplyToChildren(frame)
        if not frame then return end
        local regions = { frame:GetRegions() }
        for _, region in ipairs(regions) do
            if region and region.GetObjectType and region:GetObjectType() == "FontString" then
                local _, size, flags = region:GetFont()
                -- Prefer an explicitly pinned size (e.g. description notes) over
                -- the value read back from GetFont(), which is unreliable for
                -- font-object-backed fontstrings and caused inconsistent sizes.
                local useSize = region.mdcFontSize or size
                if useSize then
                    region:SetFont(fontPath, useSize, flags or "")
                end
            end
        end
        local children = { frame:GetChildren() }
        for _, child in ipairs(children) do
            ApplyToChildren(child)
        end
    end
    if mainFrame.contentArea then
        ApplyToChildren(mainFrame.contentArea)
    end
    if mainFrame.titleText then
        mainFrame.titleText:SetFont(fontPath, 16, "")
    end
    if mainFrame.byLine then
        mainFrame.byLine:SetFont(fontPath, 10, "")
    end
end

local function ApplyFrameOpacity()
    if not mainFrame then return end
    local db = DC.db and DC.db.profile
    if not db then return end
    local alpha = db.optionsPanel.windowOpacity or 0.95
    mainFrame:SetBackdropColor(C_BG[1], C_BG[2], C_BG[3], alpha)
    if mainFrame.titleBg then
        mainFrame.titleBg:SetColorTexture(C_TITLE_BG[1], C_TITLE_BG[2], C_TITLE_BG[3], alpha)
    end
    if mainFrame.sidebarBg then
        mainFrame.sidebarBg:SetColorTexture(C_SIDEBAR[1], C_SIDEBAR[2], C_SIDEBAR[3], alpha)
    end
end

local function ApplyWindowSize()
    if not mainFrame then return end
    local db = DC.db and DC.db.profile
    if not db then return end
    local sizeKey = db.optionsPanel.windowSize or "small"
    local sz = WINDOW_SIZES[sizeKey] or WINDOW_SIZES.small
    mainFrame:SetSize(sz.w, sz.h)
end

local function HighlightTab(key)
    selectedKey = key
    for k, btn in pairs(navButtons) do
        if k == key then
            btn.bg:SetColorTexture(C_SEL[1], C_SEL[2], C_SEL[3], C_SEL[4])
            btn.label:SetTextColor(C_NAV_SEL[1], C_NAV_SEL[2], C_NAV_SEL[3], C_NAV_SEL[4])
        else
            btn.bg:SetColorTexture(0, 0, 0, 0)
            btn.label:SetTextColor(C_NAV[1], C_NAV[2], C_NAV[3], C_NAV[4])
        end
    end
end

local function SelectCategory(key, groupTbl, options, appName)
    if selectedKey == key then return end
    HighlightTab(key)
    local scroll = MakeScrollContainer()
    RenderOptions(scroll, groupTbl, { key }, options.handler, appName)
    ApplyFontToAllNavButtons()
    DC._refreshCurrentTab = function()
        HighlightTab(key)
        local s = MakeScrollContainer()
        RenderOptions(s, groupTbl, { key }, options.handler, appName)
        ApplyFontToAllNavButtons()
    end
end

local MDC_EXPORT_PREFIX = "!mdc_"

local function GetSerializer()
    return LibStub and LibStub:GetLibrary("MDC-AceSerializer-3.0", true)
end
local function GetDeflate()
    return LibStub and LibStub:GetLibrary("MDC-LibDeflate", true)
end

local function EncodeProfile(tbl)
    local serializer = GetSerializer()
    local deflate = GetDeflate()
    if not serializer or not deflate then
        return nil, "Required libraries missing (AceSerializer / LibDeflate)"
    end
    local serialized = serializer:Serialize(tbl)
    if not serialized or serialized == "" then return nil, "Serialization failed" end
    local compressed = deflate:CompressDeflate(serialized, {level = 9})
    if not compressed then return nil, "Compression failed" end
    local encoded = deflate:EncodeForPrint(compressed)
    if not encoded then return nil, "Encoding failed" end
    return MDC_EXPORT_PREFIX .. encoded
end

local legacy_b64chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local legacy_b64lookup = {}
for i = 1, 64 do legacy_b64lookup[legacy_b64chars:byte(i)] = i - 1 end
local function LegacyBase64Decode(data)
    data = data:gsub("[^A-Za-z0-9+/=]", "")
    if data == "" then return nil end
    local out = {}
    for i = 1, #data, 4 do
        local a = legacy_b64lookup[data:byte(i)] or 0
        local b = legacy_b64lookup[data:byte(i+1)] or 0
        local c = legacy_b64lookup[data:byte(i+2)] or 0
        local d = legacy_b64lookup[data:byte(i+3)] or 0
        local n = a * 262144 + b * 4096 + c * 64 + d
        out[#out + 1] = string.char(math.floor(n / 65536) % 256)
        if data:sub(i+2, i+2) ~= "=" then out[#out + 1] = string.char(math.floor(n / 256) % 256) end
        if data:sub(i+3, i+3) ~= "=" then out[#out + 1] = string.char(n % 256) end
    end
    return table.concat(out)
end

local function TryLegacyDecode(payload)
    local raw = LegacyBase64Decode(payload)
    if not raw or raw == "" then return nil end
    local loader = loadstring or load
    if not loader then return nil end
    local fn = loader("return " .. raw)
    if not fn then return nil end
    if setfenv then pcall(setfenv, fn, {}) end
    local ok, result = pcall(fn)
    if not ok or type(result) ~= "table" then return nil end
    return result
end

local function DecodeProfile(str)
    if not str or str == "" then return nil, "Empty import string" end
    if str:sub(1, #MDC_EXPORT_PREFIX) ~= MDC_EXPORT_PREFIX then
        return nil, "Invalid format — string must start with " .. MDC_EXPORT_PREFIX
    end
    local serializer = GetSerializer()
    local deflate = GetDeflate()
    if not serializer or not deflate then
        return nil, "Required libraries missing (AceSerializer / LibDeflate)"
    end
    local payload = str:sub(#MDC_EXPORT_PREFIX + 1)
    local decoded = deflate:DecodeForPrint(payload)
    if decoded then
        local decompressed = deflate:DecompressDeflate(decoded)
        if decompressed then
            local ok, result = serializer:Deserialize(decompressed)
            if ok and type(result) == "table" then
                return result
            end
        end
    end
    local legacy = TryLegacyDecode(payload)
    if legacy then
        return legacy
    end
    return nil, "Import string is corrupted, truncated, or not a valid MDC export"
end

local function DeepCopy(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            DeepCopy(v, dst[k])
        else dst[k] = v end
    end
end

local function WipeTable(t)
    for k in pairs(t) do if type(t[k]) ~= "function" then t[k] = nil end end
end

local function UniqueProfileName(acedb, baseName)
    local existing = {}
    local profList = {}
    pcall(function() acedb:GetProfiles(profList) end)
    if #profList == 0 and acedb.profiles then
        for k in pairs(acedb.profiles) do profList[#profList + 1] = k end
    end
    for _, v in ipairs(profList) do existing[v] = true end
    if not existing[baseName] then return baseName end
    local i = 1
    while existing[baseName .. " " .. i] do i = i + 1 end
    return baseName .. " " .. i
end

local _activePopup
local function CreatePopupFrame(title, onAccept, onCancel, showEditBox, editBoxText)
    if _activePopup and _activePopup:IsShown() then
        _activePopup:Hide(); _activePopup:SetParent(nil)
    end
    _activePopup = nil
    local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    f:SetSize(350, 350); f:SetPoint("CENTER"); f:SetFrameStrata("FULLSCREEN_DIALOG"); f:SetFrameLevel(200)
    f:SetMovable(true); f:EnableMouse(true); f:SetClampedToScreen(true)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    f:SetBackdropColor(0.1, 0.1, 0.1, 0.95); f:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    f:SetScript("OnHide", function(self) if _activePopup == self then _activePopup = nil end end)
    _activePopup = f

    local titleBar = f:CreateTexture(nil, "ARTWORK"); titleBar:SetPoint("TOPLEFT", 1, -1); titleBar:SetPoint("TOPRIGHT", -1, -1)
    titleBar:SetHeight(24); titleBar:SetColorTexture(0.15, 0.15, 0.15, 1)
    local drag = CreateFrame("Frame", nil, f); drag:SetAllPoints(titleBar); drag:EnableMouse(true); drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", function() f:StartMoving() end); drag:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local titleText = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    titleText:SetPoint("CENTER", titleBar, "CENTER"); titleText:SetTextColor(1, 1, 1); titleText:SetText(title)

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetSize(20, 20); closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() f:Hide(); f:SetParent(nil) end)

    if showEditBox then
        local scrollFrame = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
        scrollFrame:SetPoint("TOPLEFT", 10, -34); scrollFrame:SetPoint("BOTTOMRIGHT", -28, 44)
        local editBox = CreateFrame("EditBox", nil, scrollFrame)
        editBox:SetMultiLine(true); editBox:SetAutoFocus(false); editBox:SetFontObject(GameFontHighlightSmall)
        editBox:SetWidth(scrollFrame:GetWidth() - 10 or 300); editBox:SetText(editBoxText or "")
        scrollFrame:SetScrollChild(editBox)
        f.editBox = editBox
        if editBoxText and editBoxText ~= "" then
            C_Timer.After(0.05, function() editBox:HighlightText(); editBox:SetFocus() end)
        else
            C_Timer.After(0.05, function() editBox:SetFocus() end)
        end
    end

    if onAccept then
        local acceptBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
        acceptBtn:SetSize(100, 24); acceptBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOM", -4, 10)
        acceptBtn:SetText(L["Save"] or "Save")
        acceptBtn:SetScript("OnClick", function() onAccept(f); f:Hide(); f:SetParent(nil) end)
    end

    local cancelBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    cancelBtn:SetSize(100, 24)
    if onAccept then
        cancelBtn:SetPoint("BOTTOMLEFT", f, "BOTTOM", 4, 10)
    else
        cancelBtn:SetPoint("BOTTOM", f, "BOTTOM", 0, 10)
    end
    cancelBtn:SetText(L["Cancel"] or "Cancel")
    cancelBtn:SetScript("OnClick", function() f:Hide(); f:SetParent(nil) end)

    f:Show()
    return f
end

local function RenderProfilesTab()
    HighlightTab("__profiles__")
    local scroll = MakeScrollContainer()
    local acedb = DC.db

    local curLabel = AceGUI:Create("Label")
    curLabel:SetText((L["Current profile:"] or "Current profile:") .. " |cffffd700" .. acedb:GetCurrentProfile() .. "|r")
    curLabel:SetFullWidth(true)
    if curLabel.label then curLabel.label.mdcFontSize = nil end
    if curLabel.SetFontObject then curLabel:SetFontObject(GameFontNormalLarge) end
    scroll:AddChild(curLabel)

    local switchDrop = AceGUI:Create("Dropdown")
    if switchDrop.SetLabel then switchDrop:SetLabel(L["Switch Profile"] or "Switch Profile") end
    local profiles = {}
    local profListAll = {}
    pcall(function() acedb:GetProfiles(profListAll) end)
    if #profListAll == 0 and acedb.profiles then
        for k in pairs(acedb.profiles) do profListAll[#profListAll + 1] = k end
    end
    for _, v in ipairs(profListAll) do profiles[v] = v end
    if switchDrop.SetList then switchDrop:SetList(profiles) end
    if switchDrop.SetValue then switchDrop:SetValue(acedb:GetCurrentProfile()) end
    if switchDrop.SetRelativeWidth then switchDrop:SetFullWidth(true) end
    switchDrop:SetCallback("OnValueChanged", function(_, _, val)
        acedb:SetProfile(val)
        DC:OpenOptionsPanel()
        C_Timer.After(0.05, function() if navButtons["__profiles__"] then RenderProfilesTab() end end)
    end)
    scroll:AddChild(switchDrop)

    local newBox = AceGUI:Create("EditBox")
    if newBox.SetLabel then newBox:SetLabel(L["New Profile"] or "New Profile") end
    if newBox.SetRelativeWidth then newBox:SetFullWidth(true) end
    if newBox.SetText then newBox:SetText("") end
    newBox:SetCallback("OnEnterPressed", function(widget, _, val)
        if val and val ~= "" then
            local name = UniqueProfileName(acedb, val)
            acedb:SetProfile(name)
            if widget.SetText then widget:SetText("") end
            DC:OpenOptionsPanel()
            C_Timer.After(0.05, function() if navButtons["__profiles__"] then RenderProfilesTab() end end)
        end
    end)
    scroll:AddChild(newBox)

    local renameBox = AceGUI:Create("EditBox")
    if renameBox.SetLabel then renameBox:SetLabel(L["Rename Profile"] or "Rename Profile") end
    if renameBox.SetRelativeWidth then renameBox:SetFullWidth(true) end
    local isDefaultProfile = (acedb:GetCurrentProfile() == "MDC Cherry - Default")
    if renameBox.SetText then renameBox:SetText(isDefaultProfile and "" or acedb:GetCurrentProfile()) end
    if renameBox.SetDisabled then renameBox:SetDisabled(isDefaultProfile) end
    renameBox:SetCallback("OnEnterPressed", function(widget, _, val)
        if acedb:GetCurrentProfile() == "MDC Cherry - Default" then return end
        if val and val ~= "" and val ~= acedb:GetCurrentProfile() then
            local oldName = acedb:GetCurrentProfile()
            local newName = UniqueProfileName(acedb, val)
            acedb:SetProfile(newName)
            if acedb.profiles[oldName] then
                DeepCopy(acedb.profiles[oldName], acedb.profile)
                acedb:DeleteProfile(oldName, true)
            end
            print("|cff00ff00Mythic Dungeon Casts:|r Profile renamed to '" .. newName .. "'.")
            DC:OpenOptionsPanel()
            C_Timer.After(0.05, function() if navButtons["__profiles__"] then RenderProfilesTab() end end)
        end
    end)
    scroll:AddChild(renameBox)

    local resetBtn = AceGUI:Create("Button")
    if resetBtn.SetText then resetBtn:SetText(L["Reset"] or "Reset") end
    if resetBtn.SetRelativeWidth then resetBtn:SetFullWidth(true) end
    resetBtn:SetCallback("OnClick", function()
        local current = acedb:GetCurrentProfile()
        StaticPopupDialogs["MDC_RESET_PROFILE_CONFIRM"] = {
            text = (L["Are you sure you want to reset profile"] or "Are you sure you want to reset profile") .. " '|cffffd700" .. current .. "|r'?",
            button1 = L["Reset"] or "Reset", button2 = L["Cancel"] or "Cancel",
            OnAccept = function()
                acedb:ResetProfile()
                print("|cff00ff00Mythic Dungeon Casts:|r Profile reset to defaults.")
                RenderProfilesTab()
            end,
            timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        }
        StaticPopup_Show("MDC_RESET_PROFILE_CONFIRM")
    end)
    scroll:AddChild(resetBtn)

    local delDrop = AceGUI:Create("Dropdown")
    if delDrop.SetLabel then delDrop:SetLabel(L["Delete"] or "Delete") end
    local delProfiles = {}
    local current = acedb:GetCurrentProfile()
    local profList = {}
    pcall(function() acedb:GetProfiles(profList) end)
    if #profList == 0 and acedb.profiles then for k in pairs(acedb.profiles) do profList[#profList + 1] = k end end
    for _, v in ipairs(profList) do if v ~= current and v ~= "MDC Cherry - Default" then delProfiles[v] = v end end
    if delDrop.SetList then delDrop:SetList(delProfiles) end
    if delDrop.SetRelativeWidth then delDrop:SetFullWidth(true) end
    delDrop:SetCallback("OnValueChanged", function(_, _, val)
        if val and val ~= "" then
            StaticPopupDialogs["MDC_DELETE_CONFIRM"] = {
                text = (L["Are you sure you want to delete profile"] or "Are you sure you want to delete profile") .. " '|cffffd700" .. val .. "|r'?",
                button1 = L["Delete"] or "Delete", button2 = L["Cancel"] or "Cancel",
                OnAccept = function()
                    acedb:DeleteProfile(val, true)
                    print("|cff00ff00Mythic Dungeon Casts:|r Profile '" .. val .. "' deleted.")
                    RenderProfilesTab()
                end,
                timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
            }
            StaticPopup_Show("MDC_DELETE_CONFIRM")
        end
    end)
    scroll:AddChild(delDrop)

    local sep = AceGUI:Create("Heading")
    if sep.SetText then sep:SetText(L["Import / Export"] or "Import / Export") end
    if sep.SetFullWidth then sep:SetFullWidth(true) end
    scroll:AddChild(sep)

    local exportBtn = AceGUI:Create("Button")
    if exportBtn.SetText then exportBtn:SetText(L["Export"] or "Export") end
    if exportBtn.SetRelativeWidth then exportBtn:SetFullWidth(true) end
    exportBtn:SetCallback("OnClick", function()
        local encoded, err = EncodeProfile(acedb.profile)
        if not encoded then
            print("|cffff4444Mythic Dungeon Casts:|r Export failed" .. (err and (": " .. err) or "") .. ".")
            return
        end
        CreatePopupFrame(
            (L["Export"] or "Export") .. ": " .. acedb:GetCurrentProfile(),
            nil, nil, true, encoded
        )
    end)
    scroll:AddChild(exportBtn)

    local importBtn = AceGUI:Create("Button")
    if importBtn.SetText then importBtn:SetText(L["Import"] or "Import") end
    if importBtn.SetRelativeWidth then importBtn:SetFullWidth(true) end
    importBtn:SetCallback("OnClick", function()
        CreatePopupFrame(
            L["Import"] or "Import",
            function(popup)
                local str = popup.editBox and popup.editBox:GetText() or ""
                local tbl, err = DecodeProfile(str)
                if tbl then
                    local newName = UniqueProfileName(acedb, "New profile")
                    acedb:SetProfile(newName)
                    WipeTable(acedb.profile)
                    DeepCopy(tbl, acedb.profile)
                    acedb.profile.preview = false
                    if MythicDungeonCasts and MythicDungeonCasts._togglePreview then
                        MythicDungeonCasts._togglePreview(false)
                    end
                    if acedb.callbacks and acedb.callbacks.Fire then
                        acedb.callbacks:Fire("OnProfileChanged", acedb)
                    end
                    print("|cff00ff00Mythic Dungeon Casts:|r Profile imported as '" .. newName .. "'.")
                    DC:OpenOptionsPanel()
                    C_Timer.After(0.05, function() if navButtons["__profiles__"] then RenderProfilesTab() end end)
                else
                    print("|cffff4444Mythic Dungeon Casts:|r Import failed" .. (err and (": " .. err) or "") .. ".")
                end
            end,
            nil, true, ""
        )
    end)
    scroll:AddChild(importBtn)
    ApplyFontToAllNavButtons()
end
local function RenderSettingsTab()
    HighlightTab("__settings__")
    local scroll = MakeScrollContainer()

    local db = DC.db.profile
    local op = db.optionsPanel

    local oSlider = AceGUI:Create("Slider")
    oSlider:SetLabel(L["Window Opacity"])
    oSlider:SetSliderValues(0.3, 1.0, 0.05)
    oSlider:SetValue(op.windowOpacity or 0.95)
    oSlider:SetFullWidth(true)
    oSlider:SetCallback("OnValueChanged", function(_, _, val)
        op.windowOpacity = val
        ApplyFrameOpacity()
    end)
    scroll:AddChild(oSlider)

    local fontChoices = {}
    for _, v in ipairs(LSM:List("font")) do fontChoices[v] = v end
    if not next(fontChoices) then fontChoices["Expressway Regular"] = "Expressway Regular" end

    local fontDrop = AceGUI:Create("Dropdown")
    fontDrop:SetLabel(L["Text Font"])
    fontDrop:SetList(fontChoices)
    fontDrop:SetValue(op.textFont or "Friz Quadrata TT")
    fontDrop:SetFullWidth(true)
    fontDrop:SetCallback("OnValueChanged", function(_, _, val)
        op.textFont = val
        ApplyFontToAllNavButtons()
    end)
    scroll:AddChild(fontDrop)

    local sizeChoices = {
        small = L["Small"] or "Small",
        medium = L["Medium"] or "Medium",
        large = L["Large"] or "Large",
    }
    local sizeDrop = AceGUI:Create("Dropdown")
    sizeDrop:SetLabel(L["Window Size"] or "Window Size")
    sizeDrop:SetList(sizeChoices)
    sizeDrop:SetValue(op.windowSize or "small")
    sizeDrop:SetFullWidth(true)
    sizeDrop:SetCallback("OnValueChanged", function(_, _, val)
        op.windowSize = val
        ApplyWindowSize()
    end)
    scroll:AddChild(sizeDrop)

    local langChoices = {
        enUS = "English",
        deDE = "Deutsch",
        esES = "Español",
        frFR = "Français",
        itIT = "Italiano",
        ptBR = "Português",
        ruRU = "Русский",
        zhCN = "中文",
        koKR = "한국어",
        nlNL = "Nederlands",
        svSE = "Svenska",
    }
    local langDrop = AceGUI:Create("Dropdown")
    langDrop:SetLabel(L["Language"])
    langDrop:SetList(langChoices)
    langDrop:SetValue(op.language or "enUS")
    langDrop:SetFullWidth(true)
    langDrop:SetCallback("OnValueChanged", function(_, _, val)
        op.language = val
        if DC.RebuildOptions then DC:RebuildOptions() end
        DC:OpenOptionsPanel()
        C_Timer.After(0.05, function()
            if navButtons["__settings__"] then
                HighlightTab("__settings__")
                RenderSettingsTab()
            end
        end)
    end)
    scroll:AddChild(langDrop)
    ApplyFontToAllNavButtons()
end
-- ── Small popup that shows a social link/handle ready to copy ──
local _activeSocialPopup
local function CreateSocialCopyPopup(social)
    -- Close any popup that's already open. Clear the reference BEFORE calling
    -- Hide(), because Hide() fires the frame's OnHide handler synchronously,
    -- which would otherwise nil out this upvalue while we're still using it.
    local prev = _activeSocialPopup
    _activeSocialPopup = nil
    if prev then
        local sameIconClicked = prev:IsShown() and prev.socialKey == social.key
        prev:Hide()
        prev:SetParent(nil)
        if sameIconClicked then
            -- clicking the same icon again toggles its popup closed
            return
        end
    end

    local cr, cg, cb = social.color[1], social.color[2], social.color[3]

    local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    f:SetSize(280, 120)
    f:SetPoint("CENTER")
    f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetFrameLevel(300)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    f:SetBackdropColor(0.08, 0.08, 0.08, 0.98)
    f:SetBackdropBorderColor(cr, cg, cb, 1)
    f:SetScript("OnHide", function(self) if _activeSocialPopup == self then _activeSocialPopup = nil end end)
    f.socialKey = social.key
    _activeSocialPopup = f

    -- Title bar (brand-tinted)
    local titleBar = f:CreateTexture(nil, "ARTWORK")
    titleBar:SetPoint("TOPLEFT", 1, -1)
    titleBar:SetPoint("TOPRIGHT", -1, -1)
    titleBar:SetHeight(24)
    titleBar:SetColorTexture(cr * 0.35, cg * 0.35, cb * 0.35, 1)

    local drag = CreateFrame("Frame", nil, f)
    drag:SetAllPoints(titleBar)
    drag:EnableMouse(true)
    drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", function() f:StartMoving() end)
    drag:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local titleIcon = f:CreateTexture(nil, "OVERLAY")
    titleIcon:SetSize(16, 16)
    titleIcon:SetPoint("LEFT", titleBar, "LEFT", 6, 0)
    titleIcon:SetTexture(social.texture)

    local titleText = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    titleText:SetPoint("LEFT", titleIcon, "RIGHT", 6, 0)
    titleText:SetTextColor(1, 1, 1, 1)
    titleText:SetText(social.name)

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetSize(20, 20)
    closeBtn:SetPoint("TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function() f:Hide(); f:SetParent(nil) end)

    -- Label
    local lbl = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("TOPLEFT", 12, -34)
    lbl:SetTextColor(0.8, 0.8, 0.8, 1)
    lbl:SetText(social.label)

    -- Read-only edit box pre-selected for copy
    local boxBg = CreateFrame("Frame", nil, f, "BackdropTemplate")
    boxBg:SetPoint("TOPLEFT", 12, -52)
    boxBg:SetPoint("TOPRIGHT", -12, -52)
    boxBg:SetHeight(24)
    boxBg:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    boxBg:SetBackdropColor(0.04, 0.04, 0.04, 1)
    boxBg:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)

    local editBox = CreateFrame("EditBox", nil, boxBg)
    editBox:SetPoint("LEFT", 6, 0)
    editBox:SetPoint("RIGHT", -6, 0)
    editBox:SetHeight(20)
    editBox:SetAutoFocus(false)
    editBox:SetFontObject(GameFontHighlightSmall)
    editBox:SetText(social.copy)
    editBox:SetCursorPosition(0)
    -- keep it read-only: revert any edit and re-highlight
    editBox:SetScript("OnTextChanged", function(self, userInput)
        if userInput and self:GetText() ~= social.copy then
            self:SetText(social.copy)
            self:HighlightText()
        end
    end)
    editBox:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    editBox:SetScript("OnMouseUp", function(self) self:HighlightText() end)
    editBox:SetScript("OnEscapePressed", function() f:Hide(); f:SetParent(nil) end)
    editBox:SetScript("OnEnterPressed", function(self) self:HighlightText() end)

    -- Hint
    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("BOTTOM", 0, 12)
    hint:SetText(L["Press Ctrl+C to copy, Esc to close"] or "Press Ctrl+C to copy, Esc to close")

    f:Show()
    C_Timer.After(0.05, function()
        editBox:SetFocus()
        editBox:HighlightText()
    end)
    return f
end

-- ── Build the row of social icon buttons at the sidebar bottom ──
local function CreateSocialBar(f)
    local sidebar = f.sidebar
    if not sidebar then return end

    local bar = CreateFrame("Frame", nil, sidebar)
    bar:SetPoint("BOTTOMLEFT", sidebar, "BOTTOMLEFT", 0, 0)
    bar:SetPoint("BOTTOMRIGHT", sidebar, "BOTTOMRIGHT", 0, 0)
    bar:SetHeight(SOCIAL_BAR_H)
    f.socialBar = bar

    -- separator line above the icons
    local line = bar:CreateTexture(nil, "ARTWORK")
    line:SetPoint("TOPLEFT", bar, "TOPLEFT", 10, 0)
    line:SetPoint("TOPRIGHT", bar, "TOPRIGHT", -10, 0)
    line:SetHeight(1)
    line:SetColorTexture(C_BORDER[1], C_BORDER[2], C_BORDER[3], 0.8)

    local count   = #SOCIAL_LINKS
    local spacing = SOCIAL_ICON_SZ + SOCIAL_ICON_GAP
    -- center the row horizontally inside the sidebar
    local startX  = -((count - 1) * spacing) / 2

    for i, social in ipairs(SOCIAL_LINKS) do
        local btn = CreateFrame("Button", nil, bar)
        btn:SetSize(SOCIAL_ICON_SZ, SOCIAL_ICON_SZ)
        btn:SetPoint("CENTER", bar, "CENTER", startX + (i - 1) * spacing, -3)
        btn:RegisterForClicks("AnyUp")

        local icon = btn:CreateTexture(nil, "ARTWORK")
        icon:SetAllPoints()
        icon:SetTexture(social.texture)
        icon:SetVertexColor(1, 1, 1, 0.55)
        btn.icon = icon

        btn:SetScript("OnEnter", function(self)
            self.icon:SetVertexColor(social.color[1], social.color[2], social.color[3], 1)
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(social.name, 1, 1, 1)
            GameTooltip:AddLine(social.copy, social.color[1], social.color[2], social.color[3])
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine(L["Click to copy"] or "Click to copy", 0.7, 0.7, 0.7)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function(self)
            self.icon:SetVertexColor(1, 1, 1, 0.55)
            GameTooltip:Hide()
        end)
        btn:SetScript("OnMouseDown", function(self) self.icon:SetPoint("CENTER", 0, -1) end)
        btn:SetScript("OnMouseUp",   function(self) self.icon:SetPoint("CENTER", 0, 0)  end)
        btn:SetScript("OnClick", function()
            PlaySound(SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION or 856)
            CreateSocialCopyPopup(social)
        end)
    end

    return bar
end

local function BuildFrame()
    if mainFrame then return mainFrame end

    local f = CreateFrame("Frame", "MythicDungeonCastsOptionsFrame", UIParent, "BackdropTemplate")
    local db = DC.db and DC.db.profile
    local sizeKey = (db and db.optionsPanel and db.optionsPanel.windowSize) or "small"
    local sz = WINDOW_SIZES[sizeKey] or WINDOW_SIZES.small
    f:SetSize(sz.w, sz.h)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetFrameLevel(100)
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8X8",
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    local db = DC.db and DC.db.profile
    local alpha = (db and db.optionsPanel and db.optionsPanel.windowOpacity) or 0.95
    f:SetBackdropColor(C_BG[1], C_BG[2], C_BG[3], alpha)
    f:SetBackdropBorderColor(C_BORDER[1], C_BORDER[2], C_BORDER[3], C_BORDER[4])
    f:Hide()

    table.insert(UISpecialFrames, "MythicDungeonCastsOptionsFrame")

    local titleBg = f:CreateTexture(nil, "ARTWORK")
    titleBg:SetPoint("TOPLEFT", 1, -1)
    titleBg:SetPoint("TOPRIGHT", -1, -1)
    titleBg:SetHeight(TITLE_H)
    titleBg:SetColorTexture(C_TITLE_BG[1], C_TITLE_BG[2], C_TITLE_BG[3], alpha)
    f.titleBg = titleBg

    local titleBorder = f:CreateTexture(nil, "ARTWORK", nil, 1)
    titleBorder:SetPoint("TOPLEFT", titleBg, "BOTTOMLEFT", 0, 0)
    titleBorder:SetPoint("TOPRIGHT", titleBg, "BOTTOMRIGHT", 0, 0)
    titleBorder:SetHeight(1)
    titleBorder:SetColorTexture(C_BORDER[1], C_BORDER[2], C_BORDER[3], C_BORDER[4])

    local drag = CreateFrame("Frame", nil, f)
    drag:SetPoint("TOPLEFT", titleBg)
    drag:SetPoint("BOTTOMRIGHT", titleBg)
    drag:EnableMouse(true)
    drag:RegisterForDrag("LeftButton")
    drag:SetScript("OnDragStart", function() f:StartMoving() end)
    drag:SetScript("OnDragStop", function() f:StopMovingOrSizing() end)

    local titleIcon = f:CreateTexture(nil, "OVERLAY")
    local iconSz = TITLE_H
    titleIcon:SetSize(iconSz, iconSz)
    titleIcon:SetTexture(4352494)
    titleIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local titleText = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    titleText:SetPoint("CENTER", titleBg, "CENTER", 5, 0)
    titleText:SetTextColor(1, 1, 1, 1)
    titleText:SetText(DISPLAY_NAME)
    f.titleText = titleText

    titleIcon:SetPoint("RIGHT", titleText, "LEFT", -4, 0)

    local byLine = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    byLine:SetPoint("LEFT", titleText, "RIGHT", 6, 0)
    byLine:SetTextColor(1, 0.82, 0, 1)
    byLine:SetText("by Abiecherry")
    f.byLine = byLine

    local closeBtn = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    closeBtn:SetSize(22, 22)
    closeBtn:SetPoint("TOPRIGHT", -2, -4)
    closeBtn:SetScript("OnClick", function() f:Hide() end)

    local sidebar = CreateFrame("Frame", nil, f)
    sidebar:SetPoint("TOPLEFT", 1, -(TITLE_H + 1))
    sidebar:SetPoint("BOTTOMLEFT", 1, 1)
    sidebar:SetWidth(SIDEBAR_W)

    local sidebarBg = sidebar:CreateTexture(nil, "BACKGROUND")
    sidebarBg:SetAllPoints()
    sidebarBg:SetColorTexture(C_SIDEBAR[1], C_SIDEBAR[2], C_SIDEBAR[3], alpha)
    f.sidebar = sidebar
    f.sidebarBg = sidebarBg

    local sidebarTopBorder = sidebar:CreateTexture(nil, "ARTWORK", nil, 1)
    sidebarTopBorder:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 0, 0)
    sidebarTopBorder:SetPoint("TOPRIGHT", sidebar, "TOPRIGHT", 0, 0)
    sidebarTopBorder:SetHeight(1)
    sidebarTopBorder:SetColorTexture(C_BORDER[1], C_BORDER[2], C_BORDER[3], C_BORDER[4])

    local sep = f:CreateTexture(nil, "ARTWORK")
    sep:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", 0, 0)
    sep:SetPoint("BOTTOMLEFT", sidebar, "BOTTOMRIGHT", 0, 0)
    sep:SetWidth(1)
    sep:SetColorTexture(C_BORDER[1], C_BORDER[2], C_BORDER[3], C_BORDER[4])

    local content = CreateFrame("Frame", nil, f)
    content:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", CONTENT_PAD, -CONTENT_PAD)
    content:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -CONTENT_PAD, CONTENT_PAD)
    f.contentArea = content

    -- social icon row pinned to the bottom of the sidebar
    CreateSocialBar(f)

    f:SetScript("OnHide", function()
        ReleaseContent()
        selectedKey = nil
        if DC.db and DC.db.profile then
            local profile = DC.db.profile
            if profile.preview then
                profile.preview = false
                local addon = _G["MythicDungeonCasts"]
                if addon and addon._togglePreview then
                    addon._togglePreview(false)
                end
            end
        end
    end)

    local verText = f:CreateFontString(nil, "OVERLAY")
    local expPath = LSM:Fetch("font", "Expressway Semi Bold")
                 or LSM:Fetch("font", "Expressway Regular")
                 or [[Fonts\FRIZQT__.TTF]]
    verText:SetFont(expPath, 10, "")
    verText:SetTextColor(1, 1, 1, 0.6)
    verText:SetPoint("LEFT", titleBg, "LEFT", 8, 0)
    verText:SetText("v" .. (DC._version or "12.1.6"))
    f.versionText = verText

    mainFrame = f
    return f
end

local function CreateNavItem(parent, index, labelText, onClick)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetHeight(NAV_ITEM_H)
    btn:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(NAV_PAD_TOP + (index - 1) * (NAV_ITEM_H + 1)))
    btn:SetPoint("RIGHT", parent, "RIGHT", 0, 0)

    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0)
    btn.bg = bg

    local label = btn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    label:SetPoint("LEFT", NAV_PAD_LEFT, 0)
    label:SetTextColor(C_NAV[1], C_NAV[2], C_NAV[3], C_NAV[4])
    label:SetText(labelText)
    label:SetJustifyH("LEFT")
    btn.label = label

    btn:SetScript("OnEnter", function(self)
        if selectedKey ~= self._key then
            bg:SetColorTexture(C_HOVER[1], C_HOVER[2], C_HOVER[3], C_HOVER[4])
        end
    end)
    btn:SetScript("OnLeave", function(self)
        if selectedKey ~= self._key then
            bg:SetColorTexture(0, 0, 0, 0)
        end
    end)
    btn:SetScript("OnClick", function() onClick() end)

    return btn
end

function DC:OpenOptionsPanel()
    local options = self._dcOptionsTable
    if not options then return end

    if SettingsPanel and SettingsPanel:IsShown() then
        HideUIPanel(SettingsPanel)
    end

    local f = BuildFrame()
    ApplyFrameOpacity()
    ApplyWindowSize()

    for _, btn in pairs(navButtons) do
        btn:Hide()
        btn:SetParent(nil)
    end
    navButtons = {}
    selectedKey = nil
    ReleaseContent()

    local groups = {}
    for _, entry in ipairs(sortedOptions(options)) do
        if entry.tbl.type == "group" and not isHidden(entry.tbl) then
            groups[#groups + 1] = entry
        end
    end

    local navIndex = 0

    for _, entry in ipairs(groups) do
        navIndex = navIndex + 1
        local btn = CreateNavItem(f.sidebar, navIndex, getName(entry.tbl), function()
            SelectCategory(entry.key, entry.tbl, options, ADDON_NAME)
        end)
        btn._key = entry.key
        navButtons[entry.key] = btn
    end

    navIndex = navIndex + 1
    local sBtn = CreateNavItem(f.sidebar, navIndex, L["Settings"], function()
        RenderSettingsTab()
    end)
    sBtn._key = "__settings__"
    navButtons["__settings__"] = sBtn

    navIndex = navIndex + 1
    local pBtn = CreateNavItem(f.sidebar, navIndex, L["Profiles"] or "Profiles", function()
        RenderProfilesTab()
    end)
    pBtn._key = "__profiles__"
    navButtons["__profiles__"] = pBtn

    ApplyFontToAllNavButtons()

    if groups[1] then
        SelectCategory(groups[1].key, groups[1].tbl, options, ADDON_NAME)
    end

    f:Show()
end

function DC:CloseOptionsPanel()
    if mainFrame then mainFrame:Hide() end
end

function DC:ToggleOptionsPanel()
    if mainFrame and mainFrame:IsShown() then
        mainFrame:Hide()
    else
        self:OpenOptionsPanel()
    end
end
