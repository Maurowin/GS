
local ADDON_NAME    = "MythicDungeonCasts"
local DISPLAY_NAME  = "Mythic Dungeon Casts"
local VERSION       = "12.2.4"

local MythicDungeonCasts = LibStub("MDC-AceAddon-3.0"):NewAddon(ADDON_NAME)
_G[ADDON_NAME] = MythicDungeonCasts

local AceDB     = LibStub("MDC-AceDB-3.0")
local AceConfig = LibStub("MDC-AceConfig-3.0")
local LSM       = LibStub("LibSharedMedia-3.0")
local LCG       = LibStub("LibCustomGlow-1.0", true)

LSM:Register("statusbar", "MDC Solid",      [[Interface\Buttons\WHITE8X8]])
LSM:Register("statusbar", "MDC Smooth",     [[Interface\TargetingFrame\UI-StatusBar]])
LSM:Register("statusbar", "MDC Blizzard",   [[Interface\RaidFrame\Raid-Bar-Hp-Fill]])
LSM:Register("statusbar", "MDC Raid",       [[Interface\RaidFrame\Raid-Bar-Resource-Fill]])
LSM:Register("statusbar", "MDC Minimalist", [[Interface\PaperDollInfoFrame\UI-Character-Skills-Bar]])
LSM:Register("statusbar", "MDC Clean",      [[Interface\AddOns\MythicDungeonCasts\textures\clean]])
LSM:Register("statusbar", "MDC Flat",       [[Interface\AddOns\MythicDungeonCasts\textures\flat]])
LSM:Register("statusbar", "MDC Melli",      [[Interface\AddOns\MythicDungeonCasts\textures\melli]])
LSM:Register("statusbar", "MDC Ruben",      [[Interface\AddOns\MythicDungeonCasts\textures\ruben]])
LSM:Register("statusbar", "MDC Gloss",      [[Interface\AddOns\MythicDungeonCasts\textures\gloss]])
LSM:Register("statusbar", "MDC Gradient",   [[Interface\AddOns\MythicDungeonCasts\textures\gradient]])


LSM:Register("border",    "MDC Solid",      [[Interface\Buttons\WHITE8X8]])

LSM:Register("font", "Expressway Regular",    [[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Regular.ttf]])
LSM:Register("font", "Expressway Extra Light",[[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Extra_Light.ttf]])
LSM:Register("font", "Expressway Light",      [[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Light.ttf]])
LSM:Register("font", "Expressway Semi Bold",  [[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Semi_Bold.ttf]])
LSM:Register("font", "Expressway Extra Bold", [[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Extra_Bold.ttf]])
LSM:Register("font", "Expressway Italic",     [[Interface\AddOns\MythicDungeonCasts\fonts\Expressway_Italic.otf]])

local L = _G["MDC_Locale"] or setmetatable({}, { __index = function(_, k) return k end })

local CreateFrame          = CreateFrame
local UIParent             = UIParent
local UnitName             = UnitName
local UnitExists           = UnitExists
local UnitCanAttack        = UnitCanAttack
local UnitAffectingCombat  = UnitAffectingCombat
local UnitIsUnit           = UnitIsUnit
local PlayerIsSpellTarget  = PlayerIsSpellTarget
local UnitCastingInfo      = UnitCastingInfo
local UnitChannelInfo      = UnitChannelInfo
local UnitCastingDuration  = UnitCastingDuration
local UnitChannelDuration  = UnitChannelDuration
local UnitClass            = UnitClass
local UnitSpellTargetName  = UnitSpellTargetName
local UnitSpellTargetClass = UnitSpellTargetClass
local UnitShouldDisplaySpellTargetName = UnitShouldDisplaySpellTargetName
local GetRaidTargetIndex   = GetRaidTargetIndex
local C_ClassColor         = C_ClassColor
local C_Timer              = C_Timer
local CreateColor          = CreateColor
local GetInstanceInfo      = GetInstanceInfo
local string, math, table  = string, math, table
local pairs, ipairs, type, tostring = pairs, ipairs, type, tostring

local DEFAULTS = {
    profile = {
        enabled = true, locked = true, preview = false, disableInitMessage = false,
        minimap = { hide = true },
        posX = -527, posY = -12,
        growDirection = "UP", maxBars = 6, spacing = 1,
        showRaidIcon = true, raidIconSize = 30, raidIconX = -1, raidIconY = 0,
        nonInterruptColorR = 1, nonInterruptColorG = 0, nonInterruptColorB = 0, nonInterruptColorA = 1,
        showSpellName = true, showTarget = true, showTimer = true,
        timerNoDecimals = false, decimalsUnder5Only = true, timerAnchor = "RIGHT", removeTimerAnchor = false, autoAnchorTarget = true,
        removeSymbol = false, symbolChoice = "HYPHEN", disableClassColor = false, hideNonInterruptible = false,
        showOnlySelfTargeted = false,
        showSelfAndMechanics = false,
        smoothAnim = false, spellNameClassColor = false, hideSymbolIfNoTarget = true,
        targetColorR = 1, targetColorG = 1, targetColorB = 1, targetColorA = 1,
        textAlign = "LEFT", targetAlign = "CENTER", timerAlign = "RIGHT",
        font_spell  = { font="Expressway Semi Bold", size=14, outline="OUTLINE", shadow=false, shadowX=1, x=2, y=0, r=1, g=1, b=1, a=1 },
        font_target = { font="Expressway Semi Bold", size=14, outline="OUTLINE", shadow=false, shadowX=1, x=2, y=0, r=1, g=1, b=1, a=1 },
        font_timer  = { font="Expressway Semi Bold", size=14, outline="OUTLINE", shadow=false, shadowX=9, x=0, y=0, r=1, g=1, b=1, a=1 },
        barGroup = {
            width=255, height=25, texture="MDC Clean",
            matchIconToBar=true,
            showIcon=true, iconSize=26, iconSide="LEFT",
            showBorder=true, borderTexture="MDC Solid", borderSize=1, borderPadding=1,
            borderColorR=0, borderColorG=0, borderColorB=0, borderColorA=1,
            useTargetClassColor=false,
            barColorR=0.02352941, barColorG=1, barColorB=0.16862745, barColorA=1,
            barBgColorR=0, barBgColorG=0, barBgColorB=0, barBgColorA=0.65,
        },
        optionsPanel = { textFont="Friz Quadrata TT", language="enUS", windowOpacity=0.8, windowSize="medium" },
        tts = {
            enabled = false,
            announceSpell = false,
            announceTarget = false,
            announceBoth = false,
            overlapMode = "stop",
            allowOverlapHeavy = false,
            rate = 0,
            volume = 100,
            voiceID = 0,
        },
        glow = {
            enabled = false,
            glowOnTargeted = false,
            glowOnTarget = false,
            glowOnFocus = false,
            glowOnImportant = false,
            glowOnEnemyTargetingMDC = false,
            glowOnNonTargeted = false,
            glowType = "PIXEL",
            colorR = 1, colorG = 1, colorB = 0, colorA = 1,
            targetColorR = 1, targetColorG = 1, targetColorB = 1, targetColorA = 1,
            focusColorR = 1, focusColorG = 1, focusColorB = 1, focusColorA = 1,
            importantColorR = 1, importantColorG = 0, importantColorB = 0.867, importantColorA = 1,
            enemyTargetColorR = 1, enemyTargetColorG = 0.53, enemyTargetColorB = 0, enemyTargetColorA = 1,
            nonTargetedColorR = 0.4, nonTargetedColorG = 0.8, nonTargetedColorB = 0.9, nonTargetedColorA = 1,
            lines = 1,
            frequency = 0.5,
            thickness = 3,
        },
        advanced = {
            barColorByClassification = false,
            bossColorR        = 1,    bossColorG        = 0.843, bossColorB       = 0.059, bossColorA        = 1,
            rareEliteColorR   = 0.890, rareEliteColorG  = 0,     rareEliteColorB  = 0.686, rareEliteColorA   = 1,
            eliteColorR       = 0,    eliteColorG       = 0.612, eliteColorB      = 1,     eliteColorA       = 1,
            casterColorR      = 0,    casterColorG      = 1,     casterColorB     = 0.702, casterColorA      = 1,
            normalColorR      = 0.867, normalColorG     = 0.294, normalColorB     = 0,     normalColorA      = 1,
            ttsBossOnly       = false,
            ttsEliteOnly      = false,
            ttsCasterOnly     = false,
            colorChanneledCasts = false,
            channeledColorR   = 0.6,  channeledColorG   = 0.4,  channeledColorB   = 1,    channeledColorA   = 1,
            truncateTargetNames = false,
            legacyCombatTracking = false,
        },
    },
}

local db
local anchorFrame
local activeBars    = {}
local usedBarsList  = {}
local barPool       = {}
local previewBars   = {}
local isPreviewing  = false
local areEventsEnabled = false

-- Step curve mapping (remaining-time-in-seconds → decimal-count).
-- We feed this to Duration:EvaluateRemainingDuration so the comparison
-- against the threshold runs natively on the privileged side. Lua only
-- ever sees the curve's output (a small non-secret integer: 0 or 1),
-- never the secret remaining-time value itself. Lazy-initialised so the
-- addon still loads if C_CurveUtil isn't present on the running client.
local _decimalCountCurve
local function GetDecimalCountCurve()
    if _decimalCountCurve ~= nil then return _decimalCountCurve end
    if not (C_CurveUtil and C_CurveUtil.CreateCurve and Enum and Enum.LuaCurveType) then
        _decimalCountCurve = false
        return nil
    end
    local c = C_CurveUtil.CreateCurve()
    c:SetType(Enum.LuaCurveType.Step)
    c:AddPoint(0, 1)
    c:AddPoint(5, 0)
    _decimalCountCurve = c
    return c
end

local MDC_SYMBOL_MAP = {
    HYPHEN       = " -",
    DOT          = " •",
    CROSS        = " +",
    ARROW        = " >",
    DOUBLE_ARROW = " »",
    STAR         = " *",
    SMALL_DOT    = " ·",
    TILDE        = " ~",
    BAR          = " ||",
    SECTION      = " §",
    COLON        = " :",
    SLASH        = " /",
}

local function GetSymbolChoices()
    return {
        HYPHEN       = L["Hyphen-Minus"] .. "  ( - )",
        DOT          = L["Dot"] .. "  ( • )",
        CROSS        = L["Cross"] .. "  ( + )",
        ARROW        = L["Arrow"] .. "  ( > )",
        DOUBLE_ARROW = L["Double Arrow"] .. "  ( » )",
        STAR         = L["Star"] .. "  ( * )",
        SMALL_DOT    = L["Small Dot"] .. "  ( · )",
        TILDE        = L["Tilde"] .. "  ( ~ )",
        BAR          = L["Bar"] .. "  ( || )",
        SECTION      = L["Section"] .. "  ( § )",
        COLON        = L["Colon"] .. "  ( : )",
        SLASH        = L["Slash"] .. "  ( / )",
    }
end

local TogglePreview, RefreshAll, ReLayout, CheckEnvironment, CreateAnchor

local function ApplyFont(fs, cfg)
    if not fs or not cfg then return end
    local path = LSM:Fetch("font", cfg.font or "Expressway Semi Bold")
              or LSM:Fetch("font", "Expressway Semi Bold")
              or [[Fonts\FRIZQT__.TTF]]
    fs:SetFont(path, cfg.size or 14, cfg.outline or "")
    fs:SetTextColor(cfg.r or 1, cfg.g or 1, cfg.b or 1, cfg.a or 1)
    if cfg.shadow then
        fs:SetShadowOffset(cfg.shadowX or 1, -(cfg.shadowX or 1)); fs:SetShadowColor(0,0,0,1)
    else
        fs:SetShadowOffset(0,0); fs:SetShadowColor(0,0,0,0)
    end
end

local function ApplyEnemyTargetGlow(bar, unit)
    if not bar then return end
    local etFrame = bar.EnemyTargetGlowOverlay
    if not etFrame then return end
    local g = db and db.glow
    if not (g and g.glowOnEnemyTargetingMDC) then
        LCG.PixelGlow_Stop(etFrame, "MDC_ENEMYTGT"); LCG.AutoCastGlow_Stop(etFrame, "MDC_ENEMYTGT")
        etFrame:SetAlpha(1); etFrame:Hide()
        return
    end

    -- IMPORTANT: the "targets me" boolean (from PlayerIsSpellTarget) is SECRET
    -- when this runs from the tainted cast-update path -- reading it in Lua (a
    -- plain `if`) throws a taint error. The only safe sink is SetAlphaFromBoolean,
    -- which consumes the secret boolean without us inspecting it. So the glow
    -- frame is shown and animated, and its ALPHA is driven to 1 (targets me) or
    -- 0 (doesn't) by the secret value. The target also resolves slightly after
    -- cast start, so ScheduleEnemyTargetCheck re-runs this on a short delay.
    local hasSpellTarget = UnitShouldDisplaySpellTargetName and UnitShouldDisplaySpellTargetName(unit)
    if not hasSpellTarget then
        LCG.PixelGlow_Stop(etFrame, "MDC_ENEMYTGT"); LCG.AutoCastGlow_Stop(etFrame, "MDC_ENEMYTGT")
        etFrame:Hide()
    else
        local color = {g.enemyTargetColorR, g.enemyTargetColorG, g.enemyTargetColorB, g.enemyTargetColorA}
        etFrame:SetAlpha(0); etFrame:Show()
        if g.glowType == "PIXEL" then
            LCG.PixelGlow_Start(etFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_ENEMYTGT")
        elseif g.glowType == "AUTOCAST" then
            LCG.AutoCastGlow_Start(etFrame, color, 4, g.frequency, nil, 0, 0, "MDC_ENEMYTGT")
        end
        etFrame:SetAlphaFromBoolean(PlayerIsSpellTarget(unit), 1, 0)
    end
end

local _etGen = {}
local function ScheduleEnemyTargetCheck(unit)
    local g = db and db.glow
    if not (g and g.glowOnEnemyTargetingMDC) then return end
    _etGen[unit] = (_etGen[unit] or 0) + 1
    local myGen = _etGen[unit]
    local function run()
        if _etGen[unit] ~= myGen then return end
        local bar = activeBars[unit]
        if bar then ApplyEnemyTargetGlow(bar, unit) end
    end
    C_Timer.After(0.10, run)
    C_Timer.After(0.25, run)
end


local function InitBar(bar)
    bar:SetClampedToScreen(true); bar:SetMinMaxValues(0,1); bar:SetValue(1)
    bar.bg = bar:CreateTexture(nil,"BACKGROUND"); bar.bg:SetAllPoints(true)
    bar.Text           = bar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    bar.TargetNameText = bar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    bar.TimerText      = bar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    bar.IconFrame = CreateFrame("Frame", nil, bar)
    bar.IconFrame:SetFrameLevel(bar:GetFrameLevel() + 5)
    bar.Icon           = bar.IconFrame:CreateTexture(nil,"OVERLAY")
    bar.Icon:SetTexCoord(0.08,0.92,0.08,0.92)
    local ri = bar:CreateTexture(nil,"OVERLAY")
    ri:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons"); ri:Hide()
    bar.RaidIcon = ri
    bar.GlowOverlay = CreateFrame("Frame", nil, bar)
    bar.GlowOverlay:SetFrameLevel(bar:GetFrameLevel() + 1)
    bar.ImportantGlowOverlay = CreateFrame("Frame", nil, bar)
    bar.ImportantGlowOverlay:SetFrameLevel(bar:GetFrameLevel() + 2)
    bar.EnemyTargetGlowOverlay = CreateFrame("Frame", nil, bar)
    bar.EnemyTargetGlowOverlay:SetFrameLevel(bar:GetFrameLevel() + 3)
    bar.NonTargetedGlowOverlay = CreateFrame("Frame", nil, bar)
    bar.NonTargetedGlowOverlay:SetFrameLevel(bar:GetFrameLevel() + 4)

end

local function AcquireBar()
    if not anchorFrame then return nil end
    local bar
    if #barPool > 0 then bar = table.remove(barPool); bar:SetParent(anchorFrame)
    else bar = CreateFrame("StatusBar", nil, anchorFrame); InitBar(bar) end
    bar._isPreview = false; bar._isNotInt = false; bar._previewRaidIndex = 1
    if bar.RaidIcon then bar.RaidIcon:Hide() end
    bar:Show()
    if db and db.smoothAnim then
        bar:SetAlpha(0)
        if not bar._fadeIn then
            bar._fadeIn = bar:CreateAnimationGroup()
            bar._fadeIn:SetToFinalAlpha(true)
            local a = bar._fadeIn:CreateAnimation("Alpha")
            a:SetFromAlpha(0); a:SetToAlpha(1); a:SetDuration(0.2); a:SetSmoothing("OUT")
            bar._fadeIn:SetScript("OnFinished", function()
                bar:SetAlpha(1)
                if bar.bg and db and db.barGroup then
                    local g = db.barGroup
                    bar.bg:SetVertexColor(g.barBgColorR or 0, g.barBgColorG or 0, g.barBgColorB or 0, g.barBgColorA or 1)
                end
            end)
        end
        bar._fadeIn:Stop(); bar._fadeIn:Play()
    else
        bar:SetAlpha(1)
    end
    return bar
end

local function ReleaseBar(bar)
    if not bar then return end
    if db and db.smoothAnim and bar:IsVisible() then
        if bar._fadeIn then bar._fadeIn:Stop() end
        if not bar._fadeOut then
            bar._fadeOut = bar:CreateAnimationGroup()
            local a = bar._fadeOut:CreateAnimation("Alpha")
            a:SetFromAlpha(1); a:SetToAlpha(0); a:SetDuration(0.2); a:SetSmoothing("IN")
            bar._fadeOut:SetScript("OnFinished", function()
                bar:SetAlpha(1); bar:Hide(); bar:ClearAllPoints()
                table.insert(barPool, bar)
            end)
        end
        bar._fadeOut:Stop(); bar._fadeOut:Play()
        bar:SetScript("OnUpdate",nil)
        bar._isPreview = false; bar._isNotInt = false; bar._previewStart = nil; bar._previewDuration = nil
        if bar.Text then bar.Text:SetText("") end
        if bar.TargetNameText then bar.TargetNameText:SetText(""); bar.TargetNameText:Hide() end
        if bar.TimerText then bar.TimerText:SetText(""); bar.TimerText:Hide() end
        if bar.RaidIcon then bar.RaidIcon:Hide() end
        if bar._borderEdges then bar._borderEdges.holder:Hide() end
        if LCG then
            local glowFrame = bar.GlowOverlay or bar
            LCG.PixelGlow_Stop(glowFrame, "MDC_TGT"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_TGT"); LCG.ButtonGlow_Stop(glowFrame)
            LCG.PixelGlow_Stop(glowFrame, "MDC_MYTARGET"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_MYTARGET")
            LCG.PixelGlow_Stop(glowFrame, "MDC_FOCUS"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_FOCUS")
            if bar.ImportantGlowOverlay then
                LCG.PixelGlow_Stop(bar.ImportantGlowOverlay, "MDC_IMP"); LCG.AutoCastGlow_Stop(bar.ImportantGlowOverlay, "MDC_IMP")
                bar.ImportantGlowOverlay:Hide()
            end
            if bar.EnemyTargetGlowOverlay then
                LCG.PixelGlow_Stop(bar.EnemyTargetGlowOverlay, "MDC_ENEMYTGT"); LCG.AutoCastGlow_Stop(bar.EnemyTargetGlowOverlay, "MDC_ENEMYTGT")
                bar.EnemyTargetGlowOverlay:SetAlpha(1)
                bar.EnemyTargetGlowOverlay:Hide()
            end
            if bar.NonTargetedGlowOverlay then
                LCG.PixelGlow_Stop(bar.NonTargetedGlowOverlay, "MDC_NONTGT"); LCG.AutoCastGlow_Stop(bar.NonTargetedGlowOverlay, "MDC_NONTGT")
                bar.NonTargetedGlowOverlay:SetAlpha(1)
                bar.NonTargetedGlowOverlay:Hide()
            end
        end
        return
    end
    bar:SetScript("OnUpdate",nil); bar:Hide(); bar:ClearAllPoints()
    bar._isPreview = false; bar._isNotInt = false; bar._previewStart = nil; bar._previewDuration = nil
    if bar.Text then bar.Text:SetText("") end
    if bar.TargetNameText then bar.TargetNameText:SetText(""); bar.TargetNameText:Hide() end
    if bar.TimerText then bar.TimerText:SetText(""); bar.TimerText:Hide() end
    if bar.RaidIcon then bar.RaidIcon:Hide() end
    if bar._borderEdges then bar._borderEdges.holder:Hide() end
    if LCG then
        local glowFrame = bar.GlowOverlay or bar
        LCG.PixelGlow_Stop(glowFrame, "MDC_TGT"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_TGT"); LCG.ButtonGlow_Stop(glowFrame)
        LCG.PixelGlow_Stop(glowFrame, "MDC_MYTARGET"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_MYTARGET")
        LCG.PixelGlow_Stop(glowFrame, "MDC_FOCUS"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_FOCUS")
        if bar.ImportantGlowOverlay then
            LCG.PixelGlow_Stop(bar.ImportantGlowOverlay, "MDC_IMP"); LCG.AutoCastGlow_Stop(bar.ImportantGlowOverlay, "MDC_IMP")
            bar.ImportantGlowOverlay:Hide()
        end
        if bar.EnemyTargetGlowOverlay then
            LCG.PixelGlow_Stop(bar.EnemyTargetGlowOverlay, "MDC_ENEMYTGT"); LCG.AutoCastGlow_Stop(bar.EnemyTargetGlowOverlay, "MDC_ENEMYTGT")
            bar.EnemyTargetGlowOverlay:SetAlpha(1)
            bar.EnemyTargetGlowOverlay:Hide()
        end
        if bar.NonTargetedGlowOverlay then
            LCG.PixelGlow_Stop(bar.NonTargetedGlowOverlay, "MDC_NONTGT"); LCG.AutoCastGlow_Stop(bar.NonTargetedGlowOverlay, "MDC_NONTGT")
            bar.NonTargetedGlowOverlay:SetAlpha(1)
            bar.NonTargetedGlowOverlay:Hide()
        end
    end
    table.insert(barPool, bar)
end


-- Compute and apply the target-name truncation width so the name truncates
-- exactly when it reaches the bar's end. Called from UpdateBarVisuals and
-- again after the spell name is set (the spell-name width is only known then,
-- and the auto-anchor case depends on it). The spell name and anchor offsets
-- are non-secret, so measuring them is taint-safe; the target name itself is
-- never measured -- the engine clips it via SetWidth.
local function ApplyTargetNameWidth(bar)
    if not bar or not bar.TargetNameText then return end
    local p = db; if not p then return end
    bar.TargetNameText:SetWordWrap(false)
    -- Truncation is done purely via anchors: when truncation is on, the
    -- FontString's far edge is pinned so its width is defined by the anchor
    -- span (start-of-name .. far edge). The engine clips + ellipsizes when the
    -- text overflows that span. We never measure the name in Lua (it's secret
    -- on live casts), so this is taint-safe. The far edge is pinned to the
    -- TIMER's near edge when the timer sits on that same side -- otherwise the
    -- name would run under the timer before truncating -- and to the bar edge
    -- when there is no timer in the way.
    bar.TargetNameText:SetWidth(0)
    if not (p.advanced and p.advanced.truncateTargetNames) then
        return
    end

    local timerShown = p.showTimer and bar.TimerText
    local timerSide = (p.removeTimerAnchor and "NONE") or (p.timerAnchor or "NONE")
    if timerSide == "NONE" then timerSide = p.timerAlign or "RIGHT" end
    local gap = 4

    local farSide
    if p.autoAnchorTarget then
        farSide = "RIGHT"
    else
        local ta = p.targetAlign or "LEFT"
        if ta == "LEFT" then farSide = "RIGHT"
        elseif ta == "RIGHT" then farSide = "LEFT"
        else farSide = nil end
    end
    if not farSide then return end

    if timerShown and timerSide == farSide then
        if farSide == "RIGHT" then
            bar.TargetNameText:SetPoint("RIGHT", bar.TimerText, "LEFT", -gap, 0)
        else
            bar.TargetNameText:SetPoint("LEFT", bar.TimerText, "RIGHT", gap, 0)
        end
    else
        if farSide == "RIGHT" then
            bar.TargetNameText:SetPoint("RIGHT", bar, "RIGHT", -gap, 0)
        else
            bar.TargetNameText:SetPoint("LEFT", bar, "LEFT", gap, 0)
        end
    end
end


local function UpdateBarVisuals(bar)
    local p = db; local group = p.barGroup
    local W, H = group.width or 255, group.height or 25
    bar:SetSize(W, H)
    for _, ov in ipairs({ bar.GlowOverlay, bar.ImportantGlowOverlay,
                          bar.EnemyTargetGlowOverlay, bar.NonTargetedGlowOverlay }) do
        if ov then
            ov:ClearAllPoints()
            ov:SetSize(W, H)
            ov:SetPoint("CENTER", bar, "CENTER")
        end
    end


    local tex = LSM:Fetch("statusbar", group.texture) or "Interface\\Buttons\\WHITE8X8"
    if bar.bg then bar.bg:SetTexture(tex); bar.bg:SetVertexColor(group.barBgColorR or 0, group.barBgColorG or 0, group.barBgColorB or 0, group.barBgColorA or 1) end
    bar:SetStatusBarTexture(tex)

    if bar._isPreview then
        local sbTex = bar:GetStatusBarTexture()
        if sbTex then
            local intC  = CreateColor(p.nonInterruptColorR, p.nonInterruptColorG, p.nonInterruptColorB, p.nonInterruptColorA)
            local normC = CreateColor(group.barColorR or 0.02, group.barColorG or 1, group.barColorB or 0.17, group.barColorA or 1)
            if group.useTargetClassColor then
                local _, cls = UnitClass("player")
                if cls then local c = C_ClassColor.GetClassColor(cls); if c then
                    local cc = CreateColor(c.r, c.g, c.b, 1)
                    normC = cc; intC = cc
                end end
            end
            sbTex:SetVertexColorFromBoolean(bar._isNotInt, intC, normC)
        end
    end

    local effIconSize = group.iconSize or 26
    if group.matchIconToBar then effIconSize = H end
    local iconShown = group.showIcon
    local iconExtra = iconShown and effIconSize or 0
    local iconOnLeft = string.upper(tostring(group.iconSide or "LEFT")) == "LEFT"

    local edgeTex = group.showBorder and group.borderTexture and group.borderTexture ~= "None" and LSM:Fetch("border", group.borderTexture) or nil
    if edgeTex then
        if not bar._borderEdges then
            local lvl = bar:GetFrameLevel() + 6
            local holder = CreateFrame("Frame", nil, bar, "BackdropTemplate")
            holder:SetFrameLevel(lvl)
            local sep = holder:CreateTexture(nil, "OVERLAY")
            bar._borderEdges = { holder = holder, sep = sep }
        end
        local e = bar._borderEdges
        local pad = group.borderPadding or 1
        local bsz = group.borderSize or 1
        local r, g, b, a = group.borderColorR or 0, group.borderColorG or 0, group.borderColorB or 0, group.borderColorA or 1
        local barW = W
        local bw = barW + iconExtra + pad * 2
        local bh = H + pad * 2
        e.holder:ClearAllPoints(); e.holder:SetSize(bw, bh)
        if iconExtra > 0 then
            if iconOnLeft then
                e.holder:SetPoint("RIGHT", bar, "RIGHT", pad, 0)
            else
                e.holder:SetPoint("LEFT", bar, "LEFT", -pad, 0)
            end
        else
            e.holder:SetPoint("CENTER", bar, "CENTER", 0, 0)
        end
        e.holder:SetBackdrop(nil)
        e.holder:SetBackdrop({ edgeFile = edgeTex, edgeSize = bsz })
        e.holder:SetBackdropBorderColor(r, g, b, a)
        if iconExtra > 0 then
            local seamX = iconOnLeft and (pad + iconExtra) or (pad + barW)
            e.sep:SetTexture(edgeTex); e.sep:SetVertexColor(r, g, b, a)
            e.sep:SetDrawLayer("OVERLAY", 7)
            e.sep:ClearAllPoints()
            e.sep:SetPoint("TOP", e.holder, "TOPLEFT", seamX, 0)
            e.sep:SetPoint("BOTTOM", e.holder, "BOTTOMLEFT", seamX, 0)
            e.sep:SetWidth(bsz)
            e.sep:Show()
        else
            e.sep:Hide()
        end
        e.holder:Show()
    else if bar._borderEdges then bar._borderEdges.holder:Hide() end end

    ApplyFont(bar.Text, p.font_spell)
    bar.Text:ClearAllPoints(); bar.Text:SetPoint(p.textAlign, bar, p.textAlign, p.font_spell.x or 2, p.font_spell.y or 0)
    bar.Text:SetJustifyH(p.textAlign); bar.Text:SetShown(p.showSpellName)

    ApplyFont(bar.TargetNameText, p.font_target)
    bar.TargetNameText:ClearAllPoints()
    if p.autoAnchorTarget then
        bar.TargetNameText:SetPoint("LEFT", bar.Text, "RIGHT", 2, 0); bar.TargetNameText:SetJustifyH("LEFT")
    else
        bar.TargetNameText:SetPoint(p.targetAlign, bar, p.targetAlign, p.font_target.x or 2, p.font_target.y or 0); bar.TargetNameText:SetJustifyH(p.targetAlign)
    end
    -- Truncate Long Target Names: ApplyTargetNameWidth pins the name's far
    -- edge to the bar edge so it clips at the bar end (anchor-based, taint-safe).
    ApplyTargetNameWidth(bar)
    bar.TargetNameText:SetShown(p.showTarget)
    if bar._isPreview then
        if p.disableClassColor then
            bar.TargetNameText:SetTextColor(p.targetColorR or 1, p.targetColorG or 1, p.targetColorB or 1, p.targetColorA or 1)
        else
            local _, cls = UnitClass("player")
            if cls then local c = C_ClassColor.GetClassColor(cls); if c then bar.TargetNameText:SetTextColor(c.r,c.g,c.b,1) end end
        end
    end

    ApplyFont(bar.TimerText, p.font_timer)
    bar.TimerText:ClearAllPoints()
    local ta = (p.removeTimerAnchor and "NONE") or (p.timerAnchor or "NONE")
    if ta == "RIGHT" then bar.TimerText:SetPoint("RIGHT",bar,"RIGHT",-2,0); bar.TimerText:SetJustifyH("RIGHT")
    elseif ta == "LEFT" then bar.TimerText:SetPoint("LEFT",bar,"LEFT",2,0); bar.TimerText:SetJustifyH("LEFT")
    elseif ta == "TOP" then bar.TimerText:SetPoint("TOP",bar,"TOP",0,0); bar.TimerText:SetJustifyH("CENTER")
    elseif ta == "BOTTOM" then bar.TimerText:SetPoint("BOTTOM",bar,"BOTTOM",0,0); bar.TimerText:SetJustifyH("CENTER")
    else bar.TimerText:SetPoint(p.timerAlign, bar, p.timerAlign, p.font_timer.x or 0, p.font_timer.y or 0); bar.TimerText:SetJustifyH(p.timerAlign) end
    bar.TimerText:SetShown(p.showTimer)

    bar.Icon:SetSize(effIconSize, effIconSize); bar.Icon:ClearAllPoints()
    if bar.IconFrame then
        bar.IconFrame:ClearAllPoints()
        bar.IconFrame:SetSize(effIconSize, effIconSize)
        if iconOnLeft then
            bar.IconFrame:SetPoint("RIGHT", bar, "LEFT", 0, 0)
        else
            bar.IconFrame:SetPoint("LEFT", bar, "RIGHT", 0, 0)
        end
        bar.Icon:SetPoint("CENTER", bar.IconFrame, "CENTER", 0, 0)
    else
        if iconOnLeft then bar.Icon:SetPoint("RIGHT", bar, "LEFT", 0, 0)
        else bar.Icon:SetPoint("LEFT", bar, "RIGHT", 0, 0) end
    end
    bar.Icon:SetShown(group.showIcon); bar.Icon:SetTexCoord(0.08,0.92,0.08,0.92)

    bar.RaidIcon:SetSize(p.raidIconSize or 30, p.raidIconSize or 30); bar.RaidIcon:ClearAllPoints()
    bar.RaidIcon:SetPoint("RIGHT", bar.Icon, "LEFT", p.raidIconX or -1, p.raidIconY or 0)
    if bar._isPreview then
        if p.showRaidIcon then bar.RaidIcon:Show(); bar.RaidIcon:SetSpriteSheetCell(bar._previewRaidIndex or 1, 4, 4)
        else bar.RaidIcon:Hide() end
    else if not p.showRaidIcon then bar.RaidIcon:Hide() end end
end

function ReLayout()
    if not anchorFrame then return end
    local group = db.barGroup; local height = group.height or 25; local spacing = db.spacing or 1
    local list = isPreviewing and previewBars or usedBarsList
    local growUp = (db.growDirection == "UP"); local maxLimit = db.maxBars or 6

    local previewDraggable = isPreviewing and (not db.locked)
    anchorFrame:SetSize(group.width or 255, 20)
    local visible = 0
    for i, bar in ipairs(list) do
        if i <= maxLimit then
            visible = visible + 1; bar:ClearAllPoints(); bar:EnableMouse(previewDraggable)
            local yOff = (i-1) * (height + spacing)
            if growUp then bar:SetPoint("BOTTOM", anchorFrame, "CENTER", 0, yOff)
            else bar:SetPoint("TOP", anchorFrame, "CENTER", 0, -yOff) end
            bar:Show()
        else bar:Hide() end
    end

    anchorFrame:ClearAllPoints()
    anchorFrame:SetPoint("CENTER", UIParent, "CENTER", db.posX or 0, db.posY or 0)
end

local function ApplyLockState(forceUnlocked)
    if not anchorFrame then return end
    local unlocked = forceUnlocked or (not db.locked)
    local draggable = unlocked and isPreviewing
    for _, bar in ipairs(previewBars) do
        bar:EnableMouse(draggable)
    end
end

local function SaveAnchorPosition()
    if not anchorFrame then return end
    local sx, sy = anchorFrame:GetCenter(); if not sx then return end
    local tx, ty = UIParent:GetCenter()
    local ts, ms = UIParent:GetEffectiveScale(), anchorFrame:GetEffectiveScale()
    db.posX = math.floor((sx*ms - tx*ts) / ms); db.posY = math.floor((sy*ms - ty*ts) / ms)
end

local function StartPreviewDrag()
    if db.locked or not anchorFrame then return end
    anchorFrame.isMoving = true
    anchorFrame:StartMoving()
end
local function StopPreviewDrag()
    if anchorFrame and anchorFrame.isMoving then
        anchorFrame.isMoving = false
        anchorFrame:StopMovingOrSizing()
        SaveAnchorPosition()
        ReLayout()
    end
end

function RefreshAll()
    if isPreviewing then TogglePreview(false); TogglePreview(true)
    else for _, bar in pairs(activeBars) do UpdateBarVisuals(bar) end end
    ReLayout(); ApplyLockState(isPreviewing or nil)
end

function TogglePreview(enable)
    isPreviewing = enable
    if not db then return end
    if not anchorFrame then CreateAnchor() end
    if not anchorFrame then return end

    if enable then
        ApplyLockState(true)
        for _, bar in pairs(activeBars) do bar:Hide() end
        for i = #previewBars, 1, -1 do ReleaseBar(previewBars[i]); table.remove(previewBars, i) end

        local intC  = CreateColor(db.nonInterruptColorR, db.nonInterruptColorG, db.nonInterruptColorB, db.nonInterruptColorA)
        local normC = CreateColor(db.barGroup.barColorR or 0.02, db.barGroup.barColorG or 1, db.barGroup.barColorB or 0.17, db.barGroup.barColorA or 1)
        if db.barGroup.useTargetClassColor then
            local _, cls = UnitClass("player")
            if cls then local c = C_ClassColor.GetClassColor(cls); if c then
                local cc = CreateColor(c.r, c.g, c.b, 1)
                normC = cc; intC = cc
            end end
        end

        local PREVIEW_BAR_COUNT = 5

        for i = 1, PREVIEW_BAR_COUNT do
            local bar = AcquireBar(); if not bar then break end
            bar._isPreview = true; bar._previewRaidIndex = (i-1)%8+1; bar._isNotInt = (i%2==1)
            bar._isPreviewChannel = (i == 4)
            bar._isPreviewNonTargeted = (i == 5)
            if bar._isPreviewChannel then bar._isNotInt = false end
            if bar._isPreviewNonTargeted then bar._isNotInt = true end

            UpdateBarVisuals(bar)

            local spellName = "Frostbolt"
            local iconID = 135846
            if bar._isPreviewChannel then
                spellName = "Ray of Frost"
                iconID = 1698700
            elseif bar._isPreviewNonTargeted then
                spellName = "Glacial Spike"
                iconID = 1698699
            end
            local symbolSuffix = ""
            if not db.removeSymbol then
                if bar._isPreviewNonTargeted and db.hideSymbolIfNoTarget then
                    symbolSuffix = ""
                else
                    symbolSuffix = MDC_SYMBOL_MAP[db.symbolChoice] or " -"
                end
            end
            bar.Text:SetText(spellName .. symbolSuffix)
            bar.Icon:SetTexture(iconID)

            if db.spellNameClassColor then
                local _, playerCls = UnitClass("player")
                if playerCls and C_ClassColor then
                    local cc = C_ClassColor.GetClassColor(playerCls)
                    if cc then bar.Text:SetTextColor(cc.r, cc.g, cc.b, 1) end
                end
            else
                bar.Text:SetTextColor(db.font_spell.r or 1, db.font_spell.g or 1, db.font_spell.b or 1, db.font_spell.a or 1)
            end

            local duration = 5
            if bar._isPreviewChannel then duration = 30
            elseif bar._isPreviewNonTargeted then duration = 8 end
            local offset = (i - 1) * (5 / PREVIEW_BAR_COUNT)
            bar._previewStart = GetTime() - offset
            bar._previewDuration = duration
            bar:SetMinMaxValues(0, duration)
            bar:SetValue(bar._isPreviewChannel and (duration - offset) or offset)

            local sbTex = bar:GetStatusBarTexture()
            if sbTex then
                local localIntC, localNormC = intC, normC
                if bar._isPreviewChannel and db.advanced and db.advanced.colorChanneledCasts then
                    local adv = db.advanced
                    local cc = CreateColor(adv.channeledColorR, adv.channeledColorG, adv.channeledColorB, adv.channeledColorA)
                    localIntC = cc; localNormC = cc
                end
                sbTex:SetVertexColorFromBoolean(bar._isNotInt, localIntC, localNormC)
            end
            if db.showOnlySelfTargeted then
                local targetsPlayer = not (i == 1 or i == 2 or i == 4 or bar._isPreviewNonTargeted)
                local a = targetsPlayer and 1 or 0
                bar:SetAlpha(a)
                if bar.Icon then bar.Icon:SetAlpha(a) end
            elseif db.showSelfAndMechanics then
                local show
                if bar._isPreviewNonTargeted then
                    show = bar._isNotInt            -- untargeted: only non-interruptible
                else
                    show = not (i == 1 or i == 2 or i == 4)  -- targeted: only at player
                end
                local a = show and 1 or 0
                bar:SetAlpha(a)
                if bar.Icon then bar.Icon:SetAlpha(a) end
            elseif db.hideNonInterruptible and bar._isNotInt then
                bar:SetAlpha(0)
                if bar.Icon then bar.Icon:SetAlpha(0) end
            else
                bar:SetAlpha(1)
                if bar.Icon then bar.Icon:SetAlpha(1) end
            end
            if bar.TargetNameText then
                if bar._isPreviewNonTargeted then
                    bar.TargetNameText:SetText("")
                    bar.TargetNameText:Hide()
                elseif db.showTarget then
                    if i == 1 then
                        bar.TargetNameText:SetText("Zyrsin")
                        bar.TargetNameText:SetTextColor(0x33/255, 0x93/255, 0x7F/255, 1)
                    elseif i == 2 then
                        bar.TargetNameText:SetText("Arxes")
                        bar.TargetNameText:SetTextColor(0x3F/255, 0xC7/255, 0xEB/255, 1)
                    elseif i == 4 then
                        bar.TargetNameText:SetText("Canexx")
                        bar.TargetNameText:SetTextColor(0xFF/255, 0x7C/255, 0x0A/255, 1)
                    else
                        bar.TargetNameText:SetText(UnitName("player") or "Player")
                    end
                    bar.TargetNameText:Show()
                end
            end
            ApplyTargetNameWidth(bar)

            bar:SetScript("OnUpdate", function(self)
                local elapsed = GetTime() - self._previewStart
                local progress = elapsed % self._previewDuration
                self:SetValue(self._isPreviewChannel and (self._previewDuration - progress) or progress)
                if self.TimerText and db.showTimer then
                    local remaining = self._previewDuration - progress
                    -- Preview bar's `remaining` is non-secret (computed from
                    -- GetTime arithmetic), so a plain Lua comparison is safe.
                    local digits
                    if db.timerNoDecimals then
                        digits = 0
                    elseif db.decimalsUnder5Only and remaining >= 5 then
                        digits = 0
                    else
                        digits = 1
                    end
                    self.TimerText:SetFormattedText("%." .. digits .. "f", remaining)
                    self.TimerText:Show()
                end
            end)

            bar:RegisterForDrag("LeftButton")
            bar:SetScript("OnMouseDown", function(_, btn) if btn == "LeftButton" then StartPreviewDrag() end end)
            bar:SetScript("OnMouseUp", function(_, btn) if btn == "LeftButton" then StopPreviewDrag() end end)
            bar:SetScript("OnDragStart", function() StartPreviewDrag() end)
            bar:SetScript("OnDragStop", function() StopPreviewDrag() end)

            table.insert(previewBars, bar)
        end

        if db.glow and db.glow.enabled then
            local g = db.glow
            local function applyPreviewGlow(bar, frame, colorR, colorG, colorB, colorA, handle)
                if not frame then return end
                frame:Show()
                frame:SetAlpha(1)
                local color = {colorR, colorG, colorB, colorA}
                if g.glowType == "PIXEL" then
                    LCG.PixelGlow_Start(frame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, handle)
                elseif g.glowType == "AUTOCAST" then
                    LCG.AutoCastGlow_Start(frame, color, 4, g.frequency, nil, 0, 0, handle)
                elseif g.glowType == "BUTTON" then
                    LCG.ButtonGlow_Start(frame, color, g.frequency)
                end
            end

            if g.glowOnTargeted then
                for _, pbar in ipairs(previewBars) do
                    if not pbar._isPreviewNonTargeted then
                        applyPreviewGlow(pbar, pbar.GlowOverlay or pbar, g.colorR, g.colorG, g.colorB, g.colorA, "MDC_TGT")
                    end
                end
            else
                local bar1 = previewBars[1]
                if bar1 then
                    local glowFrame = bar1.GlowOverlay or bar1
                    if g.glowOnTarget then
                        applyPreviewGlow(bar1, glowFrame, g.targetColorR, g.targetColorG, g.targetColorB, g.targetColorA, "MDC_MYTARGET")
                    elseif g.glowOnFocus then
                        applyPreviewGlow(bar1, glowFrame, g.focusColorR, g.focusColorG, g.focusColorB, g.focusColorA, "MDC_FOCUS")
                    end
                end
            end

            local bar2 = previewBars[2]
            if bar2 and g.glowOnImportant then
                applyPreviewGlow(bar2, bar2.ImportantGlowOverlay, g.importantColorR, g.importantColorG, g.importantColorB, g.importantColorA, "MDC_IMP")
            end

            local bar3 = previewBars[3]
            if bar3 and g.glowOnEnemyTargetingMDC then
                applyPreviewGlow(bar3, bar3.EnemyTargetGlowOverlay, g.enemyTargetColorR, g.enemyTargetColorG, g.enemyTargetColorB, g.enemyTargetColorA, "MDC_ENEMYTGT")
            end

            local bar5 = previewBars[5]
            if bar5 and g.glowOnNonTargeted then
                applyPreviewGlow(bar5, bar5.NonTargetedGlowOverlay, g.nonTargetedColorR, g.nonTargetedColorG, g.nonTargetedColorB, g.nonTargetedColorA, "MDC_NONTGT")
            end
        end
    else
        for i = #previewBars, 1, -1 do ReleaseBar(previewBars[i]); table.remove(previewBars, i) end
        for _, bar in pairs(activeBars) do bar:Show(); UpdateBarVisuals(bar) end
        ApplyLockState()
    end
    ReLayout()
end

MythicDungeonCasts._togglePreview = TogglePreview
MythicDungeonCasts._version = VERSION

function CreateAnchor()
    if anchorFrame then return end
    anchorFrame = CreateFrame("Frame", "MythicDungeonCastsAnchor", UIParent)
    anchorFrame:SetSize(280, 20)
    anchorFrame:SetPoint("CENTER", UIParent, "CENTER", db.posX or -527, db.posY or -12)
    anchorFrame:SetMovable(true); anchorFrame:SetClampedToScreen(true); anchorFrame:SetFrameStrata("MEDIUM")
    RefreshAll()
end

local function RemoveBar(unit)
    local bar = activeBars[unit]; if not bar then return end
    activeBars[unit] = nil
    for i,b in ipairs(usedBarsList) do if b==bar then table.remove(usedBarsList,i); break end end
    ReleaseBar(bar); ReLayout()
end

local function UpdateCast(unit)
    if isPreviewing then return end

    if db.advanced and db.advanced.legacyCombatTracking then
        local inCombat = UnitAffectingCombat(unit) or UnitExists(unit.."target")
        if not inCombat and unit ~= "player" then RemoveBar(unit); return end
    end

    local objCast    = UnitCastingDuration(unit)
    local objChannel = UnitChannelDuration(unit)
    local activeObj  = objCast or objChannel
    local isChanneling = (objChannel ~= nil)
    if not activeObj then RemoveBar(unit); return end

    local bar = activeBars[unit]
    if not bar then
        bar = AcquireBar(); if not bar then return end
        activeBars[unit] = bar; table.insert(usedBarsList, bar)
        UpdateBarVisuals(bar); ReLayout()
    end

    local name, _, texture, _, _, _, notInterruptible
    if isChanneling then name,_,texture,_,_,_,notInterruptible = UnitChannelInfo(unit)
    else name,_,texture,_,_,_,_,notInterruptible = UnitCastingInfo(unit) end
    if not name then return end

    local spellID
    if isChanneling then spellID = select(8, UnitChannelInfo(unit))
    else spellID = select(9, UnitCastingInfo(unit)) end

    local hasTarget = UnitSpellTargetName and UnitSpellTargetName(unit) ~= nil
    local hideForNoTarget = db.hideSymbolIfNoTarget and not hasTarget
    local suffix = (db.removeSymbol or hideForNoTarget) and "" or (MDC_SYMBOL_MAP[db.symbolChoice] or " -")
    bar.Text:SetText(name .. suffix); bar.Icon:SetTexture(texture)

    if db.spellNameClassColor then
        local tc = UnitSpellTargetClass and UnitSpellTargetClass(unit)
        if tc and C_ClassColor then
            local c = C_ClassColor.GetClassColor(tc)
            if c then bar.Text:SetTextColor(c.r, c.g, c.b, 1)
            else bar.Text:SetTextColor(db.font_spell.r or 1, db.font_spell.g or 1, db.font_spell.b or 1, db.font_spell.a or 1) end
        else
            bar.Text:SetTextColor(db.font_spell.r or 1, db.font_spell.g or 1, db.font_spell.b or 1, db.font_spell.a or 1)
        end
    else
        bar.Text:SetTextColor(db.font_spell.r or 1, db.font_spell.g or 1, db.font_spell.b or 1, db.font_spell.a or 1)
    end

    local raidIndex = GetRaidTargetIndex(unit)
    if raidIndex and bar.RaidIcon and db.showRaidIcon then
        bar.RaidIcon:Show(); bar.RaidIcon:SetSpriteSheetCell(raidIndex, 4, 4)
    else if bar.RaidIcon then bar.RaidIcon:Hide() end end

    local sbTex = bar:GetStatusBarTexture()
    if sbTex then
        local g = db.barGroup
        local intC  = CreateColor(db.nonInterruptColorR, db.nonInterruptColorG, db.nonInterruptColorB, db.nonInterruptColorA)
        local normC = CreateColor(g.barColorR or 0.02, g.barColorG or 1, g.barColorB or 0.17, g.barColorA or 1)
        if g.useTargetClassColor then
            local tc = UnitSpellTargetClass and UnitSpellTargetClass(unit)
            if tc then local c = C_ClassColor.GetClassColor(tc); if c then
                local cc = CreateColor(c.r, c.g, c.b, 1)
                normC = cc; intC = cc
            end end
        end
        -- Advanced: classification color override (always wins when enabled).
        -- Uses UnitClassification (non-secret string) plus UnitPowerType to
        -- detect caster mobs. Maps to one of five user-configurable colors.
        if db.advanced and db.advanced.barColorByClassification then
            local adv = db.advanced
            local classification = UnitClassification(unit)
            local _, powerToken = UnitPowerType(unit)
            local r, gC, b, a
            if classification == "worldboss" then
                r, gC, b, a = adv.bossColorR, adv.bossColorG, adv.bossColorB, adv.bossColorA
            elseif classification == "rareelite" or classification == "rare" then
                r, gC, b, a = adv.rareEliteColorR, adv.rareEliteColorG, adv.rareEliteColorB, adv.rareEliteColorA
            elseif classification == "elite" then
                if powerToken == "MANA" then
                    r, gC, b, a = adv.casterColorR, adv.casterColorG, adv.casterColorB, adv.casterColorA
                else
                    r, gC, b, a = adv.eliteColorR, adv.eliteColorG, adv.eliteColorB, adv.eliteColorA
                end
            else
                r, gC, b, a = adv.normalColorR, adv.normalColorG, adv.normalColorB, adv.normalColorA
            end
            local cc = CreateColor(r, gC, b, a)
            normC = cc; intC = cc
        elseif db.advanced and db.advanced.colorChanneledCasts and isChanneling then
            local adv = db.advanced
            normC = CreateColor(adv.channeledColorR, adv.channeledColorG, adv.channeledColorB, adv.channeledColorA)
        end
        sbTex:SetVertexColorFromBoolean(notInterruptible, intC, normC)

    -- Hide non-interruptible casts by driving the bar alpha from the secret
    -- notInterruptible boolean: alpha 0 (invisible) when true, 1 when false.
    if db.hideNonInterruptible then
        pcall(bar.SetAlphaFromBoolean, bar, notInterruptible, 0, 1)
        if bar.Icon then pcall(bar.Icon.SetAlphaFromBoolean, bar.Icon, notInterruptible, 0, 1) end
    else
        bar:SetAlpha(1)
        if bar.Icon then bar.Icon:SetAlpha(1) end
    end

    -- "Show Targeted Casts at Player Only": drive the bar's alpha from the secret
    -- "is this cast targeting me" boolean. We never read the boolean in Lua
    -- (that taints); SetAlphaFromBoolean consumes it directly -- alpha 1 when it
    -- targets the player, 0 otherwise. The caster's target token is stale at
    -- cast start, so ScheduleSelfTargetVisibility re-applies this after a short
    -- delay once the target resolves. Note: this can't collapse the layout gap
    -- (that would require reading the secret shown-state), and it shares the
    -- alpha sink with hideNonInterruptible -- whichever applies last wins, so the
    -- two hide options don't perfectly stack.
    if db.showOnlySelfTargeted then
        local function applySelfTargetVis()
            local b = activeBars[unit]
            if not b then return end
            -- Gate on the non-secret "has a displayable target" first. For casts
            -- with no specific target (AOE/self/ground), hide the bar outright.
            if UnitShouldDisplaySpellTargetName and not UnitShouldDisplaySpellTargetName(unit) then
                b:SetAlpha(0); if b.Icon then b.Icon:SetAlpha(0) end
                return
            end
            -- Pass the secret "targets me" boolean (PlayerIsSpellTarget, more
            -- accurate than the target-token comparison) straight into the alpha
            -- sink; never read it in Lua.
            pcall(b.SetAlphaFromBoolean, b, PlayerIsSpellTarget(unit), 1, 0)
            if b.Icon then pcall(b.Icon.SetAlphaFromBoolean, b.Icon, PlayerIsSpellTarget(unit), 1, 0) end
        end
        applySelfTargetVis()
        C_Timer.After(0.10, applySelfTargetVis)
        C_Timer.After(0.25, applySelfTargetVis)
    end

    -- "Player Targeted + Untargeted Mechanics": show casts aimed at the player,
    -- plus untargeted (AOE/ground/self) casts that are non-interruptible. Branch
    -- on the readable "has a displayable target" flag to decide which SECRET
    -- boolean drives visibility -- we never read a secret in Lua, we only choose
    -- which one to feed into the alpha sink. Like the targeted-only mode, the
    -- caster's target resolves slightly after cast start, so re-apply on a delay.
    if db.showSelfAndMechanics then
        local function applySelfMechVis()
            local b = activeBars[unit]
            if not b then return end
            if UnitShouldDisplaySpellTargetName and UnitShouldDisplaySpellTargetName(unit) then
                -- Has a specific target: show only if it targets the player.
                pcall(b.SetAlphaFromBoolean, b, PlayerIsSpellTarget(unit), 1, 0)
                if b.Icon then pcall(b.Icon.SetAlphaFromBoolean, b.Icon, PlayerIsSpellTarget(unit), 1, 0) end
            else
                -- No specific target: show only if it's non-interruptible. Re-fetch
                -- the secret notInterruptible boolean live and feed it to the sink.
                local ni
                if isChanneling then ni = select(7, UnitChannelInfo(unit))
                else ni = select(8, UnitCastingInfo(unit)) end
                pcall(b.SetAlphaFromBoolean, b, ni, 1, 0)
                if b.Icon then pcall(b.Icon.SetAlphaFromBoolean, b.Icon, ni, 1, 0) end
            end
        end
        applySelfMechVis()
        C_Timer.After(0.10, applySelfMechVis)
        C_Timer.After(0.25, applySelfMechVis)
    end
    end

    if bar.SetTimerDuration then
        local direction = isChanneling
            and (Enum.StatusBarTimerDirection and Enum.StatusBarTimerDirection.RemainingTime or 1)
            or  (Enum.StatusBarTimerDirection and Enum.StatusBarTimerDirection.ElapsedTime  or 0)
        bar:SetTimerDuration(activeObj, Enum.StatusBarInterpolation.None, direction)
    end

    if db.showTimer and bar.TimerText then
        bar.TimerText:Show()
        bar:SetScript("OnUpdate", function(self)
            local dur = self:GetTimerDuration()
            if dur then
                local remaining = dur:GetRemainingDuration()
                -- The decimal-count decision must NOT be made in Lua via
                -- `remaining < N`, because `remaining` is a secret-tainted
                -- number that errors on comparison. Instead we ask the
                -- privileged Duration object to evaluate a Step curve and
                -- hand us back the decimal-count integer.
                local digits
                if db.timerNoDecimals then
                    digits = 0
                elseif db.decimalsUnder5Only then
                    local curve = GetDecimalCountCurve()
                    digits = curve and dur:EvaluateRemainingDuration(curve) or 1
                else
                    digits = 1
                end
                self.TimerText:SetFormattedText("%." .. digits .. "f", remaining)
            else self.TimerText:SetText(""); self:SetScript("OnUpdate",nil) end
        end)
    else if bar.TimerText then bar.TimerText:SetText("") end; bar:SetScript("OnUpdate",nil) end

    if db.showTarget and bar.TargetNameText then
        local tn = UnitSpellTargetName and UnitSpellTargetName(unit)
        local displayName = ""
        if tn then
            -- 12.0.5+: UnitName rejects secret tokens, use pcall and fall back to tn itself
            local ok, resolvedName = pcall(UnitName, tn)
            displayName = (ok and resolvedName) or tn
        end
        bar.TargetNameText:SetText(displayName)
        ApplyTargetNameWidth(bar)
        if db.disableClassColor then
            bar.TargetNameText:SetTextColor(db.targetColorR or 1, db.targetColorG or 1, db.targetColorB or 1, db.targetColorA or 1)
        else
            local tc = UnitSpellTargetClass and UnitSpellTargetClass(unit)
            if tc then local c = C_ClassColor.GetClassColor(tc); if c then bar.TargetNameText:SetTextColor(c.r,c.g,c.b,1) end end
        end
        local show = UnitShouldDisplaySpellTargetName and UnitShouldDisplaySpellTargetName(unit) or (tn ~= nil)
        bar.TargetNameText:SetShown(show)
    else if bar.TargetNameText then bar.TargetNameText:Hide() end end

    if LCG and db.glow and db.glow.enabled then
        local g = db.glow
        local glowFrame = bar.GlowOverlay or bar

        local hasTarget = g.glowOnTargeted and UnitShouldDisplaySpellTargetName and UnitShouldDisplaySpellTargetName(unit) or false
        if hasTarget then
            local color = {g.colorR, g.colorG, g.colorB, g.colorA}
            if g.glowType == "PIXEL" then
                LCG.PixelGlow_Start(glowFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_TGT")
            elseif g.glowType == "AUTOCAST" then
                LCG.AutoCastGlow_Start(glowFrame, color, 4, g.frequency, nil, 0, 0, "MDC_TGT")
            elseif g.glowType == "BUTTON" then
                LCG.ButtonGlow_Start(glowFrame, color, g.frequency)
            end
        else
            LCG.PixelGlow_Stop(glowFrame, "MDC_TGT"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_TGT"); LCG.ButtonGlow_Stop(glowFrame)
        end

        local isTarget = g.glowOnTarget and UnitExists("target") and UnitIsUnit(unit, "target")
        if isTarget then
            local color = {g.targetColorR, g.targetColorG, g.targetColorB, g.targetColorA}
            if g.glowType == "PIXEL" then
                LCG.PixelGlow_Start(glowFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_MYTARGET")
            elseif g.glowType == "AUTOCAST" then
                LCG.AutoCastGlow_Start(glowFrame, color, 4, g.frequency, nil, 0, 0, "MDC_MYTARGET")
            elseif g.glowType == "BUTTON" then
                LCG.ButtonGlow_Start(glowFrame, color, g.frequency)
            end
        else
            LCG.PixelGlow_Stop(glowFrame, "MDC_MYTARGET"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_MYTARGET")
        end

        local isFocus = g.glowOnFocus and UnitExists("focus") and UnitIsUnit(unit, "focus")
        if isFocus then
            local color = {g.focusColorR, g.focusColorG, g.focusColorB, g.focusColorA}
            if g.glowType == "PIXEL" then
                LCG.PixelGlow_Start(glowFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_FOCUS")
            elseif g.glowType == "AUTOCAST" then
                LCG.AutoCastGlow_Start(glowFrame, color, 4, g.frequency, nil, 0, 0, "MDC_FOCUS")
            elseif g.glowType == "BUTTON" then
                LCG.ButtonGlow_Start(glowFrame, color, g.frequency)
            end
        else
            LCG.PixelGlow_Stop(glowFrame, "MDC_FOCUS"); LCG.AutoCastGlow_Stop(glowFrame, "MDC_FOCUS")
        end

        -- Important cast glow (uses separate overlay — SetShown with secret taints shown aspect)
        local impFrame = bar.ImportantGlowOverlay
        if g.glowOnImportant and IsSpellImportant and spellID and impFrame then
            local color = {g.importantColorR, g.importantColorG, g.importantColorB, g.importantColorA}
            if g.glowType == "PIXEL" then
                LCG.PixelGlow_Start(impFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_IMP")
            elseif g.glowType == "AUTOCAST" then
                LCG.AutoCastGlow_Start(impFrame, color, 4, g.frequency, nil, 0, 0, "MDC_IMP")
            end
            local ok, result = pcall(IsSpellImportant, spellID)
            if ok then
                impFrame:SetShown(result)
            else
                impFrame:Hide()
            end
        elseif impFrame then
            LCG.PixelGlow_Stop(impFrame, "MDC_IMP"); LCG.AutoCastGlow_Stop(impFrame, "MDC_IMP")
            impFrame:Hide()
        end

        ApplyEnemyTargetGlow(bar, unit)

        -- Non-targeted cast glow (AOE / self-buff / ground-target casts)
        -- Independently combinable with the other glow toggles. Uses
        -- UnitShouldDisplaySpellTargetName (non-secret boolean) as the same
        -- detector the cast bar's target-name display uses, so what shows
        -- a target name will not glow as non-targeted, and vice versa.
        local ntFrame = bar.NonTargetedGlowOverlay
        if g.glowOnNonTargeted and ntFrame then
            local hasSpellTarget = UnitShouldDisplaySpellTargetName and UnitShouldDisplaySpellTargetName(unit)
            if not hasSpellTarget then
                ntFrame:Show()
                local color = {g.nonTargetedColorR, g.nonTargetedColorG, g.nonTargetedColorB, g.nonTargetedColorA}
                if g.glowType == "PIXEL" then
                    LCG.PixelGlow_Start(ntFrame, color, g.lines, g.frequency, nil, g.thickness, 0, 0, false, "MDC_NONTGT")
                elseif g.glowType == "AUTOCAST" then
                    LCG.AutoCastGlow_Start(ntFrame, color, 4, g.frequency, nil, 0, 0, "MDC_NONTGT")
                end
            else
                LCG.PixelGlow_Stop(ntFrame, "MDC_NONTGT"); LCG.AutoCastGlow_Stop(ntFrame, "MDC_NONTGT")
                ntFrame:Hide()
            end
        elseif ntFrame then
            LCG.PixelGlow_Stop(ntFrame, "MDC_NONTGT"); LCG.AutoCastGlow_Stop(ntFrame, "MDC_NONTGT")
            ntFrame:Hide()
        end
    end
end

local CAST_EVENTS = {
    "UNIT_SPELLCAST_START","UNIT_SPELLCAST_CHANNEL_START",
    "UNIT_SPELLCAST_STOP","UNIT_SPELLCAST_INTERRUPTED","UNIT_SPELLCAST_CHANNEL_STOP",
    "UNIT_SPELLCAST_INTERRUPTIBLE","UNIT_SPELLCAST_NOT_INTERRUPTIBLE",
    "UNIT_TARGET",
}

local _ttsSpeaking = false

local function AnnounceTTS(unit, event)
    if not db or not db.tts or not db.tts.enabled then
        return
    end
    if not C_VoiceChat or not C_VoiceChat.SpeakText then
        return
    end

    local isStart = (event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_CHANNEL_START")
    if not isStart then
        return
    end

    local isChanneling = (event == "UNIT_SPELLCAST_CHANNEL_START")
    local name
    if isChanneling then name = UnitChannelInfo(unit)
    else name = UnitCastingInfo(unit) end
    if not name then
        return
    end

    if db.advanced then
        local adv = db.advanced
        local anyFilterActive = adv.ttsBossOnly or adv.ttsEliteOnly or adv.ttsCasterOnly
        if anyFilterActive then
            local passes = false
            if adv.ttsBossOnly then
                local lvl = UnitLevel(unit)
                if lvl == -1 or (lvl or 0) >= 92 then passes = true end
            end
            if not passes and adv.ttsEliteOnly then
                if UnitLevel(unit) == 91 then passes = true end
            end
            if not passes and adv.ttsCasterOnly then
                local _, powerToken = UnitPowerType(unit)
                if powerToken == "MANA" then passes = true end
            end
            if not passes then return end
        end
    end

    local tts = db.tts
    local msg = ""


    local advFilterActive = db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly)
    if advFilterActive then
        local _, powerToken = UnitPowerType(unit)
        if db.advanced.ttsCasterOnly and powerToken == "MANA" then
            local tn = UnitSpellTargetName and UnitSpellTargetName(unit)
            local targetName
            if tn then local ok, n = pcall(UnitName, tn); targetName = (ok and n) or tn end
            msg = targetName and (name .. " on " .. targetName) or name
        else
            msg = name
        end
    elseif tts.announceBoth then
        local tn = UnitSpellTargetName and UnitSpellTargetName(unit)
        local targetName
        if tn then local ok, n = pcall(UnitName, tn); targetName = (ok and n) or tn end
        msg = targetName and (name .. " on " .. targetName) or name
    elseif tts.announceTarget then
        local tn = UnitSpellTargetName and UnitSpellTargetName(unit)
        local targetName
        if tn then local ok, n = pcall(UnitName, tn); targetName = (ok and n) or tn end
        msg = targetName or name
    elseif tts.announceSpell then
        msg = name
    else
        return
    end

    local voiceID = tts.voiceID or 0
    local rate = tts.rate or 0
    local volume = tts.volume or 100
    local mode = tts.overlapMode or "stop"


    if mode == "skip" then
        if _ttsSpeaking then
            return
        end
        C_VoiceChat.SpeakText(voiceID, msg, rate, volume, false)
    elseif mode == "allow" then
        C_VoiceChat.SpeakText(voiceID, msg, rate, volume, true)
    else
        C_VoiceChat.StopSpeakingText()
        C_Timer.After(0.05, function()
            C_VoiceChat.SpeakText(voiceID, msg, rate, volume, false)
        end)
    end
end

local function OnCastEvent(event, unit)
    if not db or not db.enabled or not unit then return end
    if not string.match(unit, "^nameplate%d+$") then return end
    if UnitIsUnit(unit, "player") then return end
    if not UnitCanAttack("player", unit) then return end

    if event == "UNIT_TARGET" then
        if activeBars[unit] then ScheduleEnemyTargetCheck(unit) end
        return
    end

    AnnounceTTS(unit, event)
    UpdateCast(unit)

    if event == "UNIT_SPELLCAST_START" or event == "UNIT_SPELLCAST_CHANNEL_START" then
        ScheduleEnemyTargetCheck(unit)
    elseif event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_CHANNEL_STOP"
        or event == "UNIT_SPELLCAST_INTERRUPTED" then
        _etGen[unit] = (_etGen[unit] or 0) + 1
    end
end

local function OnUnitAdded(event, unit)
    if not db or not db.enabled or not unit then return end
    if not string.match(unit, "^nameplate%d+$") then return end
    if UnitIsUnit(unit, "player") then return end
    if not UnitCanAttack("player", unit) then return end
    if UnitCastingInfo(unit) or UnitChannelInfo(unit) then
        UpdateCast(unit)
    end
end

local function OnUnitRemoved(event, unit)
    _etGen[unit] = (_etGen[unit] or 0) + 1
    local bar = activeBars[unit]; if not bar then return end
    activeBars[unit] = nil
    for i,b in ipairs(usedBarsList) do if b==bar then table.remove(usedBarsList,i); break end end
    ReleaseBar(bar); ReLayout()
end

local castEventFrame = CreateFrame("Frame", "MDCCastEventFrame")
castEventFrame:SetScript("OnEvent", function(_, event, unit)
    if event == "NAME_PLATE_UNIT_ADDED" then OnUnitAdded(event, unit)
    elseif event == "NAME_PLATE_UNIT_REMOVED" then OnUnitRemoved(event, unit)
    else OnCastEvent(event, unit) end
end)

local function EnableEvents()
    if areEventsEnabled then return end; areEventsEnabled = true
    castEventFrame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
    castEventFrame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
    for _, e in ipairs(CAST_EVENTS) do castEventFrame:RegisterEvent(e) end
end

local function DisableEvents()
    if not areEventsEnabled then return end; areEventsEnabled = false
    castEventFrame:UnregisterAllEvents()
    for _, bar in pairs(activeBars) do ReleaseBar(bar) end
    activeBars = {}; usedBarsList = {}; ReLayout()
end

function CheckEnvironment()
    local _, instanceType = GetInstanceInfo()
    if instanceType == "party" and db and db.enabled then EnableEvents() else DisableEvents() end
end

local mdcTTSState = CreateFrame("Frame", "MDC_TTSStateFrame")
mdcTTSState:RegisterEvent("VOICE_CHAT_TTS_PLAYBACK_STARTED")
mdcTTSState:RegisterEvent("VOICE_CHAT_TTS_PLAYBACK_FINISHED")
mdcTTSState:RegisterEvent("VOICE_CHAT_TTS_PLAYBACK_FAILED")
mdcTTSState:SetScript("OnEvent", function(_, ev)
    if ev == "VOICE_CHAT_TTS_PLAYBACK_STARTED" then
        _ttsSpeaking = true
    else
        _ttsSpeaking = false
    end
end)

local mdcLifecycle = CreateFrame("Frame", "MDC_LifecycleFrame")
mdcLifecycle:RegisterEvent("PLAYER_ENTERING_WORLD")
mdcLifecycle:RegisterEvent("ZONE_CHANGED_NEW_AREA")
mdcLifecycle:RegisterEvent("PLAYER_REGEN_ENABLED")
mdcLifecycle:RegisterEvent("PLAYER_REGEN_DISABLED")
mdcLifecycle:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_ENTERING_WORLD" then
        if MythicDungeonCasts.db then MythicDungeonCasts.db.profile.preview = false end
        C_Timer.After(1, function()
            if MythicDungeonCasts.db then
                db = MythicDungeonCasts.db.profile
                CreateAnchor(); TogglePreview(false); CheckEnvironment()
            end
        end)
    elseif event == "ZONE_CHANGED_NEW_AREA" then
        if db then CheckEnvironment() end
    elseif event == "PLAYER_REGEN_DISABLED" then
        if isPreviewing then if db then db.preview = false end; TogglePreview(false) end
    elseif event == "PLAYER_REGEN_ENABLED" then
        if db and db.advanced and db.advanced.legacyCombatTracking then
            local rem = {}
            for u in pairs(activeBars) do if not UnitAffectingCombat(u) then rem[#rem+1] = u end end
            for _,u in ipairs(rem) do RemoveBar(u) end
        end
    end
end)

local function BuildOptions()
    local function get(info) return db[info[#info]] end
    local function set(info, val) db[info[#info]] = val; RefreshAll() end
    local function getBG(info) return db.barGroup[info[#info]] end
    local function setBG(info, val) db.barGroup[info[#info]] = val; RefreshAll() end
    local function getBarColor(key) return function() return db.barGroup[key.."R"],db.barGroup[key.."G"],db.barGroup[key.."B"],db.barGroup[key.."A"] end end
    local function setBarColor(key) return function(_,r,g,b,a) db.barGroup[key.."R"]=r; db.barGroup[key.."G"]=g; db.barGroup[key.."B"]=b; db.barGroup[key.."A"]=a; RefreshAll() end end
    local function lsmList(mt) local t={}; for _,v in ipairs(LSM:List(mt)) do t[v]=v end; return t end
    local function textureChoices() return lsmList("statusbar") end
    local function fontChoices() return lsmList("font") end
    local function borderChoices() local t = lsmList("border"); t["None"] = "None"; return t end
    local outlineChoices  = {[""]=L["None"],["OUTLINE"]=L["Outline"],["THICKOUTLINE"]=L["Thick Outline"]}
    local alignChoices    = {LEFT=L["Left"],CENTER=L["Center"],RIGHT=L["Right"]}
    local growChoices     = {UP=L["Upward"],DOWN=L["Downward"]}
    local iconSideChoices = {LEFT=L["Left"],RIGHT=L["Right"]}

    local function fontGroupArgs(cfgKey, parentDisabled)
        local function disabledFor(extra)
            if parentDisabled and extra then
                return function(info) return parentDisabled(info) or extra(info) end
            elseif parentDisabled then
                return parentDisabled
            else
                return extra
            end
        end
        return {
            font={type="select",name=L["Font"],order=1,values=fontChoices,
                disabled=disabledFor(nil),
                get=function() return db[cfgKey].font end,set=function(_,v) db[cfgKey].font=v; RefreshAll() end},
            size={type="range",name=L["Size"],order=2,min=8,max=48,step=1,
                disabled=disabledFor(nil),
                get=function() return db[cfgKey].size end,set=function(_,v) db[cfgKey].size=v; RefreshAll() end},
            outline={type="select",name=L["Outline"],order=3,values=outlineChoices,
                disabled=disabledFor(nil),
                get=function() return db[cfgKey].outline end,set=function(_,v) db[cfgKey].outline=v; RefreshAll() end},
            xOff={type="range",name=L["X Offset"],order=4,min=-500,max=500,step=1,
                disabled=disabledFor(nil),
                get=function() return db[cfgKey].x end,set=function(_,v) db[cfgKey].x=v; RefreshAll() end},
            yOff={type="range",name=L["Y Offset"],order=5,min=-100,max=100,step=1,
                disabled=disabledFor(nil),
                get=function() return db[cfgKey].y end,set=function(_,v) db[cfgKey].y=v; RefreshAll() end},
        }
    end

    return { name=DISPLAY_NAME, type="group", args={
        general={type="group",name=L["General"],order=1,args={
            enabled={type="toggle",name=L["Enable"],order=1,width="full",get=get,set=function(_,v) db.enabled=v; CheckEnvironment(); RefreshAll(); print("|cff00ff00Mythic Dungeon Casts:|r " .. (v and "|cff00ff00Enabled|r" or "|cffff4444Disabled|r")) end},
            disableInitMessage={type="toggle",name=L["Disable MDC Message on Initialization"],order=1.5,width="full",get=get,set=set},
            minimapIcon={type="toggle",name=L["Show Minimap Icon"],order=1.6,width="full",
                get=function() return not (db.minimap and db.minimap.hide) end,
                set=function(_,v)
                    db.minimap = db.minimap or {}
                    db.minimap.hide = not v
                    MythicDungeonCasts:RefreshMinimapButton()
                end},
            locked={type="toggle",name=L["Lock Position"],order=2,get=get,set=set},

            preview={type="toggle",name=L["Preview Mode"],order=5,get=get,set=function(_,v) db.preview=v; TogglePreview(v) end},
            resetPos={type="execute",name=L["Reset Position"],order=6,func=function()
                StaticPopupDialogs["MDC_CONFIRM_RESET_POSITION"] = {
                    text = L["Are you sure you want to reset the position?"],
                    button1 = L["Reset"] or ACCEPT, button2 = L["Cancel"] or CANCEL,
                    OnAccept = function()
                        db.posX = 0; db.posY = 100
                        if anchorFrame then anchorFrame:ClearAllPoints(); anchorFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 100) end
                        RefreshAll()
                    end,
                    timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
                }
                StaticPopup_Show("MDC_CONFIRM_RESET_POSITION")
            end},
            displayBehaviorHeader={type="header",name=L["Display Behaviour"],order=6.5},
            displayBehavior={type="select",name=L["Display Behaviour"],order=6.6,width="full",
                values={
                    NONE          = L["Basic"],
                    HIDE_NONINT   = L["Hide Non-Interruptible Casts"],
                    SMOOTH        = L["Smoother Bar Animations"],
                    SHOW_TARGETED = L["Show Targeted Casts at Player Only"],
                    SELF_MECH     = L["Player Targeted + Untargeted Mechanics"],
                },
                sorting={"NONE","HIDE_NONINT","SMOOTH","SHOW_TARGETED","SELF_MECH"},
                get=function()
                    if db.hideNonInterruptible then return "HIDE_NONINT"
                    elseif db.smoothAnim then return "SMOOTH"
                    elseif db.showOnlySelfTargeted then return "SHOW_TARGETED"
                    elseif db.showSelfAndMechanics then return "SELF_MECH"
                    else return "NONE" end
                end,
                set=function(_,v)
                    db.hideNonInterruptible = (v == "HIDE_NONINT")
                    db.smoothAnim           = (v == "SMOOTH")
                    db.showOnlySelfTargeted = (v == "SHOW_TARGETED")
                    db.showSelfAndMechanics = (v == "SELF_MECH")
                    RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end
                end},
        }},
        layout={type="group",name=L["Layout"],order=2,args={
            growDirection={type="select",name=L["Grow Direction"],order=1,values=growChoices,get=get,set=set},
            maxBars={type="range",name=L["Max Bars"],order=2,min=1,max=15,step=1,get=get,set=set},
            spacing={type="range",name=L["Vertical Spacing"],order=3,min=0,max=50,step=1,get=get,set=set},
            iconHeader={type="header",name=L["Spell Icon"],order=10},
            showIcon={type="toggle",name=L["Show Icon"],order=11,get=getBG,set=setBG},
            iconSize={type="range",name=L["Icon Size"],order=12,min=8,max=64,step=1,
                disabled=function() return db.barGroup.matchIconToBar end,
                get=getBG,set=setBG},
            iconSide={type="select",name=L["Icon Side"],order=13,values=iconSideChoices,get=getBG,set=setBG},
            raidHeader={type="header",name=L["Raid Icons"],order=20},
            showRaidIcon={type="toggle",name=L["Show Raid Target Icons"],order=21,get=get,set=set},
            raidIconSize={type="range",name=L["Icon Size"],order=22,min=10,max=64,step=1,get=get,set=set},
            raidIconX={type="range",name=L["X Offset"],order=23,min=-100,max=100,step=1,get=get,set=set},
            raidIconY={type="range",name=L["Y Offset"],order=24,min=-100,max=100,step=1,get=get,set=set},
        }},
        barAppearance={type="group",name=L["Bar Appearance"],order=3,args={
            barsHeader={type="header",name=L["Bars"],order=0},
            width={type="range",name=L["Width"],order=1,min=50,max=800,step=1,get=getBG,set=setBG},
            height={type="range",name=L["Height"],order=2,min=8,max=80,step=1,get=getBG,set=setBG},
            matchIconToBar={type="toggle",name=L["Match Icon Size with Bar Size"],order=2.5,width="full",
                get=getBG,
                set=function(info,v) db.barGroup.matchIconToBar=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            texture={type="select",name=L["Texture"],order=3,values=textureChoices,get=getBG,set=setBG},
            useTargetClassColor={type="toggle",name=L["Use Target Class Colour for Bar"],order=4,width="full",
                disabled=function() return db.advanced and db.advanced.barColorByClassification end,
                get=getBG,
                set=function(info,v) db.barGroup.useTargetClassColor=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            barColor={type="color",name=L["Bar Color (Interruptible)"],order=5,hasAlpha=true,
                disabled=function() return db.advanced and db.advanced.barColorByClassification end,
                get=getBarColor("barColor"),set=setBarColor("barColor")},
            barBgColor={type="color",name=L["Background Color"],order=6,hasAlpha=true,get=getBarColor("barBgColor"),set=setBarColor("barBgColor")},
            nonInterruptColor={type="color",name=L["Non-Interruptible Color"],order=7,hasAlpha=true,
                disabled=function() return db.advanced and db.advanced.barColorByClassification end,
                get=function() return db.nonInterruptColorR,db.nonInterruptColorG,db.nonInterruptColorB,db.nonInterruptColorA end,
                set=function(_,r,g,b,a) db.nonInterruptColorR=r; db.nonInterruptColorG=g; db.nonInterruptColorB=b; db.nonInterruptColorA=a; RefreshAll() end},
            advancedOverrideNote={type="description",fontSize="small",name=L["These options are unavailable when Advanced mob classifications settings are enabled."],order=7.5,
                hidden=function() return not (db.advanced and db.advanced.barColorByClassification) end},
            borderHeader={type="header",name=L["Border"],order=8},
            showBorder={type="toggle",name=L["Show Border"],order=9,get=getBG,set=setBG},
            borderTexture={type="select",name=L["Border Texture"],order=10,values=borderChoices,get=getBG,set=setBG},
            borderSize={type="range",name=L["Border Size"],order=11,min=1,max=32,step=1,get=getBG,set=setBG},
            borderPadding={type="range",name=L["Border Padding"],order=12,min=-10,max=20,step=1,get=getBG,set=setBG},
            borderColor={type="color",name=L["Border Color"],order=13,hasAlpha=true,get=getBarColor("borderColor"),set=setBarColor("borderColor")},
        }},
        fontSpell={type="group",name=L["Spell Name"],order=4,args={
            showSpellName={type="toggle",name=L["Show Spell Name"],order=1,width="full",get=get,
                set=function(info,v) db.showSpellName=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            spellNameClassColor={type="toggle",name=L["Use Target Class Color for Spell Name"],order=1.5,width="full",
                disabled=function() return not db.showSpellName end,
                get=get,set=set},
            textAlign={type="select",name=L["Text Alignment"],order=2,values=alignChoices,
                disabled=function() return not db.showSpellName end,
                get=function() return db.textAlign end,set=function(_,v) db.textAlign=v; RefreshAll() end},
            fg={type="group",name=L["Font Settings"],order=4,inline=true,
                disabled=function() return not db.showSpellName end,
                args=fontGroupArgs("font_spell", function() return not db.showSpellName end)},
        }},
        fontTarget={type="group",name=L["Target Name"],order=5,args={
            showTarget={type="toggle",name=L["Show Target Name"],order=1,width="full",get=get,
                set=function(info,v) db.showTarget=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            autoAnchorTarget={type="toggle",name=L["Automatically Anchor Player Names"],order=2,width="full",
                disabled=function() return not db.showTarget end,
                get=get,
                set=function(info,v) db.autoAnchorTarget=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            disableClassColor={type="toggle",name=L["Disable Class Color"],order=3,width="full",
                disabled=function() return not db.showTarget end,
                get=get,
                set=function(info,v) db.disableClassColor=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            targetColor={type="color",name=L["Target Name Color"],order=4,hasAlpha=false,
                disabled=function() return not db.showTarget or not db.disableClassColor end,
                get=function() return db.targetColorR or 1, db.targetColorG or 1, db.targetColorB or 1, db.targetColorA or 1 end,
                set=function(_,r,g,b,a) db.targetColorR=r; db.targetColorG=g; db.targetColorB=b; db.targetColorA=a or 1; RefreshAll() end},
            hideSymbolIfNoTarget={type="toggle",name=L["Hide Symbol When No Target"],order=4.5,width="full",
                disabled=function() return not db.showTarget end,
                get=get,
                set=function(info,v) db.hideSymbolIfNoTarget=v; if v then db.removeSymbol=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            removeSymbol={type="toggle",name=L["Remove Symbol"],order=5,width="full",
                disabled=function() return not db.showTarget end,
                get=get,
                set=function(info,v) db.removeSymbol=v; if v then db.hideSymbolIfNoTarget=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            symbolChoice={type="select",name=L["Symbols"],order=6,values=GetSymbolChoices,
                disabled=function() return not db.showTarget or db.removeSymbol end,
                get=function() return db.symbolChoice or "HYPHEN" end,
                set=function(_,v) db.symbolChoice=v; RefreshAll() end},
            targetAlign={type="select",name=L["Text Alignment"],order=7,values=alignChoices,
                disabled=function() return not db.showTarget or db.autoAnchorTarget end,
                get=function() return db.targetAlign end,set=function(_,v) db.targetAlign=v; RefreshAll() end},
            fg={type="group",name=L["Font Settings"],order=9,inline=true,
                disabled=function() return not db.showTarget end,
                args={
                font={type="select",name=L["Font"],order=1,values=fontChoices,
                    disabled=function() return not db.showTarget end,
                    get=function() return db.font_target.font end,set=function(_,v) db.font_target.font=v; RefreshAll() end},
                size={type="range",name=L["Size"],order=2,min=8,max=48,step=1,
                    disabled=function() return not db.showTarget end,
                    get=function() return db.font_target.size end,set=function(_,v) db.font_target.size=v; RefreshAll() end},
                outline={type="select",name=L["Outline"],order=3,values=outlineChoices,
                    disabled=function() return not db.showTarget end,
                    get=function() return db.font_target.outline end,set=function(_,v) db.font_target.outline=v; RefreshAll() end},
                xOff={type="range",name=L["X Offset"],order=4,min=-500,max=500,step=1,
                    disabled=function() return not db.showTarget or db.autoAnchorTarget end,
                    get=function() return db.font_target.x end,set=function(_,v) db.font_target.x=v; RefreshAll() end},
                yOff={type="range",name=L["Y Offset"],order=5,min=-100,max=100,step=1,
                    disabled=function() return not db.showTarget or db.autoAnchorTarget end,
                    get=function() return db.font_target.y end,set=function(_,v) db.font_target.y=v; RefreshAll() end},
            }},
        }},
        fontTimer={type="group",name=L["Timer"],order=6,args={
            showTimer={type="toggle",name=L["Show Timer Text"],order=1,width="full",get=get,
                set=function(info,v) db.showTimer=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            timerNoDecimals={type="toggle",name=L["Remove Decimals"],order=2.2,
                disabled=function() return not db.showTimer end,
                get=get,
                set=function(_,v) db.timerNoDecimals=v; if v then db.decimalsUnder5Only=false end; RefreshAll() end},
            decimalsUnder5Only={type="toggle",name=L["Decimals Only Under 5 Seconds"],order=2,
                disabled=function() return not db.showTimer end,
                get=get,
                set=function(_,v) db.decimalsUnder5Only=v; if v then db.timerNoDecimals=false end; RefreshAll() end},
            removeTimerAnchor={type="toggle",name=L["Unlock Timer Position"],order=2.5,width="full",
                disabled=function() return not db.showTimer end,
                get=get,
                set=function(_,v) db.removeTimerAnchor=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            timerAnchor={type="select",name=L["Timer Anchor"],order=3,
                values={RIGHT=L["Right"],LEFT=L["Left"],TOP="Top",BOTTOM="Bottom"},
                disabled=function() return not db.showTimer or db.removeTimerAnchor end,
                get=get,
                set=function(info,v) db.timerAnchor=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            fg={type="group",name=L["Font Settings"],order=5,inline=true,
                disabled=function() return not db.showTimer end,
                args={
                font={type="select",name=L["Font"],order=1,values=fontChoices,
                    disabled=function() return not db.showTimer end,
                    get=function() return db.font_timer.font end,set=function(_,v) db.font_timer.font=v; RefreshAll() end},
                size={type="range",name=L["Size"],order=2,min=8,max=48,step=1,
                    disabled=function() return not db.showTimer end,
                    get=function() return db.font_timer.size end,set=function(_,v) db.font_timer.size=v; RefreshAll() end},
                outline={type="select",name=L["Outline"],order=3,values=outlineChoices,
                    disabled=function() return not db.showTimer end,
                    get=function() return db.font_timer.outline end,set=function(_,v) db.font_timer.outline=v; RefreshAll() end},
                xOff={type="range",name=L["X Offset"],order=4,min=-500,max=500,step=1,
                    disabled=function() return not db.showTimer or not db.removeTimerAnchor end,
                    get=function() return db.font_timer.x end,set=function(_,v) db.font_timer.x=v; RefreshAll() end},
                yOff={type="range",name=L["Y Offset"],order=5,min=-100,max=100,step=1,
                    disabled=function() return not db.showTimer or not db.removeTimerAnchor end,
                    get=function() return db.font_timer.y end,set=function(_,v) db.font_timer.y=v; RefreshAll() end},
            }},
        }},
        ttsGroup={type="group",name=L["Text to Speech"],order=7,args={
            ttsEnabled={type="toggle",name=L["Enable Text to Speech"],order=1,width="full",
                get=function() return db.tts.enabled end,
                set=function(_,v)
                    db.tts.enabled=v
                    if v and not db.tts.announceSpell and not db.tts.announceTarget and not db.tts.announceBoth then
                        db.tts.announceSpell = true
                    end
                    if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end
                end},
            sep1={type="header",name=L["Announcement"],order=2},
            advancedFeaturesNote={type="description",fontSize="small",name=L["Additional Text to Speech features exist in the Advanced tab"],order=2.5,
                hidden=function() return db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly) end},
            announceSpell={type="toggle",name=L["Announce Spell Name"],order=3,width="full",
                disabled=function()
                    if not db.tts.enabled then return true end
                    if db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly) then return true end
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    return getFn and getFn("CAAEnabled") == "1"
                end,
                get=function() return db.tts.announceSpell end,
                set=function(_,v) db.tts.announceSpell=v; if v then db.tts.announceTarget=false; db.tts.announceBoth=false end; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            announceTarget={type="toggle",name=L["Announce Target Name"],order=4,width="full",
                disabled=function()
                    if not db.tts.enabled then return true end
                    if db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly) then return true end
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    return getFn and getFn("CAAEnabled") == "1"
                end,
                get=function() return db.tts.announceTarget end,
                set=function(_,v) db.tts.announceTarget=v; if v then db.tts.announceSpell=false; db.tts.announceBoth=false end; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            announceBoth={type="toggle",name=L["Announce Spell and Target"],order=5,width="full",
                disabled=function()
                    if not db.tts.enabled then return true end
                    if db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly) then return true end
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    return getFn and getFn("CAAEnabled") == "1"
                end,
                get=function() return db.tts.announceBoth end,
                set=function(_,v) db.tts.announceBoth=v; if v then db.tts.announceSpell=false; db.tts.announceTarget=false end; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            announceModeAdvNote={type="description",fontSize="small",name=L["Announcement options are controlled by Advanced filters while a filter is active."],order=5.5,
                hidden=function() return not (db.advanced and (db.advanced.ttsBossOnly or db.advanced.ttsEliteOnly or db.advanced.ttsCasterOnly)) end},
            sep3={type="header",name=L["Overlap"],order=6},
            overlapMode={type="select",name=L["When a new cast starts while announcing"],order=7,width="full",
                disabled=function() return not db.tts.enabled end,
                values={
                    stop  = L["Stop previous announcement"],
                    skip  = L["Skip new announcement"],
                    allow = L["Allow overlap"],
                },
                sorting={"stop","skip","allow"},
                get=function() return db.tts.overlapMode or "stop" end,
                set=function(_,v)
                    db.tts.overlapMode = v
                    db.tts.allowOverlapHeavy  = (v == "allow")
                end},
            sep5={type="header",name=L["Blizzard Audio Assist"],order=9},
            blizzAudioAssistNote={type="description",fontSize="small",name=L["These are native Blizzard features. MDC provides a shortcut to toggle them."],order=9.1},
            blizzCAAEnabled={type="toggle",name=L["Enable Combat Audio Alerts"],order=10,width="full",
                get=function()
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    if getFn then return getFn("CAAEnabled") == "1" end
                    return false
                end,
                set=function(_,v)
                    local setFn = (C_CVar and C_CVar.SetCVar) or SetCVar
                    if setFn then pcall(setFn, "CAAEnabled", v and "1" or "0") end
                    if v then
                        db.tts.announceSpell = false
                        db.tts.announceTarget = false
                        db.tts.announceBoth = false
                    end
                    if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end
                end},
            blizzInterruptAlert={type="toggle",name=L["Interruptible Cast Alert"],order=11,width="full",
                disabled=function()
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    return getFn and getFn("CAAEnabled") ~= "1"
                end,
                get=function()
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    if getFn then return getFn("CAAInterruptCast") == "1" end
                    return false
                end,
                set=function(_,v)
                    local setFn = (C_CVar and C_CVar.SetCVar) or SetCVar
                    if setFn then pcall(setFn, "CAAInterruptCast", v and "1" or "0") end
                end},
            blizzInterruptSuccess={type="toggle",name=L["Successful Interrupt Alert"],order=12,width="full",
                disabled=function()
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    return getFn and getFn("CAAEnabled") ~= "1"
                end,
                get=function()
                    local getFn = (C_CVar and C_CVar.GetCVar) or GetCVar
                    if getFn then return getFn("CAAInterruptCastSuccess") == "1" end
                    return false
                end,
                set=function(_,v)
                    local setFn = (C_CVar and C_CVar.SetCVar) or SetCVar
                    if setFn then pcall(setFn, "CAAInterruptCastSuccess", v and "1" or "0") end
                end},
            sep4={type="header",name=L["Voice Settings"],order=14},
            ttsVoice={type="select",name=L["Voice"],order=15,
                disabled=function() return not db.tts.enabled end,
                values=function()
                    local voices = {}
                    if C_VoiceChat and C_VoiceChat.GetTtsVoices then
                        for _, v in ipairs(C_VoiceChat.GetTtsVoices()) do
                            voices[v.voiceID] = v.name
                        end
                    end
                    if not next(voices) then voices[0] = L["Default"] end
                    return voices
                end,
                get=function() return db.tts.voiceID or 0 end,
                set=function(_,v) db.tts.voiceID=v end},
            voiceHint={type="description",fontSize="small",name=L["Install more voices via your OS speech settings. Windows: Settings > Time & Language > Speech. macOS: System Settings > Accessibility > Spoken Content."],order=16},
            ttsRate={type="range",name=L["Speech Rate"],order=17,min=-10,max=10,step=1,
                disabled=function() return not db.tts.enabled end,
                get=function() return db.tts.rate or 0 end,
                set=function(_,v) db.tts.rate=v end},
            ttsVolume={type="range",name=L["Volume"],order=18,min=0,max=100,step=1,
                disabled=function() return not db.tts.enabled end,
                get=function() return db.tts.volume or 100 end,
                set=function(_,v) db.tts.volume=v end},
            ttsPreview={type="execute",name=L["Preview Text to Speech"],order=1.5,
                disabled=function() return not db.tts.enabled end,
                func=function()
                    if not C_VoiceChat or not C_VoiceChat.SpeakText then return end
                    C_VoiceChat.StopSpeakingText()
                    local playerName = UnitName("player") or "Player"
                    local msg = "Frostbolt"
                    if db.tts.announceBoth then msg = "Frostbolt on " .. playerName
                    elseif db.tts.announceTarget then msg = playerName end
                    C_VoiceChat.SpeakText(db.tts.voiceID or 0, msg, db.tts.rate or 0, db.tts.volume or 100, false)
                end},
        }},
        glowGroup={type="group",name=L["Glows"],order=8,args={
            glowEnabled={type="toggle",name=L["Enable Glows"],order=1,width="full",
                get=function() return db.glow.enabled end,
                set=function(_,v)
                    db.glow.enabled=v
                    if v and not db.glow.glowOnTargeted and not db.glow.glowOnNonTargeted
                       and not db.glow.glowOnTarget and not db.glow.glowOnFocus
                       and not db.glow.glowOnImportant
                       and not db.glow.glowOnEnemyTargetingMDC then
                        db.glow.glowOnTargeted = true
                    end
                    RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end
                end},
            sep1={type="header",name=L["Glow Triggers"],order=2},
            glowOnTargeted={type="toggle",name=L["Glow on All Targeted Casts"],order=3,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnTargeted end,
                set=function(_,v) db.glow.glowOnTargeted=v; if v then db.glow.glowOnNonTargeted=false; db.glow.glowOnTarget=false; db.glow.glowOnFocus=false; db.glow.glowOnImportant=false; db.glow.glowOnEnemyTargetingMDC=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            glowOnNonTargeted={type="toggle",name=L["Glow on Non-Targeted Casts"],order=3.5,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnNonTargeted end,
                set=function(_,v) db.glow.glowOnNonTargeted=v; if v then db.glow.glowOnTargeted=false; db.glow.glowOnTarget=false; db.glow.glowOnFocus=false; db.glow.glowOnImportant=false; db.glow.glowOnEnemyTargetingMDC=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            glowOnTarget={type="toggle",name=L["Glow on Your Target"],order=4,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnTarget end,
                set=function(_,v) db.glow.glowOnTarget=v; if v then db.glow.glowOnTargeted=false; db.glow.glowOnNonTargeted=false; db.glow.glowOnFocus=false; db.glow.glowOnImportant=false; db.glow.glowOnEnemyTargetingMDC=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            glowOnFocus={type="toggle",name=L["Glow on Focus Target"],order=5,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnFocus end,
                set=function(_,v) db.glow.glowOnFocus=v; if v then db.glow.glowOnTargeted=false; db.glow.glowOnNonTargeted=false; db.glow.glowOnTarget=false; db.glow.glowOnImportant=false; db.glow.glowOnEnemyTargetingMDC=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            sep1b={type="header",name=L["Blizzard Glow Triggers"],order=6},
            glowOnImportant={type="toggle",name=L["Glow on Important Casts"],order=7,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnImportant end,
                set=function(_,v) db.glow.glowOnImportant=v; if v then db.glow.glowOnTargeted=false; db.glow.glowOnNonTargeted=false; db.glow.glowOnTarget=false; db.glow.glowOnFocus=false; db.glow.glowOnEnemyTargetingMDC=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            glowOnEnemyTargetingMDC={type="toggle",name=L["Glow When Targeted by Enemy"],order=8.5,width="full",
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.glowOnEnemyTargetingMDC end,
                set=function(_,v) db.glow.glowOnEnemyTargetingMDC=v; if v then db.glow.glowOnTargeted=false; db.glow.glowOnNonTargeted=false; db.glow.glowOnTarget=false; db.glow.glowOnFocus=false; db.glow.glowOnImportant=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            sep2={type="header",name=L["Glow Style"],order=9},
            glowType={type="select",name=L["Glow Type"],order=10,
                disabled=function() return not db.glow.enabled end,
                values={PIXEL=L["Pixel Glow"],AUTOCAST=L["AutoCast Glow"],BUTTON=L["Button Glow"]},
                get=function() return db.glow.glowType end,
                set=function(_,v) db.glow.glowType=v; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            lines={type="range",name=L["Number of Lines"],order=11,min=1,max=20,step=1,
                disabled=function() return not db.glow.enabled or db.glow.glowType ~= "PIXEL" end,
                get=function() return db.glow.lines end,
                set=function(_,v) db.glow.lines=v; RefreshAll() end},
            thickness={type="range",name=L["Thickness"],order=12,min=1,max=8,step=1,
                disabled=function() return not db.glow.enabled or db.glow.glowType ~= "PIXEL" end,
                get=function() return db.glow.thickness end,
                set=function(_,v) db.glow.thickness=v; RefreshAll() end},
            frequency={type="range",name=L["Speed"],order=13,min=-2,max=2,step=0.05,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.frequency end,
                set=function(_,v) db.glow.frequency=v; RefreshAll() end},
            sep3={type="header",name=L["Colors"],order=14},
            glowColor={type="color",name=L["Targeted Cast Color"],order=15,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.colorR, db.glow.colorG, db.glow.colorB, db.glow.colorA end,
                set=function(_,r,g,b,a) db.glow.colorR=r; db.glow.colorG=g; db.glow.colorB=b; db.glow.colorA=a; RefreshAll() end},
            targetColor={type="color",name=L["Your Target Color"],order=16,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.targetColorR, db.glow.targetColorG, db.glow.targetColorB, db.glow.targetColorA end,
                set=function(_,r,g,b,a) db.glow.targetColorR=r; db.glow.targetColorG=g; db.glow.targetColorB=b; db.glow.targetColorA=a; RefreshAll() end},
            focusColor={type="color",name=L["Focus Target Color"],order=17,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.focusColorR, db.glow.focusColorG, db.glow.focusColorB, db.glow.focusColorA end,
                set=function(_,r,g,b,a) db.glow.focusColorR=r; db.glow.focusColorG=g; db.glow.focusColorB=b; db.glow.focusColorA=a; RefreshAll() end},
            importantColor={type="color",name=L["Important Cast Color"],order=18,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.importantColorR, db.glow.importantColorG, db.glow.importantColorB, db.glow.importantColorA end,
                set=function(_,r,g,b,a) db.glow.importantColorR=r; db.glow.importantColorG=g; db.glow.importantColorB=b; db.glow.importantColorA=a; RefreshAll() end},
            enemyTargetColor={type="color",name=L["Enemy Targeting You Color"],order=19,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.enemyTargetColorR, db.glow.enemyTargetColorG, db.glow.enemyTargetColorB, db.glow.enemyTargetColorA end,
                set=function(_,r,g,b,a) db.glow.enemyTargetColorR=r; db.glow.enemyTargetColorG=g; db.glow.enemyTargetColorB=b; db.glow.enemyTargetColorA=a; RefreshAll() end},
            nonTargetedColor={type="color",name=L["Non-Targeted Cast Color"],order=20,hasAlpha=true,
                disabled=function() return not db.glow.enabled end,
                get=function() return db.glow.nonTargetedColorR, db.glow.nonTargetedColorG, db.glow.nonTargetedColorB, db.glow.nonTargetedColorA end,
                set=function(_,r,g,b,a) db.glow.nonTargetedColorR=r; db.glow.nonTargetedColorG=g; db.glow.nonTargetedColorB=b; db.glow.nonTargetedColorA=a; RefreshAll() end},
        }},
        advanced={type="group",name=L["Advanced"],order=9,args={
            barColorByClassification={type="toggle",name=L["Color Bars by Mob Classification"],order=1,width="full",
                get=function() return db.advanced.barColorByClassification end,
                set=function(_,v) db.advanced.barColorByClassification=v; if v then db.advanced.colorChanneledCasts=false end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            sepColors={type="header",name=L["Colors Classifications"],order=10},
            bossColor={type="color",name=L["Boss Color"],order=11,hasAlpha=true,
                disabled=function() return not db.advanced.barColorByClassification end,
                get=function() return db.advanced.bossColorR, db.advanced.bossColorG, db.advanced.bossColorB, db.advanced.bossColorA end,
                set=function(_,r,g,b,a) db.advanced.bossColorR=r; db.advanced.bossColorG=g; db.advanced.bossColorB=b; db.advanced.bossColorA=a; RefreshAll() end},
            rareEliteColor={type="color",name=L["Rare Elite Color"],order=12,hasAlpha=true,
                disabled=function() return not db.advanced.barColorByClassification end,
                get=function() return db.advanced.rareEliteColorR, db.advanced.rareEliteColorG, db.advanced.rareEliteColorB, db.advanced.rareEliteColorA end,
                set=function(_,r,g,b,a) db.advanced.rareEliteColorR=r; db.advanced.rareEliteColorG=g; db.advanced.rareEliteColorB=b; db.advanced.rareEliteColorA=a; RefreshAll() end},
            eliteColor={type="color",name=L["Elite Color"],order=13,hasAlpha=true,
                disabled=function() return not db.advanced.barColorByClassification end,
                get=function() return db.advanced.eliteColorR, db.advanced.eliteColorG, db.advanced.eliteColorB, db.advanced.eliteColorA end,
                set=function(_,r,g,b,a) db.advanced.eliteColorR=r; db.advanced.eliteColorG=g; db.advanced.eliteColorB=b; db.advanced.eliteColorA=a; RefreshAll() end},
            casterColor={type="color",name=L["Caster Color"],order=14,hasAlpha=true,
                disabled=function() return not db.advanced.barColorByClassification end,
                get=function() return db.advanced.casterColorR, db.advanced.casterColorG, db.advanced.casterColorB, db.advanced.casterColorA end,
                set=function(_,r,g,b,a) db.advanced.casterColorR=r; db.advanced.casterColorG=g; db.advanced.casterColorB=b; db.advanced.casterColorA=a; RefreshAll() end},
            normalColor={type="color",name=L["Normal Color"],order=15,hasAlpha=true,
                disabled=function() return not db.advanced.barColorByClassification end,
                get=function() return db.advanced.normalColorR, db.advanced.normalColorG, db.advanced.normalColorB, db.advanced.normalColorA end,
                set=function(_,r,g,b,a) db.advanced.normalColorR=r; db.advanced.normalColorG=g; db.advanced.normalColorB=b; db.advanced.normalColorA=a; RefreshAll() end},
            sepSpecialColors={type="header",name=L["Special Colors"],order=16},
            colorChanneledCasts={type="toggle",name=L["Color Channeled Casts"],order=17,width="full",
                get=function() return db.advanced.colorChanneledCasts end,
                set=function(_,v) db.advanced.colorChanneledCasts=v; if v then db.advanced.barColorByClassification=false; if db.barGroup then db.barGroup.useTargetClassColor=false end end; RefreshAll(); if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            channeledColor={type="color",name=L["Channeled Cast Color"],order=18,hasAlpha=true,
                disabled=function() return not db.advanced.colorChanneledCasts end,
                get=function() return db.advanced.channeledColorR, db.advanced.channeledColorG, db.advanced.channeledColorB, db.advanced.channeledColorA end,
                set=function(_,r,g,b,a) db.advanced.channeledColorR=r; db.advanced.channeledColorG=g; db.advanced.channeledColorB=b; db.advanced.channeledColorA=a; RefreshAll() end},
            sepTracking={type="header",name=L["Nameplate Tracking"],order=18.7},
            legacyCombatTracking={type="toggle",name=L["In-Combat only nameplate tracking [Legacy]"],order=18.8,width="full",
                get=function() return db.advanced.legacyCombatTracking end,
                set=function(_,v) db.advanced.legacyCombatTracking=v; RefreshAll() end},
            sepBarText={type="header",name=L["Bar Text"],order=19},
            truncateTargetNames={type="toggle",name=L["Truncate Long Target Names"],order=19.5,width="full",
                get=function() return db.advanced.truncateTargetNames end,
                set=function(_,v) db.advanced.truncateTargetNames=v; RefreshAll() end},
            sepTTS={type="header",name=L["Text To Speech Filters"],order=20},
            ttsBossOnly={type="toggle",name=L["Text To Speech only for Boss (Lv 92+) Casts"],order=20.5,width="full",
                disabled=function() return not db.tts.enabled end,
                get=function() return db.advanced.ttsBossOnly end,
                set=function(_,v) db.advanced.ttsBossOnly=v; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            ttsEliteOnly={type="toggle",name=L["Text To Speech only for Elite (Lv 91) Casts"],order=21,width="full",
                disabled=function() return not db.tts.enabled end,
                get=function() return db.advanced.ttsEliteOnly end,
                set=function(_,v) db.advanced.ttsEliteOnly=v; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            ttsCasterOnly={type="toggle",name=L["Text To Speech only for Caster Mobs"],order=22,width="full",
                disabled=function() return not db.tts.enabled end,
                get=function() return db.advanced.ttsCasterOnly end,
                set=function(_,v) db.advanced.ttsCasterOnly=v; if MythicDungeonCasts._refreshCurrentTab then MythicDungeonCasts._refreshCurrentTab() end end},
            ttsFiltersNote={type="description",fontSize="small",name=L["Enable Text to Speech to use these filters."],order=23,
                hidden=function() return db.tts.enabled end},
        }},
    }}
end

-- ── Minimap button (LibDBIcon) ─────────────────────────────────
local LDB     = LibStub and LibStub("LibDataBroker-1.1", true)
local LDBIcon = LibStub and LibStub("LibDBIcon-1.0", true)
local minimapLDB

local function MDC_EnsureLDBObject()
    if minimapLDB or not LDB then return minimapLDB end
    minimapLDB = LDB:NewDataObject(ADDON_NAME, {
        type  = "launcher",
        icon  = 4352494, -- MDC addon icon (FileDataID, matches the TOC IconTexture)
        label = DISPLAY_NAME,
        OnClick = function(_, button)
            MythicDungeonCasts:OpenOptionsPanel()
        end,
        OnTooltipShow = function(tt)
            tt:AddLine(DISPLAY_NAME, 1, 0.82, 0)
            tt:AddLine(L["Click to display options."] or "Click to display options.", 1, 1, 1)
            tt:AddLine(
                L["You can also use /mdc to open the options panel."]
                or "You can also use /mdc to open the options panel.", 0.7, 0.7, 0.7)
        end,
    })
    return minimapLDB
end

function MythicDungeonCasts:RefreshMinimapButton()
    db = db or self.db.profile
    if not db.minimap then db.minimap = { hide = true } end
    if not (LDB and LDBIcon) then return end
    MDC_EnsureLDBObject()
    if not LDBIcon:IsRegistered(ADDON_NAME) then
        LDBIcon:Register(ADDON_NAME, minimapLDB, db.minimap)
    end

    -- Always provide an addon-compartment entry (the dropdown at the top of the
    -- minimap), independent of whether the minimap ring button is shown. Give it
    -- a friendly display label instead of the raw addon folder name.
    if LDBIcon.IsButtonCompartmentAvailable and LDBIcon:IsButtonCompartmentAvailable() then
        if LDBIcon.AddButtonToCompartment then
            LDBIcon:AddButtonToCompartment(ADDON_NAME) -- no-op if already present
        end
        local obj = LDBIcon.GetMinimapButton and LDBIcon:GetMinimapButton(ADDON_NAME)
        if obj and obj.compartmentData and obj.compartmentData.text ~= DISPLAY_NAME then
            obj.compartmentData.text = DISPLAY_NAME
            if AddonCompartmentFrame and AddonCompartmentFrame.UpdateDisplay then
                AddonCompartmentFrame:UpdateDisplay()
            end
        end
    end

    if db.minimap.hide then
        LDBIcon:Hide(ADDON_NAME)
    else
        LDBIcon:Show(ADDON_NAME)
    end
end


function MythicDungeonCasts:OnInitialize()
    self.db = AceDB:New("MythicDungeonCastsDB", DEFAULTS, "MDC Cherry - Default")
    db = self.db.profile
    if db.removeHyphen ~= nil then
        db.removeSymbol = db.removeHyphen
        db.removeHyphen = nil
    end
    if db.symbolChoice == nil or not MDC_SYMBOL_MAP[db.symbolChoice] then
        db.symbolChoice = "HYPHEN"
    end
    if db.timerAnchor == "NONE" then
        db.removeTimerAnchor = true
        db.timerAnchor = "RIGHT"
    end
    if not db._decimals5Migrated then
        if not db.timerNoDecimals then
            db.decimalsUnder5Only = true
        end
        db._decimals5Migrated = true
    end
    if db.tts and db.tts._overlapMigrated == nil then
        if db.tts.allowOverlapHeavy then
            db.tts.overlapMode = "allow"
        else
            db.tts.overlapMode = "stop"
        end
        db.tts._overlapMigrated = true
    end
    if db.advanced and not db.advanced._eliteSplitMigrated then
        if db.advanced.ttsEliteOnly then
            db.advanced.ttsBossOnly = true
        end
        db.advanced._eliteSplitMigrated = true
    end
    if not db._smoothHideMigrated then
        if db.smoothAnim and db.hideNonInterruptible then
            db.hideNonInterruptible = false
        end
        db._smoothHideMigrated = true
    end
    local options = BuildOptions()
    self._dcOptionsTable = options
    self._displayName = DISPLAY_NAME
    AceConfig:RegisterOptionsTable(ADDON_NAME, options)
    if Settings and Settings.RegisterCanvasLayoutCategory then
        local panel = CreateFrame("Frame"); panel.name = DISPLAY_NAME

        local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOPLEFT", 16, -16)
        title:SetText("Mythic Dungeon Casts")

        local ver = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        ver:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
        ver:SetText("v" .. VERSION)
        ver:SetTextColor(0.6, 0.6, 0.6)

        local desc = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        desc:SetPoint("TOPLEFT", ver, "BOTTOMLEFT", 0, -12)
        desc:SetText("Use the button below or type /mdc to open settings.")

        local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
        btn:SetSize(180, 28)
        btn:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -12)
        btn:SetText("Open Settings")
        btn:SetScript("OnClick", function()
            HideUIPanel(SettingsPanel)
            MythicDungeonCasts:OpenOptionsPanel()
        end)

        local cat = Settings.RegisterCanvasLayoutCategory(panel, DISPLAY_NAME)
        if cat then cat.ID = DISPLAY_NAME; Settings.RegisterAddOnCategory(cat) end
    end
    SLASH_MDC1 = "/mdc"
    SlashCmdList["MDC"] = function(input) MythicDungeonCasts:SlashCommand(input) end
    self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChange")
    self.db.RegisterCallback(self, "OnProfileCopied",  "OnProfileChange")
    self.db.RegisterCallback(self, "OnProfileReset",   "OnProfileChange")
end

function MythicDungeonCasts:OnEnable()
    self:RefreshMinimapButton()
    if not db.disableInitMessage then
        print("|cffffd100Mythic Dungeon Casts|r Loaded: |cfffffffftype /mdc to open the settings.|r")
    end
end
function MythicDungeonCasts:OnDisable() DisableEvents() end

function MythicDungeonCasts:RebuildOptions()
    local options = BuildOptions()
    self._dcOptionsTable = options
    AceConfig:RegisterOptionsTable(ADDON_NAME, options)
end

function MythicDungeonCasts:OnProfileChange()
    db = self.db.profile
    if db.removeHyphen ~= nil then db.removeSymbol = db.removeHyphen; db.removeHyphen = nil end
    if db.symbolChoice == nil or not MDC_SYMBOL_MAP[db.symbolChoice] then db.symbolChoice = "HYPHEN" end
    self:RefreshMinimapButton()
    if db.preview then
        TogglePreview(false); TogglePreview(true)
    elseif isPreviewing then
        TogglePreview(false)
    else
        RefreshAll()
    end
end

function MythicDungeonCasts:SlashCommand(input)
    local arg = (input or ""):match("^%s*(.-)%s*$"):lower()
    if arg == "toggle" then db.enabled = not db.enabled; CheckEnvironment(); print("|cff00ff00Mythic Dungeon Casts:|r " .. (db.enabled and "|cff00ff00Enabled|r" or "|cffff4444Disabled|r"))
    elseif arg == "lock" then db.locked = not db.locked; RefreshAll(); print("|cff00ff00Mythic Dungeon Casts:|r " .. (db.locked and "Locked" or "Unlocked"))
    elseif arg == "preview" then db.preview = not db.preview; TogglePreview(db.preview)
    else self:OpenOptionsPanel() end
end
