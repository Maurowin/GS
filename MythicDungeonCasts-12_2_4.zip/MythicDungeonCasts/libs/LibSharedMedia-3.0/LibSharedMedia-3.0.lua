local MAJOR, MINOR = "LibSharedMedia-3.0", 1
local lib = LibStub:NewLibrary(MAJOR, MINOR)
if not lib then return end

local _storage = lib._storage or {}
lib._storage = _storage

local MediaType_BACKGROUND = "background"
local MediaType_BORDER      = "border"
local MediaType_FONT        = "font"
local MediaType_STATUSBAR   = "statusbar"
local MediaType_SOUND       = "sound"

lib.MediaType = {
	BACKGROUND = MediaType_BACKGROUND,
	BORDER      = MediaType_BORDER,
	FONT        = MediaType_FONT,
	STATUSBAR   = MediaType_STATUSBAR,
	SOUND       = MediaType_SOUND,
}

-- Initialise storage buckets
for _, mt in pairs(lib.MediaType) do
	_storage[mt] = _storage[mt] or {}
end

function lib:Register(mediatype, key, data, langmask)
	if type(mediatype) ~= "string" then error("mediatype must be string") end
	mediatype = mediatype:lower()
	_storage[mediatype] = _storage[mediatype] or {}
	_storage[mediatype][key] = data
end

function lib:Fetch(mediatype, key, noDefault)
	if type(mediatype) ~= "string" then return end
	mediatype = mediatype:lower()
	local db = _storage[mediatype]
	if db then
		if key and db[key] then return db[key] end
		if not noDefault then
			-- return any first entry as fallback
			local _, v = next(db)
			return v
		end
	end
end

function lib:IsValid(mediatype, key)
	if type(mediatype) ~= "string" then return false end
	mediatype = mediatype:lower()
	return _storage[mediatype] and _storage[mediatype][key] and true or false
end

function lib:List(mediatype)
	if type(mediatype) ~= "string" then return {} end
	mediatype = mediatype:lower()
	local db = _storage[mediatype]
	if not db then return {} end
	local list = {}
	for k in pairs(db) do list[#list+1] = k end
	table.sort(list)
	return list
end

function lib:HashTable(mediatype)
	if type(mediatype) ~= "string" then return {} end
	mediatype = mediatype:lower()
	return _storage[mediatype] or {}
end

function lib:GetGlobal(mediatype)
	return self:Fetch(mediatype, "")
end

-- ── Default Media ──────────────────────────────────────────────────────────

-- Fonts
lib:Register("font", "Arial Narrow",       [[Fonts\ARIALN.TTF]])
lib:Register("font", "Friz Quadrata TT",   [[Fonts\FRIZQT__.TTF]])
lib:Register("font", "Morpheus",           [[Fonts\MORPHEUS.TTF]])
lib:Register("font", "Skurri",             [[Fonts\SKURRI.TTF]])
lib:Register("font", "Accidental Presidency", [[Fonts\ARIALN.TTF]])

-- StatusBars
lib:Register("statusbar", "Blizzard",        [[Interface\TargetingFrame\UI-StatusBar]])
lib:Register("statusbar", "Blizzard Raid Bar",[[Interface\RaidFrame\Raid-Bar-Hp-Fill]])
lib:Register("statusbar", "Smooth",          [[Interface\AddOns\DungeonCasts\media\statusbar\smooth]])
lib:Register("statusbar", "Melli",           [[Interface\Buttons\WHITE8X8]])
lib:Register("statusbar", "Solid",           [[Interface\Buttons\WHITE8X8]])
lib:Register("statusbar", "Flat",            [[Interface\Buttons\WHITE8X8]])

-- Borders
lib:Register("border", "None",              "")
lib:Register("border", "Blizzard Dialog",   [[Interface\DialogFrame\UI-DialogBox-Border]])
lib:Register("border", "Blizzard Tooltip",  [[Interface\Tooltips\UI-Tooltip-Border]])

-- Backgrounds
lib:Register("background", "Blizzard Dialog",     [[Interface\DialogFrame\UI-DialogBox-Background]])
lib:Register("background", "Blizzard Low Health",  [[Interface\FullScreenTextures\LowHealth]])
lib:Register("background", "Solid",                [[Interface\Buttons\WHITE8X8]])
